from OLenv import *

num_experts, num_rounds = 5, 1000
data_path = "loss.npy"
env = Env(num_experts, num_rounds, data_path)
random_alg = RandomAlg(num_experts)

env.reset()
for _ in range(num_rounds):
    # random algorithm
    action = random_alg.take_action()
    loss, done = env.step(action)
plt.plot(env.results, label='random')


env.reset()
# for _ in range(num_rounds):
#     # add your code/algorithm here
#     action = your code/algorithm.take_action()
#     loss, done = env.step(action)
# plt.plot(env.results, label='your code/algorithm')

plt.xlabel('time')
plt.ylabel('accumulative loss')
plt.show()