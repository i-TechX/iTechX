import numpy as np

class Env:
    def __init__(self, K, T, data_path):
        self.K = K
        self.T = T
        self.data_path = data_path
        self.loss_fun = np.load(self.data_path)

    def step(self, arm):
        if arm not in set([k for k in range(self.K)]):
            raise (f"please select an expert from 0 to {self.K - 1}")
        loss_t = self.loss_fun[self.t][arm]
        self.regret += loss_t
        self.results += [self.regret]
        self.t += 1
        return loss_t, self.t == self.T

    def reset(self):
        self.loss_fun = np.load(self.data_path)
        self.t = 0
        self.regret = 0.0
        self.results = []
        return True

class RandomAlg:
    def take_action(self):
        return np.random.choice(32)