from env import *
import matplotlib.pyplot as plt
num_experts, num_rounds = 32, 5000
data_path = "losslist.npy"
env = Env(num_experts, num_rounds, data_path)
env.reset()
Randomloss = [0 for _ in range(num_rounds)]
trials = 10 #10 repetitions to take the averge

for _ in range(trials):
    Random = RandomAlg()
    env.reset()
    for i in range(num_rounds):
        arm = Random.take_action()
        loss, done = env.step(arm)
        Randomloss[i] += env.results[i] / trials

plt.plot(Randomloss, label='Randomloss')
plt.grid()
plt.legend()
plt.show()