#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <vector>
#include <utility>
#include <algorithm>
#include <string>
#include <random>
#include <unordered_set>
#include <iostream>

using namespace std;

static size_t signatureWidth; // Signature size (in bits)
static size_t signatureSize;  // Signature size (in uint64_t)
static size_t kmerLength;     // Kmer length
static float density;         // % of sequence set as bits

vector<pair<string, string>> loadFasta(const char *path)
{
  vector<pair<string, string>> sequences;

  FILE *fp = fopen(path, "r");
  if (!fp) {
    fprintf(stderr, "Failed to load %s\n", path);
    exit(1);
  }
  for (;;) {
    char seqNameBuf[8192];
    if (fscanf(fp, " >%[^\n]\n", seqNameBuf) < 1) break;
    string sequenceBuf;

    for (;;) {
      int c = fgetc(fp);
      if (c == EOF || c == '>') {
        ungetc(c, fp);
        break;
      }
      if (isalpha(c)) {
        sequenceBuf.push_back(c);
      }
    }
    sequences.push_back(make_pair(string(seqNameBuf), sequenceBuf));
  }
  fclose(fp);

  return sequences;
}

void generateSignature(uint64_t *output, const pair<string, string> &fasta)
{
  // Generate a signature from the kmers contained within
  
  string fastaSequence = fasta.second;
  // If the sequence is shorter than the kmer length, pad it with Xs
  while (fastaSequence.size() < kmerLength) {
    fastaSequence.push_back('X');
  }
  
  ranlux24_base rng;
  uniform_int_distribution<int> dist(-64 * signatureSize, signatureSize * 64 - 1);
  vector<int> unflattenedSignature(signatureSize * 64);
  int setBits = density * signatureSize * 64;
  //fprintf(stderr, "%s\n", fastaSequence.c_str());
  
  for (size_t i = 0; i < fastaSequence.size() - kmerLength + 1; i++) {
    seed_seq rngSeed(begin(fastaSequence) + i, begin(fastaSequence) + i + kmerLength);
    rng.seed(rngSeed);
    string kmer(begin(fastaSequence) + i, begin(fastaSequence) + i + kmerLength);
    //fprintf(stderr, "- %s\n", kmer.c_str());
    
    for (int j = 0; j < setBits; j++) {
      int bitPos = dist(rng);
      if (bitPos >= 0) {
        unflattenedSignature[bitPos] += 1;
      } else {
        unflattenedSignature[bitPos + 64 * signatureSize] -= 1;
      }
    }
  }
  fill(output, output + signatureSize, 0);
  for (size_t i = 0; i < signatureSize * 64; i++) {
    if (unflattenedSignature[i] > 0) {
      output[i / 64] |= (uint64_t)1 << (i % 64);
    }
  }
}

vector<uint64_t> convertFastaToSignatures(const vector<pair<string, string>> &fasta)
{
  vector<uint64_t> output;
  // Allocate space for the strings
  
  output.resize(fasta.size() * signatureSize);
  
  for (size_t i = 0; i < fasta.size(); i++) {
    generateSignature(&output[signatureSize * i], fasta[i]);
  }
  
  return output;
}




int main(int argc, char **argv)
{
  if (argc < 2) {
    fprintf(stderr, "  -i [input fastafile]\n");
    return 1;
  }
  signatureWidth = 64;
  kmerLength = 5;
  density = 1.0f / 21.0f;
  
  string fastafile = "";
  
  for (int a = 1; a < argc; a++) {
    string arg(argv[a]);
    if (arg == "-i") fastafile = argv[++a];
    else {
      fprintf(stderr, "Invalid or extra argument: %s\n", arg.c_str());
      exit(1);
    }
  }
  
  signatureSize = signatureWidth / 64;
  
  auto fasta = loadFasta(fastafile.c_str());
  auto sigs = convertFastaToSignatures(fasta);
  for(int i=0;i<sigs.size();i++)
    cout << sigs[i] << endl;
  return 0;
}
