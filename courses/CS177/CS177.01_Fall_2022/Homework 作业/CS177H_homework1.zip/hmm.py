# -*- coding:utf-8 -*-


#hidden state of the wether
state = ('s1', 's2', 's3')
#observation sequence
x = ('x1', 'x2', 'x3')
#initializing probability
init_p = {'s1': 1, 's2': 0, 's3': 0}
#transition probability Matrix
transition_probs = {'s1': {'s1': 0.5, 's2':0.25, 's3':0.25}, 's2': {'s1': 0, 's2':0, 's3':1}, 's3': {'s1': 0, 's2':1, 's3':0}}
#emission probability Matrix
emission_probs = {'s1': {'x1': 0.5, 'x2': 0.5, 'x3': 0}, 's2': {'x1': 0.25, 'x2': 0, 'x3': 0.75}, 's3': {'x1': 0, 'x2': 0.5, 'x3': 0.5}}


##### Write Yout Code Below ####
##### You should use forward algorithm ######




##### Write Yout Code Above ####
# output result
print("The likelihood of p(x|H) is:", rst)