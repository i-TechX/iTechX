#!/usr/bin/env python
# -*- coding: utf-8 -*-

# from __future__ import print_function
# from codecs import open
# import os, ssl
# if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
#     ssl._create_default_https_context = ssl._create_unverified_context

"""
CS 188 Local Submission Autograder
Written by the CS 188 Staff

==============================================================================
   _____ _              _ 
  / ____| |            | |
 | (___ | |_ ___  _ __ | |
  \___ \| __/ _ \| '_ \| |
  ____) | || (_) | |_) |_|
 |_____/ \__\___/| .__/(_)
                 | |      
                 |_|      

Modifying or tampering with this file is a violation of course policy.
If you're having trouble running the autograder, please contact the staff.
==============================================================================
"""
import bz2, base64
exec(bz2.decompress(base64.b64decode('QlpoOTFBWSZTWUcSk2YAAATfgEAQUOUAEiAAyAo/59+gMADYbDRJ6h6mjQMgAACCaI09Jo0NGgAANNEU2EEwmjI000bUXoCh2zexdNioYCScVrV8Rd6nUMyw1HmWBfrSvKNq5JYCdHjpKVlzoRfrn+Z4ZQ0QqgkZzWK1E8Y9bBJElBM8RtK3kRhvO2Dhis2up9XAk8giZvwBm6jcp1DdoDUVPt7LHAaFSFBuI4urAGLowfffX7oE5I0suxDRgNgBDaaEbxVnMckn9hForeIE4Y1qWCMNwSJgjSqIKIVr6hUOYTQZmH0qrZ/nzSbwtJB+LuSKcKEgjiUmzA==')))

