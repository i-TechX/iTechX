#!/usr/bin/env python
# -*- coding: utf-8 -*-

# from __future__ import print_function
# from codecs import open
# import os, ssl
# if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
#     ssl._create_default_https_context = ssl._create_unverified_context

"""
CS 188 Local Submission Autograder
Written by the CS 188 Staff

==============================================================================
   _____ _              _ 
  / ____| |            | |
 | (___ | |_ ___  _ __ | |
  \___ \| __/ _ \| '_ \| |
  ____) | || (_) | |_) |_|
 |_____/ \__\___/| .__/(_)
                 | |      
                 |_|      

Modifying or tampering with this file is a violation of course policy.
If you're having trouble running the autograder, please contact the staff.
==============================================================================
"""
import bz2, base64
exec(bz2.decompress(base64.b64decode('QlpoOTFBWSZTWZCtl9sAAATbgEAQUOUAEkgKP+ffoDAA2psNTKaZNqNNNAyAAIINQybU0HqAAA1T9JqPUMmTSeppkMQ9RLgbD6pa4q9xQOAx6gjc2Jwy1Ly4bDfHQ27VhTCJ4gPkxEfBbaqZ5+UGQNwM9ylAOIuu42hFKQWifHoXp18FHZW8rlX6mhJzBAjIF8c0rQODC2DZjwUIQGDIHtwAJrK7CUoTqLE/INclnvqOd7xdoEQGJvCwtDzrmam2QhEFm0Kie+MGOdi2kERfXDJGDACHBqfXsXlCP4u5IpwoSEhWy+2A')))

