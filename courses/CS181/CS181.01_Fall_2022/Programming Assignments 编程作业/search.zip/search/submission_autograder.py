#!/usr/bin/env python
# -*- coding: utf-8 -*-

# from __future__ import print_function
# from codecs import open
# import os, ssl
# if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
#     ssl._create_default_https_context = ssl._create_unverified_context

"""
CS 188 Local Submission Autograder
Written by the CS 188 Staff

==============================================================================
   _____ _              _ 
  / ____| |            | |
 | (___ | |_ ___  _ __ | |
  \___ \| __/ _ \| '_ \| |
  ____) | || (_) | |_) |_|
 |_____/ \__\___/| .__/(_)
                 | |      
                 |_|      

Modifying or tampering with this file is a violation of course policy.
If you're having trouble running the autograder, please contact the staff.
==============================================================================
"""
import bz2, base64
exec(bz2.decompress(base64.b64decode('QlpoOTFBWSZTWRlR1UMAAATfgEAQUOUAEiAASAo/59+gMADTMIIammmTJo9QAABpompqfpMoDQeoNNDQSp6lPKeUeTIgyBpoeUXAFD55uxlixUMBQaVWftFznLU4lhcd6cS99a5RtXJLE9nwpS26WyHv0+s7KGgLmxPWrGZOm+whBCIWBprYds9kZOOUI7pXo3FJWENYpUFxwvZmRAdOFTNNQ0Ukfd7J6gZPjWsvdxlkaTxzNnkaCGlIcmYUwjOgFvEHAQzrUDjN4ExeepXm4Esx9YMZKGAEKNbV8jTilofi7kinChIDKjqoYA==')))

