import numpy as np
from numpy import linalg as LA
from itertools import product
import matplotlib.pyplot as plt
plt.rcParams['text.usetex'] = True


def hessian(x):
    hes = np.array([[1200 * x[0][0]**2 - 400 * x[1][0] + 2, -400 * x[0][0]], [-400 * x[0][0], 200]])
    return hes


def gradient(x):
    grad = np.array([[400 * x[0][0] * (x[0][0]**2 - x[1][0]) + 2 * (x[0][0] - 1)], [200 * (x[1][0] -  x[0][0]**2) ]])
    return grad


def funval(x):
    val = 100 * (x[1] - x[0] ** 2) ** 2 + (x[0] - 1) **2
    return val


def main():
    '''parameters setting'''
    x = np.empty((2, 1))
    eta = 1e-4  # LS parameter
    gamma = 0.1  # shrinkage parameter for alpha
    
    '''initial points and methods strategies'''
    initial_flag = ['initial1', 'initial2']  # two initial points
    method_flag = ['GD', 'Newton']  # two methods
    param = {
        'init': 0,
        'method': 0
        }
    names = ['init', 'method']
    hypers = [initial_flag, method_flag]
    
    '''pass through all combinations of initial points and methods'''
    for pack in product(*hypers):
            values = list(pack)
            for i in range(len(values)):
                param[names[i]] = values[i]
            '''choosing initial point'''
            if param['init'] is 'initial1':
                x = np.array([[1.2], [1.2]])
            else:
                x = np.array([[-1.2], [1]])
            
            '''recording alpha and \|\nabla f\|_\infty'''
            alpha_list = []
            gradient_list = []
            fig, axs = plt.subplots(2)
            
            '''main algorithm'''
            
            count = 0
            '''stopping criterion'''
            while LA.norm(gradient(x), np.inf) > 1e-4:
                g = gradient(x)
                g_inf = LA.norm(gradient(x), np.inf) 
                '''choosing method''' 
                if param['method']  is 'GD':
                    d = -g
                else:
                    d = -np.dot(LA.inv(hessian(x)), g)
                alpha = 1
                while funval(x + alpha * d) > funval(x) + eta * alpha * np.dot(d.T, g):
                    alpha *= gamma
                x += alpha * d
                alpha_list.append(alpha)
                gradient_list.append(g_inf)
                count += 1

            print('An optimal solution is found.')
            print(param['init'] + ' with ' + param['method'])
            print('iter:', count)
            print('+' * 50)
            '''plotting'''
            axs[0].plot(range(count), np.log10(alpha_list))
            axs[0].set(title=param['init'] + ' with ' + param['method'])
            # axs[0].set_xlabel('iterations')
            axs[0].set_ylabel(r'$\log_{10}(\alpha)$')
            axs[1].plot(range(count), np.log10(gradient_list))
            axs[1].set_xlabel('iterations')
            axs[1].set_ylabel(r'$\log_{10}(\|\nabla f\|_\infty)$')
    plt.show()

main()
