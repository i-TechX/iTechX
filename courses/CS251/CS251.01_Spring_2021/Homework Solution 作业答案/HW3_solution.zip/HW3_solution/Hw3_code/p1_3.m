load('data.mat')
[M,N] = size(A);

L =2;
C = kron(eye(L),A);
b = reshape(B,[M*L,1]);
conic(C,b,mu,M,L,N)
