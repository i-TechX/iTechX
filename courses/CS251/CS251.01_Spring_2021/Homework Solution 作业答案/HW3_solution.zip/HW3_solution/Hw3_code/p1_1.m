clc 
clear
load('data.mat')
[M,N] = size(A);
[~,L] = size(B);
% X = [ 1 2 3;
%      4 5 6];
% norm21(X)
% sum(sqrt(sum(X.^2,2)))

cvx_begin
     cvx_solver mosek
    variable X(N,L)
    expression temp(N,1)
    for i = 1:N
        temp(i) =  norm( X(i,:),2 );
    end     
    minimize 1/2 * pow_pos ( norm(A*X-B,'fro'),2 )  + mu*ones(1,N)*temp
    
cvx_end

% function  sum = norm21(X)
%     [N,L] = size(X);
%     sum = 0;
%     for i = 1:N
%         sum = sum + norm( X(i,:),2 );
%     end
% end