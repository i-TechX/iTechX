function conic(C,b,mu,M,L,N)
%  N = 512 M = 256 L = 2
% A (256*512),   C (ML, NL) b (ML, 1)
%% 
% variable     [s,  (t_1,t_2,...,t_N),  (x_1,x_2,...,x_NL),  y  ,  0.5 ]
% count :       1  +    N         +          NL    +        M*2  +  1  =  4*N + 2 
%% N Cones
%    1          t_1 (2)                x_1   (2)    x_(1+N)
%    2          t_2 (3)                x_2    (2)    x_(2+N)
%    3          t_3 (4)                x_3  (2)    x_(3+N)
%    4          t_4 (5)                x_4  (2)    x_(4+N)
%    i          t_i (i+1)                x_i   (2)    x_(i+N)
%    N          t_N (N+1)                x_N  (2)      x_(2N)
%   N+1         
%%
c = zeros(N*4+2,1);
c(1) = 0.5;
c(2:513) = mu;
H = zeros(M*L,N*4+2);
H(:,N+2:N+1+N*L) = C;
H(:,N+1+N*L:N*4+1) = -1;

lx = -inf*ones(N*4+2,1);
ux = -lx;
lx(end) = 0.5;
ux(end) = 0.5;

clear prob;

[r, res] = mosekopt('symbcon');
% Specify the non-conic part of the problem.


prob.c   = c;
prob.a   = sparse(H);
prob.blc = b;
prob.buc = b;
prob.blx = lx;
prob.bux = ux;

dim_cone = zeros(N+1,1);
dim_cone(N+1) = res.symbcon.MSK_CT_RQUAD;
for i=1:N
    dim_cone(i) = res.symbcon.MSK_CT_QUAD;
end

sub = zeros(4*N+2,1);

for i=1:N
    sub(3*(i-1)+1) = 2+(i-1); % start index of i-th cone
    sub(3*(i-1)+2) = 2+(i-1)+N;
    sub(3*(i-1)+3) = 2+(i-1)+2*N;
end

sub(3*N+1) = 4*N+2; % start of (N+1)-th cone
sub(3*N+2) = 1;
sub(3*N+3:end) = 3*N+2:1:4*N+1;


subptr = zeros(N+1,1);

for i=1:N
    subptr(i) = 3*(i-1)+1;
end
subptr(end) = 3*N+1;

% Specify the cones.
prob.cones.type   = dim_cone;
prob.cones.sub    = sub;
prob.cones.subptr = subptr;


[r,res]=mosekopt('minimize',prob);

% Display the primal solution.

res.sol.itr.xx'
