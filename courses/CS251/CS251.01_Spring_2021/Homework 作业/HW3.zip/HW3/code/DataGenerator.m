%% Data Generation
seed = 97006855;
ss = RandStream('mt19937ar', 'Seed', seed);
RandStream.setGlobalStream(ss);
N = 512;
M = 256;
A = randn(M, N);
K = round(N*0.1); L = 2;
A = randn(M, N);
p = randperm(N); p = p(1:K);
u = zeros(N, L); u(p, :) = randn(K, L);
B = A*u;
mu = 1e-2;

save('data.mat', 'A', 'B', 'mu');

