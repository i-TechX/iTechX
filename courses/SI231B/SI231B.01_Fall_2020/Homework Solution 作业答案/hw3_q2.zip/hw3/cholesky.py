import numpy as np

__all__ = ["Cholesky_Decomposition"]


def Cholesky_Decomposition(A):
    N = A.shape[0]
    diag_A = np.diag(A)
    D = np.zeros(N)
    L = np.diag(np.ones_like(diag_A))
    D[0] = diag_A[0]
    for i in np.arange(N):
        s_d = 0
        for j in np.arange(i):
            s_l = 0
            for k in np.arange(j):
                s_l += L[i, k] * L[j, k] * D[k]
            L[i, j] = (A[i, j] - s_l) / D[j]
            s_d += L[i, j] ** 2 * D[j]
        D[i] = A[i, i] - s_d
    # L += np.tril(L).T - np.diag(L.diagonal())
    D_matrix = np.diag(D)
    return L, D_matrix


if __name__ == "__main__":
    A = [[34, 47, 5, 18, 26],
         [47, 10, 13, 26, 34],
         [5, 13, 26, 39, 47],
         [18, 26, 39, 42, 5],
         [26, 34, 47, 5, 18]]

    L, D = Cholesky_Decomposition(np.array(A, dtype=np.float))
    print("L = \n", L)
    print("D = \n", D)
    print("LDL^T - A= \n,", L.dot(D).dot(L.T) - np.array(A, dtype=np.float))
    # print(np.linalg.cholesky(np.array(A,dtype=np.float)))
    # print(torch.cholesky(torch.tensor(A,dtype=torch.float)))
