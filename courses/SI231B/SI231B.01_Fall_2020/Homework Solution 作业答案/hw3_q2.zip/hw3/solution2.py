import numpy as np
import time
from cholesky import *
from LU import *

print("==================load data================")
d=open('data.txt')
l=open('label.txt')
g=open('groundtruth.txt')

data=[]
label=[]
gt=[]

lines=d.readlines()
for line in lines:
    line=line.strip().split()
    data.append(line)

lines=l.readlines()
for line in lines:
    label.append(float(line.strip('\n')))

lines=g.readlines()
for line in lines:
    gt.append(float(line.strip('\n')))

data=np.array(data).astype(float)
label=np.array(label).reshape(-1,1).astype(float)
gt=np.array(gt).reshape(-1,1).astype(float)
print(data.shape, label.shape, gt.shape)
print("==============groundtruth===================")

loss_f = np.matmul(data, gt) - label
loss_gt = np.sum(loss_f ** 2)
grad_gt = 2 * np.matmul(data.T, loss_f)
print('loss: {:.6f}, grad_norm: {:.9f}'.format(loss_gt,np.linalg.norm(grad_gt)))

print("============== LS normal eq===================")
# use your own methods to solve this martrix
# x=np.linalg.inv(np.matmul(data.T, data))@data.T@label

t_s = time.monotonic()

L, D = Cholesky_Decomposition(np.matmul(data.T, data))
x = forwards_substitution(L, data.T@label)
# print(210*210 - np.sum(np.isclose(D, 0)))
x = np.matmul(np.diag(1./np.diag(D)), x)
x = backwards_substitution(L.T, x)

t_e = time.monotonic()

s, ms = divmod((t_e - t_s)*1000, 1000)
m, s = divmod(s, 60)
h, m = divmod(m, 60)
print("%d:%02d:%02d:%02d" % (h, m, s, ms))

# print(x.shape)
error=np.linalg.norm(abs(x-gt))

loss_f = np.matmul(data, x) - label
loss_gt = np.sum(loss_f ** 2)
grad_gt = 2 * np.matmul(data.T, loss_f)
print('loss: {:.6f}, grad_norm: {:.9f}, dis: {:.6f}'.format(loss_gt,np.linalg.norm(grad_gt),error))


print("============== LS normal gd ===================")

# print(data.shape)
w = np.zeros((data.shape[1], 1))

t_s = time.monotonic()

loss_f = (np.matmul(data, w) - label)
loss = np.sum(loss_f ** 2)
grad = np.matmul(data.T, loss_f)
gradient_norm = np.linalg.norm(grad)
# print(gradient_norm, 1e-6)

lr = 1e-5
epoch = 0
gradient_cache = [gradient_norm, ]
while gradient_norm >= 1e-9:
    w = w - lr * grad
    loss_f = np.matmul(data, w) - label
    loss = np.sum(loss_f ** 2)
    grad = np.matmul(data.T, loss_f)
    gradient_norm = np.linalg.norm(grad)
    epoch = epoch + 1
    # if epoch % 10 == 0:
    #     print("epoch = %6f, gradient_norm = %.15f" % (epoch, gradient_norm))
    gradient_cache.append(gradient_norm)

t_e = time.monotonic()

s, ms = divmod((t_e - t_s)*1000, 1000)
m, s = divmod(s, 60)
h, m = divmod(m, 60)
print("%d:%02d:%02d:%02d" % (h, m, s, ms))

print("epochs: ", epoch)
np.savetxt('result2.txt', w, fmt='%.9e', delimiter=',', newline='\n')
print('loss: {:.6f}, grad_norm: {:.9f}, dis: {:.6f}'.format(loss, np.linalg.norm(grad), np.linalg.norm(gt - w)))


