import numpy as np


def Gassian_elimination(A: np.ndarray):
    M = A.shape[-2]
    N = A.shape[-1]
    L = np.diag(np.ones(M))
    R = A.copy()
    for i in range(N):
        G = np.diag(np.ones(M))
        G_inv = np.diag(np.ones(M))
        if R[i, i]:
            # print("normal\n")
            G[i + 1:, i] = -R[i + 1:, i] / R[i, i]
            G_inv[i + 1:, i] = R[i + 1:, i] / R[i, i]
            L = np.matmul(L, G_inv)
            # print("G:", G, '\n')
            # print("R:", R, '\n')
            R = np.matmul(G, R)
        else:
            # TODO: replace R[i, i] by first non-zero element at ith column
            ix = np.nonzero(R[i:, i])[0]
            if ix.size>0:
                # print("permute\n")
                P = np.diag(np.ones(M))
                P[ix + i, ix + i] = P[i, i] = 0
                P[ix + i, i] = P[i, ix + i] = 1
                # print('P:',P,'\n')
                # print("R:", R, '\n')
                L = np.matmul(L, P)
                R = np.matmul(P, R)
                G[i + 1:, i] = -R[i + 1:, i] / R[i, i]
                G_inv[i + 1:, i] = R[i + 1:, i] / R[i, i]
                L = np.matmul(L, G_inv)
                # print("G:", G, '\n')
                # print("R:", R, '\n')
                R = np.matmul(G, R)
            else:
                pass
    return L, R


if __name__ == "__main__":
    A = np.array([[17, 24, 1, 8, 15],
                      [23, 5, 7, 14, 16],
                      [4, 6, 13, 20, 22],
                      [10, 12, 19, 21, 3],
                      [11, 18, 25, 2, 9]]).astype(np.float_)
    # A = np.array([[1., 2., 3.],
    #               [1., 2., 3.],
    #               [2., 4., 6.],
    #               [1., 1., 1.],
    #               [1., 2., 1.],
    #               [2., 4., 2.]])
    L, U = Gassian_elimination(A)
    print(U)
    # print(U[np.any(U != 0, axis=-1)])
