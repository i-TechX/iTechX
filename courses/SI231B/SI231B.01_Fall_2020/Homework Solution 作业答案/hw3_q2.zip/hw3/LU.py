import numpy as np
import torch

__all__=["backwards_substitution", "forwards_substitution", "LU_decomposition", "solve"]

def LU_decomposition(A):
    # A = np.array()
    N = A.shape[0]
    L = np.diag(np.ones(N))
    R = A.copy()
    for i in np.arange(N - 1):
        G = np.diag(np.ones(N))
        G_inv = np.diag(np.ones(N))
        G[i + 1:, i] = -R[i + 1:, i] / R[i, i]
        G_inv[i + 1:, i] = R[i + 1:, i] / R[i, i]
        L = np.dot(L, G_inv)
        R = np.dot(G, R)
    return L, R


def backwards_substitution(A, b):
    """

    :param A:
    :param b:
    :return:
    """
    diag = np.diag(A)
    N = A.shape[0]
    if len(b.shape) == 2:
        x = b.reshape(N, -1)
        M = b.shape[1]
    elif len(b.shape) == 1:
        x = b.reshape(N, 1)
        M = 1
    x[-1, :] = b[-1, :] / diag[-1]
    for j in np.arange(N - 2, -1, -1):
        pp = np.dot(A[j:j + 1, j + 1:], x[j + 1:, :])
        x[j, :] = 1 / diag[j] * (x[j, :] - np.dot(A[j:j+1, j + 1:] , x[j + 1:, :]))
    return x


def forwards_substitution(A, b):
    """

    :param A:
    :param b:
    :return:
    """
    diag = np.diag(A)
    N = A.shape[0]
    if len(b.shape) == 2:
        x = b.reshape(N, -1)
    elif len(b.shape) == 1:
        x = b.reshape(N, 1)
    x[0, :] = b[0, :] / diag[0]
    for j in np.arange(1, N):
        x[j, :] = 1 / diag[j] * (x[j, :] - np.dot(A[j:j+1, :j], x[:j, :]))
    return x


def solve(A, B):
    """

    Solve a linear matrix equation, or system of linear scalar equations.

    Computes the "exact" solution, `x`, of the well-determined, i.e., full
    rank, linear matrix equation `ax = b`.

    Parameters
    ----------
    a : (..., M, M) array_like
        Coefficient matrix.
    b : {(..., M,), (..., M, K)}, array_like
        Ordinate or "dependent variable" values.

    Returns
    -------
    x : {(..., M,), (..., M, K)} ndarray
        Solution to the system a x = b.  Returned shape is identical to `b`.    """

    L, R = LU_decomposition(A)
    print(L)
    print(R)
    x = forwards_substitution(L, B)
    x = backwards_substitution(R, x)
    return x

if __name__ == "__main__":
    A = np.array([[17, 24, 1, 8, 15],
                  [23, 5, 7, 14, 16],
                  [4, 6, 13, 20, 22],
                  [10, 12, 19, 21, 3],
                  [11, 18, 25, 2, 9]],dtype=np.float)
    b1 = np.array([1, 2, 3, 4, 8],dtype=np.float).reshape(1, -1).T
    b2 = np.array([2, 3, 4, 3, 6],dtype=np.float).reshape(1, -1).T
    b3 = np.array([3, 4, 5, 6, 8],dtype=np.float).reshape(1, -1).T

    B = np.concatenate((b1, b2, b3), axis=1)
    print("numpy result x =:\n",np.linalg.solve(A, B))
    # A_LU, pivots = torch.lu(torch.tensor(A))
    # print(np.linalg.inv(A))
    # print(A_LU)
    # print(torch.lu_solve(torch.tensor(B), A_LU, pivots))
    print("My result x=:\n",solve(A, B))
    print("Ax-B =\n",A.dot(solve(A, B))-B)
