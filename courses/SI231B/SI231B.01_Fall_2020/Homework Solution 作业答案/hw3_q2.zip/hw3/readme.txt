data.txt: 1000　rows, 210 numbers in each row.
label.txt: 1000 rows, 1 number in each row.　扰动：真实值＋random[-10, 10]

groundtruth.txt:210 numbers. 生成直线的真正系数，LS计算出的结果应该与这210个数接近。（我们自己跑代码写solution时用，不release给学生)
