import numpy as np

d=open('data.txt')
l=open('label.txt')

g=open('groundtruth.txt')

data=[]
label=[]

gt=[]

lines=d.readlines()
for line in lines:
    line=line.strip().split()
    data.append(line)

lines=l.readlines()
for line in lines:
    label.append(float(line.strip('\n')))

lines=g.readlines()
for line in lines:
    gt.append(float(line.strip('\n')))

data=np.array(data)
label=np.array(label).reshape(-1,1)
print(data.shape, label.shape)

gt=np.array(gt)

data=data.astype(float)
label=label.astype(float)

gt=gt.astype(float)

x=np.linalg.inv(np.matmul(data.T, data))@data.T@label

x=np.array(x)
x=np.squeeze(x)

print(x.shape,gt.shape)
error=np.sum(abs(x-gt))

print(error)