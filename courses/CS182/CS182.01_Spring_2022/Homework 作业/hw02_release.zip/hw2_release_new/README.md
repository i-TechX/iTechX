# CS182 HW2

## Introduction

HW2 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (30 PTS)

1. Finish the problems in `..\writing\hw2_writing.pdf`.
2. Upload your answers as "name_hw2_writing.pdf" to Gradescope.

### Part Two: Coding (70 PTS)

1. Finish `..\coding\hw2_coding.ipynb`. 
2. Upload your answers as "name_hw2_coding.pdf" to Gradescope.

## Due date
 
Friday, Apr. 8 at 23:59 (CST)
