#define PI 3.1415926535897932f
#define DELTA 1e-4f

/* Material settings */
#define AMBIENT_MAGNITUDE 0.1f
#define SPECULAR_SHININESS 16.0f