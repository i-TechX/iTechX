#include <glm/gtc/reciprocal.hpp>
#include <ctime>

int main()
{
	return 0;
}

