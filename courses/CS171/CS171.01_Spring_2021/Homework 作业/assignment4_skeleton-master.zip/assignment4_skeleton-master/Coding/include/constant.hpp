#pragma once
#define DELTA 0.0001f
#define EPSILON 0.00001f
#define PI 3.14159265358979323846f
#define PI_INV 0.31830988618f
#define INF 1e12f
