#include <light.h>

/**
 * Light class
 */
Light::Light(const vec3 &position, const vec3 &color)
    : position(position), color(color) {}

vec3 Light::getPosition() const { return position; }

vec3 Light::getColor() const { return color; }

/**
 * AreaLight class
 */
AreaLight::AreaLight(const vec3 &position, const vec3 &color, const vec2 &size)
    : Light(position, color),
      areaSize(size),
      geoms(makeParallelogram(position - vec3(size[0], 0, size[1]) / 2,
                              vec3(size[0], 0, 0), vec3(0, 0, size[1]),
                              vec3(0, -1, 0), nullptr)) {}

std::vector<LightSamplePair> AreaLight::samples() const {
  std::vector<LightSamplePair> ret;

  // TODO: generate rectangle light samples
  // !!!DELETE THIS WHEN FINISHED
  UNIMPLEMENTED;

  return ret;
}

bool AreaLight::intersect(Interaction &interaction,
                                const Ray &ray) const {
  bool intersection = false;
  for (auto &i : geoms)
    intersection = intersection || i->intersect(interaction, ray);
  interaction.type = Interaction::Type::LIGHT;
  return intersection;
}

std::shared_ptr<Light> makeAreaLight(const vec3 &position, const vec3 &color,
                                     const vec2 &size) {
  return std::make_shared<AreaLight>(position, color, size);
}