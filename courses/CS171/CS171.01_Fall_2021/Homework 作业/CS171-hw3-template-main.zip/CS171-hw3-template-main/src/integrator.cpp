#include <integrator.h>
#include <material.h>
#include <light.h>

/**
 * Integrator class
 */
Integrator::Integrator(std::shared_ptr<Camera> camera) : camera(camera) {}

/**
 * PhongLightingIntegrator class
 */
PhongLightingIntegrator::PhongLightingIntegrator(std::shared_ptr<Camera> camera)
    : Integrator(camera) {}

/**
 * render a scene
 * @param[in] the given scene
 */
void PhongLightingIntegrator::render(Scene &scene) {
  int now = 0;
#pragma omp parallel for schedule(guided, 2) default(none) shared(now)
  for (int dx = 0; dx < camera->getFilm().resolution.x(); ++dx) {
#pragma omp atomic
    ++now;
    printf("\r%.02f%%", now * 100.0 / camera->getFilm().resolution.x());
    for (int dy = 0; dy < camera->getFilm().resolution.y(); ++dy) {
      vec3 L(0, 0, 0);

      // TODO: generate camera ray & calculate radiance

      camera->setPixel(dx, dy, L);
    }
  }
}

/**
 * according to phong lighting model
 * calculate the radiance with given scene, ray and interaction
 * @param[in] scene the given scene
 * @param[in] interaction the given interaction
 * @param[in] the given ray
 */
vec3 PhongLightingIntegrator::radiance(Scene &scene,
                                       const Interaction &interaction,
                                       const Ray &ray) const {
  // !!!DELETE THIS WHEN FINISHED
  UNIMPLEMENTED;
  return vec3::Zero();
}

std::shared_ptr<Integrator> makePhongLightingIntegrator(
    std::shared_ptr<Camera> camera) {
  return std::make_shared<PhongLightingIntegrator>(camera);
}