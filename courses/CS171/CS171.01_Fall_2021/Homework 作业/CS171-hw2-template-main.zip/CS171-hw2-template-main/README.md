# Homework 2

Name:  
Student ID:  

**Please write your Chinese name and your student ID in this README.**

## Deadline

**October 24, 2021, 22:00 UTC+8**

## Statement

Refer to [course page](https://faculty.sist.shanghaitech.edu.cn/faculty/liuxp/course/cs171.01/).

## Skeleton Project/ Report Template

The skeleton program and report template will be provided once you accept the assignment link of GitHub classroom which we published in piazza. If you accept the assignment through link properly, a repository which contains the skeleton project and report template will be created under your GitHub account. Please follow the template to prepare your report.

You should complete your assignment submission to your repository through GitHub before the deadline.
