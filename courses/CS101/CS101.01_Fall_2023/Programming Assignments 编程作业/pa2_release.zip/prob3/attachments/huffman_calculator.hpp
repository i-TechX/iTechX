#ifndef HUFFMAN_CALCULATOR_HPP
#define HUFFMAN_CALCULATOR_HPP

#include <tuple>
#include <vector>

size_t get_huffman_length(const std::vector<std::pair<size_t, size_t>> &data) {
  // TODO: Implement this.
  return 0;
}
#endif // HUFFMAN_CALCULATOR_HPP