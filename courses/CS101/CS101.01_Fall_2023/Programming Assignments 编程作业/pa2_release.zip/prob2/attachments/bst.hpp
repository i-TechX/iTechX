#ifndef CS10123F_PA2_BST
#define CS10123F_PA2_BST

#include<vector>
#include<iostream>

//you can do data structure initialization in this function
void init(std::size_t n [[maybe_unused]])
{
    
}

//You can deconstruct your data structure in this function
void clear()
{

}

// opt==1 insert x
// opt==2 erase x
// opt==3 query x
// opt==4 query xth
// opt==5 query x*sum(s1...st) - sum(s_t+1...s_m)
long long SetOperation(std::size_t opt, long long x)
{
    
}



#endif //CS10123F_PA2_BST