Hi! We are glad to see you trying to do this homework with LaTeX.

The main.tex is where we frame this homework, but all
contents are included in other `.tex` files.

- To do question 1, refer to `academic_integrity.tex`.
- For question 2, go to `multiple_choices.tex`.
- For question 3, go to `array_representation.tex`.
- For question 4, go to `vocab.tex`.
- For question 5, go to `car_park.tex`.

We have provided you with tips on where and how to answer the
questions. Please read all the comments in the `.tex` files carefully.

For those who want to submit a handwritten version, please work on `main.pdf` directly.