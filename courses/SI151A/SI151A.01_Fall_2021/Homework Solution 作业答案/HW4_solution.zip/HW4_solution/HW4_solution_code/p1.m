clear;
cvx_clear
clc;


n=100;
eps=1e-6;
prob_matrix=zeros(n,n);
for m=1:n
    for k=1:n
        count=0;
        for i=1:50
            A=randn(m,n);
            x=zeros(n,1);
            index=randi([1,n],k,1);
            x(index)=1;
            y=A*x;
            x_sol=l1_minimization(A,y,n);
            if(norm(x-x_sol)<=eps)
                count=count+1;
            end
        end
        prob=count/50;
        prob_matrix(m,k)=prob;
        disp(['m=',num2str(m),' k=',num2str(k),' prob=',num2str(prob)]);
    end
end
prob_matrix=fliplr(prob_matrix);
imagesc(prob_matrix);


function x = l1_minimization(A,y,N)
    cvx_begin quiet
    variable x(N)
    minimize(norm(x,1))
    subject to 
    A*x==y
    cvx_end
end
