clear;
clc;

load('data.mat');
[m,n] = size(M);
idx = (M~=0);
A = zeros(m,n); 
A(idx) = 1;

cvx_begin sdp
    variable X(m,n) 
    minimize norm_nuc(X)
    subject to 
        M.*A == X.*A;
cvx_end

save('sol1.txt', 'X', '-ascii')