clear;
clc;

load('data.mat');
[m,n] = size(M);
idx = (M~=0);
A = zeros(m,n); 
A(idx) = 1;

cvx_begin sdp
    variable W1(m,m);
    variable W2(n,n);
    variable X(m,n) ;
    minimize 0.5*(trace(W1)+trace(W2));
    subject to 
        [W1 X;X' W2] >= 0;
        M.*A == X.*A;
cvx_end

save('sol2.txt', 'X', '-ascii')