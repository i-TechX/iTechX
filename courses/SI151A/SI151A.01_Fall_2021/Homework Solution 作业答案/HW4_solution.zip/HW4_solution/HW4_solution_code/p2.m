clc 
clear 
tic
K = 50;
n = 3;
targetSINR = -20:0.5:0;
gamma = 10.^(targetSINR/10);
sigma = 1;

ratio = zeros(length(gamma), 1);
times = 20;
for i = 1:length(gamma)
    count = 0;
    for ii = 1:times
%         h = sqrt(1/K/2)*( randn(n,K) + 1j*randn(n,K) );
        h = (normrnd(0, 1/K, [n, K]) + 1j*normrnd(0, 1/K, [n, K]))/sqrt(2);
        status = opt1(h,gamma(i),sigma,n,K);
        if strcmp(status, 'Solved')
            count =  count + 1;
        end
    end
    ratio(i) = count/times
end
plot(targetSINR, ratio, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Target SINR (dB)');
ylabel('R');
toc
function [cvx_status] = opt1(h,gamma,sigma,n,K)
     cvx_begin quiet
        variable w(n,K) complex
        expression temp(K)  
            for i = 1:K
                temp(i) =  norm( w(:,i),2 );
            end 
        minimize 0
        %minimize sum(temp)
        subject to
            for k = 1:K
                norm([h(:, k)'*w, sigma]) <= sqrt(1 + 1/gamma)*real(h(:, k)'*w(:, k));
                real(h(:, k)'*w(:, k)) == h(:, k)'*w(:, k);
                real(h(:, k)'*w(:, k)) >= 0;
            end
    cvx_end
end

