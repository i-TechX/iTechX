%% Data Generation
seed = 97006855;
ss = RandStream('mt19937ar', 'Seed', seed);
RandStream.setGlobalStream(ss);
m = 100;
n = 20;
density = 0.2;
M = sprand(m, n, density);

save('data.mat', 'M');