hw3/prob4/testcases is too large, which Piazza refuses to upload. Contact your TA if you really need it.
