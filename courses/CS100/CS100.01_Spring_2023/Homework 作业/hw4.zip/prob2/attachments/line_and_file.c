#include <stdio.h>

int main(void) {
  printf("%s\n", __FILE__);
  printf("%d\n", __LINE__);
  printf("%d\n", __LINE__);
  printf("%d\n", __LINE__);
  printf("%d\n", __LINE__);
  return 0;
}