#ifndef NAMED_CONTAINER_HPP_
#define NAMED_CONTAINER_HPP_

#include <string>

template<typename T>
class NamedContainer {
public:
  NamedContainer( const std::string & name );
  virtual ~NamedContainer();

  virtual void push_back( const T& value ) = 0;
  virtual T& at( unsigned int index ) = 0;
  virtual const T& at( unsigned int index ) const = 0;
  virtual int size() const = 0;

  std::string& name();
  const std::string& name() const;

protected:
  std::string _s_name;
};

#include "NamedContainer_impl.hpp"

#endif