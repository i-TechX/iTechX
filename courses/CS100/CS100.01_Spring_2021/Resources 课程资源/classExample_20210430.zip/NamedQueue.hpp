#ifndef NAMED_QUEUE_HPP_
#define NAMED_QUEUE_HPP_

#include "NamedContainer.hpp"
#include <deque>

template<typename T>
class NamedQueue : public NamedContainer<T> {
public:
  NamedQueue( const std::string& name );
  virtual ~NamedQueue();

  virtual void push_back( const T& value );
  virtual T& at( unsigned int index );
  virtual const T& at( unsigned int index ) const;
  virtual int size() const;

private:
  std::deque<T> _data;
};

#include "NamedQueue_impl.hpp"
#endif