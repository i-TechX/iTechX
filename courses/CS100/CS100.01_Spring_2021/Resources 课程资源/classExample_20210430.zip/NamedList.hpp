#ifndef NAMED_LIST_HPP_
#define NAMED_LIST_HPP_

#include "NamedContainer.hpp"
#include <list>

template<typename T>
class NamedList : public NamedContainer<T> {
public:
  NamedList( const std::string& name );
  virtual ~NamedList();

  virtual void push_back( const T& value );
  virtual T& at( unsigned int index );
  virtual const T& at( unsigned int index ) const;
  virtual int size() const;

private:
  std::list<T> _data;
};

#include "NamedList_impl.hpp"

#endif