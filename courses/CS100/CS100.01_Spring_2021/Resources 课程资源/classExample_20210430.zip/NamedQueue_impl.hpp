#include <iostream>

template<typename T>
NamedQueue<T>::NamedQueue( const std::string & name ) : NamedContainer<T>(name)
{}

template<typename T>
NamedQueue<T>::~NamedQueue()
{}

template<typename T>
void
NamedQueue<T>::push_back( const T& value ) {
  _data.push_back(value);
}

template<typename T>
T&
NamedQueue<T>::at( unsigned int index ) {
  if( index >= _data.size() ) {
    std::cout << "Error in named vector " << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  typename std::deque<T>::iterator it = _data.begin();
  for( int i = 0; i < index; i++ )
    it++;
  return *it;
}

template<typename T>
const T&
NamedQueue<T>::at( unsigned int index ) const {
  if( index >= _data.size() ) {
    std::cout << "Error in named vector " << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  typename std::deque<T>::const_iterator it = _data.begin();
  for( int i = 0; i < index; i++ )
    it++;
  return *it;
}

template<typename T>
int
NamedQueue<T>::size() const {
  return _data.size();
}