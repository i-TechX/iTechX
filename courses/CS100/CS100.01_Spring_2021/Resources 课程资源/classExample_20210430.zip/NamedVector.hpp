#ifndef NAMED_VECTOR_HPP_
#define NAMED_VECTOR_HPP_

#include "NamedContainer.hpp"
#include <vector>

template<typename T>
class NamedVector : public NamedContainer<T> {
public:
  NamedVector( const std::string& name );
  virtual ~NamedVector();

  virtual void push_back( const T& value );
  virtual T& at( unsigned int index );
  virtual const T& at( unsigned int index ) const;
  virtual int size() const;

private:
  std::vector<T> _data;
};

#include "NamedVector_impl.hpp"
#endif