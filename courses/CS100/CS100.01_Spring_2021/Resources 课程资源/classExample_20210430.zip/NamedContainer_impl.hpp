template<typename T>
NamedContainer<T>::NamedContainer( const std::string& name ) {
  _s_name = name;
}

template<typename T>
NamedContainer<T>::~NamedContainer()
{}

template<typename T>
std::string&
NamedContainer<T>::name() {
  return _s_name;
}

template<typename T>
const std::string&
NamedContainer<T>::name() const {
  return _s_name;
}