#include <iostream>

template<typename T>
NamedVector<T>::NamedVector( const std::string & name ) : NamedContainer<T>(name)
{}

template<typename T>
NamedVector<T>::~NamedVector()
{}

template<typename T>
void
NamedVector<T>::push_back( const T& value ) {
  _data.push_back(value);
}

template<typename T>
T&
NamedVector<T>::at( unsigned int index ) {
  if( index >= _data.size() ) {
    std::cout << "Error in named vector " << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  return _data.at(index);
}

template<typename T>
const T&
NamedVector<T>::at( unsigned int index ) const {
  if( index >= _data.size() ) {
    std::cout << "Error in named vector " << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  return _data.at(index);
}

template<typename T>
int
NamedVector<T>::size() const {
  return _data.size();
}