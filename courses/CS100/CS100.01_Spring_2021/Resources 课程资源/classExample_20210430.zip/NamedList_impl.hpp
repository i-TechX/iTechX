#include <iostream>

template<typename T>
NamedList<T>::NamedList( const std::string & name ) : NamedContainer<T>(name)
{}

template<typename T>
NamedList<T>::~NamedList()
{}

template<typename T>
void
NamedList<T>::push_back( const T& value ) {
  _data.push_back(value);
}

template<typename T>
T&
NamedList<T>::at( unsigned int index ) {
  if( index >= _data.size() ) {
    std::cout << "Error in named list:" << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  typename std::list<T>::iterator it = _data.begin();
  for( int i = 0; i < index; i++ )
    it++;
  return *it;
}

template<typename T>
const T&
NamedList<T>::at( unsigned int index ) const {
  if( index >= _data.size() ) {
    std::cout << "Error in named list:" << this->_s_name << ": Attempted access beyond container size\n";
    return *(_data.begin());
  }
  typename std::list<T>::const_iterator it = _data.begin();
  for( int i = 0; i < index; i++ )
    it++;
  return *it;
}

template<typename T>
int
NamedList<T>::size() const {
  return _data.size();
}