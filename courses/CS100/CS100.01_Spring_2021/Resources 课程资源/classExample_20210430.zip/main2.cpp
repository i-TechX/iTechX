#include <stdlib.h>
#include <iostream>
#include <sys/time.h>

int main() {
  struct timeval tic;
  gettimeofday( &tic, 0 );
  srand ( tic.tv_usec );

  for( int i = 0; i < 1000; i++ ) {
    std::cout << rand() % 100 << " ";
  }
  std::cout << std::endl;
}