//Description of problem:
//
//Make a program that can treat an arbitrary number of STL containers homogeneously,
//no matter if they are a vector, a list, or a map.
//For this, you will need to define an abstract base class for the containers.
//The containers should be stored in a map and furthermore need to be named by the name of the file they are loaded from.
//The main routine should then interact with the user and enable the user to load files
//held with a specified data structure, print their content, list open files, or close individual ones or all of them.
//It should also enable the user to count the occurrence of a certain string across a single or across all open documents.
//
//The program makes use of the following language features
//
//classes (aggregation)
//inheritance
//polymorphism, virtualization
//overloading, Overwriting
//vector, list, deque
//references
//const-correctness
//namespaces
//console I/O, file reading
//dynamic memory allocation

#include "NamedContainer.hpp"
#include "NamedList.hpp"
#include "NamedVector.hpp"
#include "NamedQueue.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <map>

void clear( std::map<std::string,NamedContainer<std::string>*> & openDocs ) {
  std::map<std::string,NamedContainer<std::string>*>::const_iterator it;
  for(it = openDocs.begin();it != openDocs.end(); it++)
    delete it->second;
  openDocs.clear();
}

void print( const NamedContainer<std::string>* container ) {
  for( int i = 0; i < container->size(); i++ )
    std::cout << container->at(i) << " ";
  std::cout << "\n";
}

unsigned int count( const NamedContainer<std::string>* container, const std::string & tag ) {
  unsigned int wc = 0;
  for( int i = 0; i < container->size(); i++ ) {
    if( container->at(i) == tag )
      wc++;
  }
  return wc;
}

int main() {

  std::cout << "\nWelcome to file-handler 1.0!\n\n";
  std::map<std::string,NamedContainer<std::string>*> openDocs;
  bool running = true;

  do {
    std::cout << "\n";
    std::cout << "Please enter your next command! Options are:\n";
    std::cout << "1) load [vector/list/queue] [PATHTOFILE]\n";
    std::cout << "2) print\n";
    std::cout << "3) print [NAME]\n";
    std::cout << "4) close [NAME]\n";
    std::cout << "5) clear\n";
    std::cout << "6) wc [TAG]\n";
    std::cout << "7) wc [TAG] [NAME]\n";
    std::cout << "8) exit\n\n";

    std::vector<std::string> cmd;
    std::string buffer;
    std::getline(std::cin, buffer);
    std::stringstream ss(buffer);
    std::string buffer2;
    while( ss >> buffer2 )
      cmd.push_back(buffer2);

    switch(cmd.size()) {
      case 1: { //for one argument commands
        if( cmd[0] == "exit" ) {
          clear(openDocs);
          return 0;
        } else if( cmd[0] == "clear" ) {
          clear(openDocs);
        } else if( cmd[0] == "print" ) {
          std::map<std::string,NamedContainer<std::string>*>::iterator it;
          for(it = openDocs.begin();it != openDocs.end(); it++)
            std::cout << it->first << "\n";
        } else {
          std::cout << "Unrecognized command, ignoring it!\n";
        }
        break;
      }
      case 2: { //for two argument commands
        if( cmd[0] == "print" ) {
          std::map<std::string,NamedContainer<std::string>*>::iterator it = openDocs.find(cmd[1]);
          if( it != openDocs.end() ) {
            print( it->second );
          } else {
            std::cout << "Cannot find document named " << cmd[1] << " for printing!\n";
          }
        } else if ( cmd[0] == "close" ) {
          std::map<std::string,NamedContainer<std::string>*>::iterator it = openDocs.find(cmd[1]);
          if( it != openDocs.end() ) {
            openDocs.erase(it);
          } else {
            std::cout << "Cannot find document named " << cmd[1] << " for closing!\n";
          }
        } else if ( cmd[0] == "wc" ) {
          std::map<std::string,NamedContainer<std::string>*>::iterator it;
          unsigned int counter = 0;
          for(it = openDocs.begin();it != openDocs.end(); it++)
            counter += count(it->second,cmd[1]);
          std::cout << "Documents have " << counter;
          std::cout << " occurences of the tag " << cmd[1] << "\n";
        } else {
          std::cout << "Unrecognized command, ignoring it!\n";
        }
        break;
      }
      case 3: { //for three argument commands
        if( cmd[0] == "wc" ) {
          std::map<std::string,NamedContainer<std::string>*>::iterator it = openDocs.find(cmd[2]);
          if( it != openDocs.end() ) {
            std::cout << "Document named " << it->first << " has ";
            std::cout << count(it->second,cmd[1]) << " occurences of the tag " << cmd[1] << "\n";
          } else {
            std::cout << "Cannot find document named " << cmd[1] << " for word count!\n";
          }
        } else if( cmd[0] == "load" ) {
          NamedContainer<std::string>* newContainer = NULL;
          if( cmd[1] == "vector" ) {
            newContainer = new NamedVector<std::string>(cmd[2]);
          } else if( cmd[1] == "list" ) {
            newContainer = new NamedList<std::string>(cmd[2]);
          } else if( cmd[1] == "queue" ) {
            newContainer = new NamedQueue<std::string>(cmd[2]);
          } else {
            std::cout << "Unrecognized container type!\n";
          }
          if( newContainer != NULL ) {
            //attempt to open the file for reading
            std::ifstream inStream;
            inStream.open(cmd[2]);
            if(!inStream) {
              delete newContainer;
              std::cout << "File not found, ignoring command!\n";
            } else {
              std::string buffer;
              while( inStream >> buffer )
                newContainer->push_back(buffer);
              openDocs[cmd[2]] = newContainer;
            }
          } else {
            std::cout << "Unrecognized command, ignoring it!\n";
          }
        } else {
          std::cout << "Unrecognized command, ignoring it!\n";
        }
        break;
      }
      default: {
        std::cout << "Unrecognized command, ignoring it!\n";
        break;
      }
    }
  } while(running);

  return 0;
}