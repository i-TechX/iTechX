#include <iostream>
#include <fstream>
#include <sstream>

int main() {
  std::ifstream inStream;
  inStream.open("data0.txt");
  if( !inStream )
    return -1;

  while( inStream.good() ) {
    std::string oneLine;
    std::getline( inStream, oneLine );
    std::stringstream lineStm(oneLine);

    while( lineStm.good() ) {
      std::string copy;
      lineStm >> copy;
      std::cout << copy << " ";
    }
    std::cout << "\n";
  }
}