#include <stdio.h>
#include <stdlib.h>

void FindSecondMaxAndMin(int* secondMax, int* secondMin)
{
    // YOUR CODE STARTS HERE
    
    // YOUR CODE ENDS HERE
}

int main()
{
    int secondMax, secondMin;
    FindSecondMaxAndMin(&secondMax, &secondMin);
    printf ("%d %d\n", secondMax, secondMin);
    return 0;
}