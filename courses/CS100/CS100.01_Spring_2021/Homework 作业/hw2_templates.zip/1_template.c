#include <stdio.h>

int ColorMap(float minVal, float maxVal, int maxValColor, float val)
{
    // YOUR CODE STARTS HERE

    // YOUR CODE ENDS HERE
}

int main()
{
    float minVal, maxVal, val;
    int maxValColor;
    scanf("%f %f %x %f", &minVal, &maxVal, &maxValColor, &val);
    int color = ColorMap(minVal, maxVal, maxValColor, val);
    printf ("0x%x\n", color);
    return 0;
}
