#include <iostream>
#include <string>

class ReportParser
{
public:
    ReportParser(int numStudents, int numProblems);
    ~ReportParser();
    void readReport();
    void writeStructuredReport();
private:
    // Your additional declarations here
};


// DO NOT modify the main function
int main()
{
    int n, m;
    std::cin >> n >> m;
    getchar();
    ReportParser a(n, m);
    a.readReport();
    a.writeStructuredReport();
    return 0;
}
