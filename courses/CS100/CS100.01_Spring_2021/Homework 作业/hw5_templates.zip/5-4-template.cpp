#include <iostream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

class Alarm
{
public:
    // constructors and destructor

    // other functions
    virtual void Trigger() = 0;

protected:
    // member variables are protected to let child classes access them.

};

class RepeatableAlarm;

class SnoozeableAlarm;

class AlarmClock
{
public:
    // constructors and destructor

    // other functions
    void AddAlarm(Alarm* alarm);
    void TimeElapse();
    
private:
    // a container of Alarm*

    // other member variables

};

/**************** Implementations ******************/
void AlarmClock::AddAlarm(Alarm* alarm)
{

}

void AlarmClock::TimeElapse()
{

}

/**************** Input function ******************/
void Input(AlarmClock& clock)
{

}

int main()
{
    AlarmClock clock;
    for(int days = 0; days < 3; days++)
    {
        cout << "Do you want to add any alarms?" << endl;
        Input(clock);
        for(int minute = 0; minute < 24*60; minute++)
        {
            clock.TimeElapse();
        }
        cout << "A day has elapsed." << endl;
    }
}
