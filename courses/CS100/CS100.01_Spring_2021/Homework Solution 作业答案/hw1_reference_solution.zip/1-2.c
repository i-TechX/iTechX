#include <stdio.h>

int main(){
    int num;
    int hospital = 0;
    float mood = 100.0f;
    int beginh, endh, beginm, endm, currh = 8, currm = 0;
    printf("How many lectures today?\n");
    scanf("%d", &num);
    for(int i = 0; i < num; i++)
    {
        scanf("%d:%d-%d:%d", &beginh, &beginm, &endh, &endm);
        
        // recover until lecture starts
        mood += 0.5*((beginh - currh)*60 + (beginm - currm));
        if(mood > 100.0) mood = 100.0;
        
        // calculate mood loss during lecture
        currh = beginh, currm = beginm;
        int duration = ((endh - currh)*60 + (endm - currm));
        if(duration <= 60) mood -= 0.4*duration;
        if(duration >  60) mood -= (24 + 0.8*(duration - 60));
        if(mood <= 0) hospital = 1;
        
        currh = endh, currm = endm;
    }

    // recover until the day ends
    mood += 0.5*((22 - currh)*60 + (0 - currm));
    if(mood > 100.0) mood = 100.0;

    if(hospital) 
        printf("Gezi Wang has been sent to hospital.\n");
    else
        printf("His mood level is %.1f at the end of the day.", mood);
}