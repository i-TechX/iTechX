#include <stdio.h>
#include <math.h>

int main(){
    int num;
    scanf("%x", &num); // "0x%x" also fine
    float result = 0.0f;

    // fraction part
    for (int i = 0; i < 24; i++)
    {
        if(num & 0x1) result += 1.0f;
        result /= 2;
        num >>= 1;
    }
    
    // 0.fraction + 1
    result += 1.0f;

    // exponent part    
    result *= pow(2, (num & 0b1111111) - 63);
    
    // the sign bit
    if((num >> 7) & 0x1) result = -result;
    
    printf("The number converts to %f\n", result);
}
