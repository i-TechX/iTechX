#include <stdio.h> // missing include line

int main() // misspelled main
{
    int numTotalStudents, numSatisfied; // use comma between variables 
    float satisfiedRatio; // need to be stored in float

    printf("How many students went to the new dining hall?\n");
    scanf("%d", &numTotalStudents); // missing '&' in scanf
    printf("How many of them are satisfied?\n");
    scanf("%d", &numSatisfied); // missing '&' in scanf

    // check zero division before 0 gets divided
        /* It's true, however, that (float)0/0 does not raise an error but returns "inf".
         * If you intend to check zero division with this feature,
         * it's okay to leave the following lines where they originally are.
         * However, modifications are needed when checking bounds. 
         * > 0.5f should change to > 0.5f && < 1.0f, and same for <.  
         * */
    if(numTotalStudents == 0) // In case if it divides by zero
    {
        printf("No one went to the dining hall?\n");
    }

    satisfiedRatio = (float) numSatisfied / numTotalStudents; // int divisions return int only

    // Prints different messages according to the ratio!
    if(satisfiedRatio == 0.5f) // "==", not "="
    {
        printf("Exactly half of the students are satisfied!\n");
    }
    else if(satisfiedRatio > 0.5f)
    {
        printf("More students are satisfied! :)\n");
    }
    else if(satisfiedRatio < 0.5f)
    {
        printf("More students are unsatisfied! :(\n");
    }
    return 0;
}

