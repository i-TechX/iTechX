#include <stdio.h>

void DrawSquare(int size)
{
    for(int i = 0; i < size; i++)
    {
        if(i == size - 1 || i == 0)
        {
            for(int j = 0; j < size; j++){
                putchar('*');
            }
        }
        else
        {
            putchar('*');
            for(int j = 0; j < size - 2; j++)
                putchar(' ');
            putchar('*');
        }
        putchar('\n');
    }
}

void DrawDiamond(int size)
{    
    for(int i = 0; i < size; i++)
    {
        if(i == 0)
        {
            for(int j = 0; j < size - 1; j++)
                putchar(' ');
            putchar('*');
        }
        else
        {
            for(int j = 0; j < size - 1 - i; j++)
                putchar(' ');
            putchar('*');
            
            for(int j = 0; j < 2 * i - 1; j++)
                putchar(' ');
            putchar('*');
        }
        putchar('\n');
    }

    for(int i = size - 2; i >= 0; i--)
    {
        if(i == 0)
        {
            for(int j = 0; j < size - 1; j++)
                putchar(' ');
            putchar('*');
        }
        else
        {
            for(int j = 0; j < size - 1 - i; j++)
                putchar(' ');
            putchar('*');
            
            for(int j = 0; j < 2 * i - 1; j++)
                putchar(' ');
            putchar('*');
        }
        putchar('\n');
    }

    
}

void DrawHexagon(int size)
{
    for(int i = 0; i < size; i++)
    {
        if(i == 0)
        {
            for(int j = 0; j < size - 1; j++)
                putchar(' ');
            for(int j = 0; j < size; j++)
                putchar('*');
        }
        else
        {
            for(int j = 0; j < size - 1 - i; j++)
                putchar(' ');
            putchar('*');
            
            for(int j = 0; j < 2 * i + size - 2; j++)
                putchar(' ');
            putchar('*');
        }
        putchar('\n');
    }
    for(int i = size - 2; i >= 0; i--)
    {
        if(i == 0)
        {
            for(int j = 0; j < size - 1; j++)
                putchar(' ');
            for(int j = 0; j < size; j++)
                putchar('*');
        }
        else
        {
            for(int j = 0; j < size - 1 - i; j++)
                putchar(' ');
            putchar('*');
            
            for(int j = 0; j < 2 * i + size - 2; j++)
                putchar(' ');
            putchar('*');
        }
        putchar('\n');
    }

}

int main()
{
    int shape, size;
    scanf("%d %d", &shape, &size);
    
    // 1 for square, 2 for diamond, 3 for hexagon.
    switch(shape){
    case 1:
        DrawSquare(size);
        break;
    case 2:
        DrawDiamond(size);
        break;
    case 3:
        DrawHexagon(size);
        break;
    default:
        return -1;
    }
    return 0;
}
