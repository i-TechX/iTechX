/* This function is used for compare two tiles
 * the order of sorted array is [1-9]m, [1-9]p, [1-9]s, [1-7]z
 */
int cmp(const void* ss1, const void* ss2)
{
    char* s1 = *(char**)ss1, *s2 = *(char**)ss2;
    char buf1[2], buf2[2];
    buf1[0] = s1[1], buf1[1] = s1[0], buf2[0] = s2[1], buf2[1] = s2[0];
    return strcmp(buf1, buf2);
}

/* This function will check `n` cards recursively
 * Each time it will find a chow or pung, and check
 * other cards by recursion, until only 2 cards remain.
 */
int CheckWinHelper(char* hand[], int n)
{
    // If only 2 tiles, just check if it's a pair
    if (n == 2)
        return strcmp(hand[0], hand[1]) == 0;
    
    // More than 2 tiles
    for (int i = 0; i < n - 2; i++)
    {
        // If a PUNG is found
        if (strcmp(hand[i], hand[i + 1]) == 0 && strcmp(hand[i + 1], hand[i + 2]) == 0)
        {     
            char* tmp[n - 3];
            int k = 0;
            // Add other tiles to `tmp`
            for (int j = 0; j < n; j++)
                if (j != i && j != i + 1 && j != i + 2) tmp[k++] = hand[j];
            if (CheckWinHelper(tmp, n - 3) == 1) // Check recursively
                return 1;
        }
        else // Try to find a CHEW
        {
            // `i1`, `i2`, `i3` is the indexs of 3 different tiles
            int i2 = i + 1;
            while (i2 < n && strcmp(hand[i], hand[i2]) == 0)
                i2++;
            int i3 = i2 + 1;
            while (i3 < n && strcmp(hand[i2], hand[i3]) == 0)
                i3++;
            // Check whether hand[i1], hand[i2] and hand[i3] is a CHEW
            if (i < n && i2 < n && i3 < n && hand[i][1] == hand[i2][1] && hand[i2][1] == hand[i3][1] \
                && hand[i][0] + 1 == hand[i2][0] && hand[i2][0] + 1 == hand[i3][0] && hand[i][1] != 'z')
            {
                char* tmp[n - 3];
                int k = 0;
                // Add other tiles to `tmp`
                for (int j = 0; j < n; j++)
                    if (j != i && j != i2 && j != i3) tmp[k++] = hand[j]; // Check recursively
                if (CheckWinHelper(tmp, n - 3) == 1)
                    return 1;
            }            
        }

    }
    return 0;
}

int CheckWin(char* mahjongHand[])
{
    // `qsort` is the sort function provided by `stdlib.h`
    qsort(mahjongHand, 14, sizeof(char*), cmp);
    int i = 0, j = 0;
    // Check if there are more than 4 identical tiles.
    while (i < 14 && j < 14)
    {
        int tmp = 0;
        while (j < 14 && strcmp(mahjongHand[i], mahjongHand[j]) == 0)
            j++, tmp++;
        if (tmp > 4) return 0;
        i = j;
    }
    return CheckWinHelper(mahjongHand, 14);
}

/* Traverse all tiles and check if `currentTiles` + `THIS_TILE`
 * is a win state. count all such tiles.
 */
int CountWaitingTiles(char* currentTiles[])
{
    int res = 0;
    char** buf = malloc(sizeof(char*) * 14);
    for (int i = 0; i < 14; i++) buf[i] = malloc(sizeof(char) * 2);
    char types[4] = "smpz";
    for (int t = 0; t < 4; t++)
    {
        for (int i = 1; i < 10; i++)
        {
            if (t == 3 && i > 7)
                continue;
            for (int ii = 0; ii < 13; ii++)
                strcpy(buf[ii], currentTiles[ii]);
            buf[13][0] = i + '0', buf[13][1] = types[t];
            if (CheckWin((char**)buf) == 1) 
                res++;
        }        
    }
    for (int i = 0; i < 14; i++) free(buf[i]);
    free(buf);
    return res;
}
