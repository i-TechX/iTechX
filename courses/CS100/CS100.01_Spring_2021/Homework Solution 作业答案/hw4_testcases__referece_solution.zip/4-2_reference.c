typedef struct _node
{
    int value;
    struct _node* next;
}Node;

typedef struct _linkedlist
{
    Node* head;
    Node* tail;
    int   size;
} LinkedList;

void list_init(LinkedList* l)
{
    // Initial size = 0, head = tail = NULL
    l->size = 0;
    l->head = NULL;
    l->tail = NULL;
}


void list_insert(LinkedList* l,int val)
{
    Node* node = (Node*)malloc(sizeof(Node));
    node->value = val;
    // If the list is empty
    if (l->size == 0)
    {
        l->head = node;
        l->tail = node;
        node->next = NULL;
    }
    else // Not empty
    {
        l->tail->next = node;
        l->tail = l->tail->next;
        node->next = NULL;
    }
    l->size ++;
}

void list_clear(LinkedList* l)
{
    if (!l || l->size == 0) 
        return;
    Node* iter = l->head;
    while (iter->next != NULL)
    {
        iter = iter->next;
        free(l->head);
        l->head = iter;
    }
    free(l->head);
    l->head = NULL;
    l->tail = NULL;
    l->size = 0;
}

Node* list_remove(LinkedList* l, Node* target)
{
    if (!l || l->size == 0 || target == NULL)
        return NULL;
    // If this node is both head & tail
    if (l->head == target && l->tail == target)
    {
        free(l->head);
        l->head = NULL;
        l->tail = NULL;
        l->size--;
        return NULL;
    }
    // Remove head
    else if (l->head == target)
    {
        Node* head_next = l->head->next;
        Node* tmp = l->head;
        free(tmp);
        l->head = head_next;
        l->size--;
        return head_next;
    }
    // remove tail
    else if (l->tail == target)
    {
        // Remove tail
        l->size--;
        Node* iter = l->head;
        while(iter->next != l->tail) iter = iter->next;
        free(l->tail);
        l->tail = iter;
        iter->next = NULL;
        return NULL;
    }
    // Remove interiors
    else
    {
        Node* prev = l->head;
        Node* curr = l->head->next;
        while (curr != NULL && curr != target)
        {
            curr = curr->next;
            prev = prev->next;
        }
        if (curr == NULL) return NULL;
        Node* del = curr;
        curr = curr->next;
        prev->next = curr;
        free(del);
        l->size--;
        return curr;
    }
}
