#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define main __Student__Main_Function_
#define _ONLINE_JUDGE

// INSERT YOUR CODE BELOW

// INSERT YOUR CODE ABOVE

#ifdef OJ_assert
#undef OJ_assert
#endif
#define OJ_assert(stmt) { if (!(stmt)) { printf("Wrong answer!\n"); return 0; } }

#undef main

int main() 
{
    int tcase;
    scanf("%d", &tcase);
    switch(tcase)
    {
        case 1: // Ghost on an empty cell
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddGhost(g, 3, 5, left) == true);
            OJ_assert(AddGhost(g, 2, 1, up) == true);
            OJ_assert(g->grid[2][1] == '@');
            OJ_assert(g->grid[3][5] == '@');
            OJ_assert(AddFood(g, 3, 5) == false);
            break;
        }
        case 2: // Ghost at invalid places
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddGhost(g, 8, 10, left) == false);
            OJ_assert(AddWall(g, 2, 1) == true);
            OJ_assert(AddGhost(g, 2, 1, up) == false);
            OJ_assert(AddPacman(g, 3, 5) == true);
            OJ_assert(AddGhost(g, 3, 5, down) == false);
            OJ_assert(g->grid[2][1] != '@');
            OJ_assert(g->grid[3][5] != '@');
            break;
        }
        case 3: // Ghost on foods
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddGhost(g, 3, 5, left) == true);
            OJ_assert(AddFood(g, 2, 1) == true);
            for(int i = 0; i < 10; i++){
                OJ_assert(AddFood(g, 4, i) == true);
            }
            OJ_assert(g->foodCount == 11);
            OJ_assert(AddGhost(g, 2, 1, up) == true);
            OJ_assert(g->grid[2][1] == '@');
            OJ_assert(g->foodCount == 11);
            OJ_assert(g->grid[3][5] == '@');
            OJ_assert(AddFood(g, 3, 5) == false);
            break;
        }
        case 4: // Move ghosts on an empty board
        {
            Game* g = NewGame(6, 6);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddGhost(g, 4, 2, left) == true);
            MoveGhosts(g);
            OJ_assert(g->grid[3][5] == '@');
            OJ_assert(g->grid[4][1] == '@');
            OJ_assert(g->grid[3][4] != '@');
            OJ_assert(g->grid[4][2] != '@');

            MoveGhosts(g);
            OJ_assert(g->grid[3][4] == '@');
            OJ_assert(g->grid[4][0] == '@');
            OJ_assert(g->grid[3][5] != '@');
            OJ_assert(g->grid[4][1] != '@');

            MoveGhosts(g);
            OJ_assert(g->grid[3][3] == '@');
            OJ_assert(g->grid[4][1] == '@');
            OJ_assert(g->grid[3][4] != '@');
            OJ_assert(g->grid[3][5] != '@');
            OJ_assert(g->grid[4][0] != '@');
            OJ_assert(g->grid[4][2] != '@');

            break;
        }
        case 5: // Losing the game
        /* Note: sorry that we created multiple games in a single test.
         * Some students using global variables are suffering,
         * as they forget to clear their globals, resulting in data from
         * former games to be carried into later games.
         * 
         * However, such use of global variables are not recommended,
         * as such data should be stored as members of Game structure.
         * Again, it's not a good practice in OOP to use global variables. 
         */
        {
            // Pacman bumps into a ghost
            Game* g = NewGame(6, 6);
            OJ_assert(AddFood(g, 0, 0) == true);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddGhost(g, 4, 2, left) == true);
            OJ_assert(AddPacman(g, 2, 4) == true);
            MovePacman(g, down);
            OJ_assert(g->grid[3][4] == '@');
            OJ_assert(g->state == losing);
            EndGame(g);

            // Ghost kills Pacman
            g = NewGame(6, 6);
            OJ_assert(AddFood(g, 0, 0) == true);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddGhost(g, 4, 2, left) == true);
            OJ_assert(AddPacman(g, 3, 5) == true);
            MovePacman(g, idle);
            OJ_assert(g->state != losing);
            MoveGhosts(g);
            OJ_assert(g->grid[3][5] == '@');
            OJ_assert(g->state == losing);
            EndGame(g);

            // They move towards a same grid
            g = NewGame(6, 6);
            OJ_assert(AddFood(g, 0, 0) == true);
            OJ_assert(AddGhost(g, 3, 5, right) == true);
            OJ_assert(AddGhost(g, 4, 2, left) == true);
            OJ_assert(AddPacman(g, 2, 4) == true);
            MovePacman(g, down);
            OJ_assert(g->state != losing);
            MoveGhosts(g);
            OJ_assert(g->grid[3][4] == '@');
            OJ_assert(g->state == losing);
			EndGame(g);
            break;
        }
        case 6: // Ghost moving on foods
        {
            Game* g = NewGame(6, 6);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddFood(g, 3, 1) == true);
            OJ_assert(AddFood(g, 3, 3) == true);
            OJ_assert(AddFood(g, 3, 5) == true);
            OJ_assert(AddFood(g, 4, 1) == true);
            OJ_assert(AddFood(g, 5, 1) == true);
            OJ_assert(AddGhost(g, 4, 1, down) == true);
            OJ_assert(g->foodCount == 5);
            /* ______
              |      |
              |      |
              |      |
              | . .@.|
              | @    |
              | .    |
              \------/
            */

            MoveGhosts(g);
            /* ______
              |      |
              |      |
              |      |
              | . . @|
              | .    |
              | @    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][5] == '@' && g->grid[5][1] == '@');
            OJ_assert(g->grid[3][4] == ' ' && g->grid[4][1] == '.');
            OJ_assert(g->grid[3][1] == '.' && g->grid[3][3] == '.');

            MoveGhosts(g);
            /* ______
              |      |
              |      |
              |      |
              | . .@.|
              | @    |
              | .    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][4] == '@' && g->grid[4][1] == '@');
            OJ_assert(g->grid[3][5] == '.' && g->grid[5][1] == '.');
            OJ_assert(g->grid[3][1] == '.' && g->grid[3][3] == '.');

            MoveGhosts(g);
            /* ______
              |      |
              |      |
              |      |
              | @ @ .|
              | .    |
              | .    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][3] == '@' && g->grid[3][1] == '@');
            OJ_assert(g->grid[3][4] == ' ' && g->grid[4][1] == '.');
            OJ_assert(g->grid[5][1] == '.' && g->grid[3][5] == '.');

            MoveGhosts(g);
            /* ______
              |      |
              |      |
              | @    |
              | .@. .|
              | .    |
              | .    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][2] == '@' && g->grid[2][1] == '@');
            OJ_assert(g->grid[3][3] == '.' && g->grid[3][1] == '.');

            MoveGhosts(g);
            /* ______
              |      |
              | @    |
              |      |
              | @ . .|
              | .    |
              | .    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][1] == '@' && g->grid[1][1] == '@');
            OJ_assert(g->grid[3][2] == ' ' && g->grid[2][1] == ' ');

            break;
        }
        case 7: // Ghost hitting walls and ghosts
        {
            Game* g = NewGame(6, 6);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddGhost(g, 5, 4, up) == true);
            OJ_assert(AddWall(g, 3, 3) == true);

            OJ_assert(AddFood(g, 3, 1) == true);
            OJ_assert(AddFood(g, 3, 5) == true);
            OJ_assert(AddFood(g, 4, 1) == true);
            OJ_assert(AddFood(g, 5, 1) == true);
            OJ_assert(AddFood(g, 0, 0) == true);
            
            OJ_assert(AddGhost(g, 2, 2, right) == true);
            OJ_assert(AddGhost(g, 4, 1, down) == true);
            OJ_assert(AddWall(g, 2, 3) == true)
            OJ_assert(g->foodCount == 5);
            /* ______
              |.     |
              |      |
              |  @#  |
              | . #@.|
              | @    |
              | .  @ |
              \------/
            */

            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              | @ #  |
              | . # @|
              | .  @ |
              | @    |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][5] == '@' && g->grid[5][1] == '@' && g->grid[4][4] == '@' && g->grid[2][1] == '@');

            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              |@  #  |
              | . #@.|
              | @    |
              | .  @ |
              \------/
            */
            OJ_assert(g->foodCount == 5);
            OJ_assert(g->grid[3][4] == '@' && g->grid[4][1] == '@' && g->grid[5][4] == '@' && g->grid[2][0] == '@');
            OJ_assert(g->grid[3][5] == '.' && g->grid[5][1] == '.');

            MoveGhosts(g);
            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              | @@#  |
              | . #@.|
              | .    |
              | .  @ |
              \------/
            */
            OJ_assert(g->grid[2][1] == '@' && g->grid[2][2] == '@' && g->grid[2][0] != '@');

            MoveGhosts(g);
            /* ______
              |.     |
              | @    |
              |  @#  |
              | . # @|
              | .  @ |
              | .    |
              \------/
            */
            OJ_assert(g->grid[1][1] == '@' && g->grid[2][2] == '@' && g->grid[2][1] != '@');
            MoveGhosts(g);
            /* ______
              |.@    |
              |      |
              | @ #  |
              | . #@.|
              | .    |
              | .  @ |
              \------/
            */
            OJ_assert(g->grid[0][1] == '@' && g->grid[2][1] == '@');


            break;
        }
        case 8: // multiple collisions
        {            
            Game* g = NewGame(6, 6);
            OJ_assert(AddGhost(g, 3, 2, right) == true);
            OJ_assert(AddGhost(g, 3, 1, up) == true);
            OJ_assert(AddWall(g, 3, 3) == true);
            OJ_assert(AddWall(g, 4, 1) == true);
            OJ_assert(AddWall(g, 1, 1) == true);
            /* ______
              |      |
              | #    |
              |      |
              | @@#  |
              | #    |
              |      |
              \------/
            */

            MoveGhosts(g);
            /* ______
              |      |
              | #    |
              | @    |
              |  @#  |
              | #    |
              |      |
              \------/
            */
            OJ_assert(g->grid[2][1] == '@' && g->grid[3][2] == '@' && g->grid[3][1] == ' ');

            MoveGhosts(g);
            /* ______
              |      |
              | #    |
              | @    |
              | @ #  |
              | #    |
              |      |
              \------/
            */
            OJ_assert(g->grid[2][1] == '@' && g->grid[3][1] == '@');

            MoveGhosts(g);
            /* ______
              |      |
              | #    |
              |      |
              |@@ #  |
              | #    |
              |      |
              \------/
            */
            OJ_assert(g->grid[3][1] == '@' && g->grid[3][0] == '@');
            
            MoveGhosts(g);
            /* ______
              |      |
              | #    |
              | @    |
              |@  #  |
              | #    |
              |      |
              \------/
            */
            OJ_assert(g->grid[2][1] == '@' && g->grid[3][0] == '@' && g->grid[3][1] == ' ');

            break;
            
        }
        case 9: // Eat food along ghost trail
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddPacman(g, 0, 0) == true);
            OJ_assert(AddFood(g, 0, 1) == true);
            OJ_assert(AddFood(g, 0, 2) == true);
            OJ_assert(AddGhost(g, 0, 3, left) == true);
            OJ_assert(AddWall(g, 0, 4) == true);
            OJ_assert(g->foodCount == 2);
            /* ______
              |C..@# |
              |      |
              |      |
              |      |
              |      |
              |      |
              \------/
            */

            MovePacman(g, down);
            MoveGhosts(g);
            /* ______
              | .@ # |
              |C     |
              |      |
              |      |
              |      |
              |      |
              \------/
            */
            OJ_assert(g->foodCount == 2);
            OJ_assert(g->grid[1][0] == 'C' && g->grid[0][1] == '.' && g->grid[0][2] == '@' && g->grid[0][3] == ' ');

            MovePacman(g, idle);
            MoveGhosts(g);
            /* ______
              | @. # |
              |C     |
              |      |
              |      |
              |      |
              |      |
              \------/
            */
            OJ_assert(g->foodCount == 2);
            OJ_assert(g->grid[1][0] == 'C' && g->grid[0][1] == '@' && g->grid[0][2] == '.' && g->grid[0][3] == ' ');
            
            MovePacman(g, idle);
            MoveGhosts(g);
            MovePacman(g, idle);
            MoveGhosts(g);
            /* ______
              | @. # |
              |C     |
              |      |
              |      |
              |      |
              |      |
              \------/
            */
            OJ_assert(g->foodCount == 2);
            OJ_assert(g->grid[1][0] == 'C' && g->grid[0][1] == '@' && g->grid[0][2] == '.' && g->grid[0][3] == ' ');
                        
            MovePacman(g, up);
            MoveGhosts(g);            
            MovePacman(g, right);
            MoveGhosts(g);
            /* ______
              | C.@# |
              |      |
              |      |
              |      |
              |      |
              |      |
              \------/
            */
            OJ_assert(g->foodCount == 1);
            OJ_assert(g->grid[0][0] == ' ' && g->grid[0][1] == 'C' && g->grid[0][2] == '.' && g->grid[0][3] == '@');
                        
            MovePacman(g, down);
            MoveGhosts(g);            
            MovePacman(g, right);
            MoveGhosts(g);
            /* ______
              | @. # |
              |  C   |
              |      |
              |      |
              |      |
              |      |
              \------/
            */
            OJ_assert(g->foodCount == 1);
            OJ_assert(g->grid[1][2] == 'C' && g->grid[0][1] == '@' && g->grid[0][2] == '.' && g->grid[0][3] == ' ');

            MovePacman(g, up);
            OJ_assert(g->foodCount == 0);
            OJ_assert(g->state == winning);

            EndGame(g);
            break;
        }
        case 10: // Everything!
        {            
            Game* g = NewGame(6, 6);
            OJ_assert(AddGhost(g, 5, 3, right) == true);
            OJ_assert(AddGhost(g, 3, 4, right) == true);
            OJ_assert(AddGhost(g, 5, 4, up) == true);
            OJ_assert(AddWall(g, 3, 3) == true);

            OJ_assert(AddFood(g, 3, 1) == true);
            OJ_assert(AddFood(g, 3, 5) == true);
            OJ_assert(AddFood(g, 4, 1) == true);
            OJ_assert(AddFood(g, 5, 1) == true);
            OJ_assert(AddFood(g, 0, 0) == true);
            
            OJ_assert(AddGhost(g, 2, 2, right) == true);
            OJ_assert(AddGhost(g, 4, 1, down) == true);
            OJ_assert(AddWall(g, 2, 3) == true);
            OJ_assert(g->foodCount == 5);

            OJ_assert(AddPacman(g, 2, 2) == false);
            OJ_assert(AddPacman(g, 3, 0) == true);
            /* ______
              |.     |
              |      |
              |  @#  |
              |C. #@.|
              | @    |
              | . @@ |
              \------/
            */

            MovePacman(g, right);
            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              | @ #  |
              | C # @|
              | .  @ |
              | @@   |
              \------/
            */
            OJ_assert(g->foodCount == 4);
            OJ_assert(g->grid[3][5] == '@' && g->grid[5][1] == '@' && g->grid[4][4] == '@' && g->grid[2][1] == '@' && g->grid[5][2] == '@');
            
            MovePacman(g, right);
            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              |@  #  |
              |  C#@.|
              | @    |
              | . @@ |
              \------/
            */
            OJ_assert(g->foodCount == 4);
            OJ_assert(g->grid[3][4] == '@' && g->grid[4][1] == '@' && g->grid[5][4] == '@' && g->grid[2][0] == '@');
            OJ_assert(g->grid[3][5] == '.' && g->grid[5][1] == '.' && g->grid[3][2] == 'C');

            MovePacman(g, down);
            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              | @ #  |
              | @ # @|
              | .C @ |
              | .@   |
              \------/
            */
            OJ_assert(g->grid[5][2] == '@' && g->grid[5][1] == '.');


            MovePacman(g, left);
            MoveGhosts(g);
            /* ______
              |.     |
              |      |
              | @@#  |
              |   #@.|
              | C    |
              | @  @ |
              \------/
            */
            OJ_assert(g->foodCount == 3);
            OJ_assert(g->score == 16);
            OJ_assert(g->grid[5][1] == '@');
            OJ_assert(g->grid[2][1] == '@' && g->grid[2][2] == '@' && g->grid[2][0] != '@');


            MovePacman(g, idle);
            MoveGhosts(g);
            MovePacman(g, idle);
            MoveGhosts(g);
            MovePacman(g, idle);
            MoveGhosts(g);
            MovePacman(g, down);
            MoveGhosts(g);
            MovePacman(g, up);
            MoveGhosts(g);
            /* ______
              |.     |
              | @    |
              |  @#  |
              |   # @|
              | C  @ |
              |  @   |
              \------/
            */
            OJ_assert(g->foodCount == 2);
            OJ_assert(g->score == 21);
            OJ_assert(g->grid[5][2] == '@');
            OJ_assert(g->grid[2][1] == ' ' && g->grid[2][2] == '@' && g->grid[1][1] == '@');

            
            MovePacman(g, right);
            MoveGhosts(g);
            MovePacman(g, up);
            MoveGhosts(g);
            MovePacman(g, up);
            MoveGhosts(g);
            MovePacman(g, up);
            MoveGhosts(g);
            /* ______
              |.     |
              | @C   |
              |  @#  |
              |   # @|
              |    @ |
              |  @   |
              \------/
            */
            OJ_assert(g->foodCount == 2);
            OJ_assert(g->score == 17);
            OJ_assert(g->grid[5][2] == '@');
            OJ_assert(g->grid[2][1] == ' ' && g->grid[2][2] == '@' && g->grid[1][1] == '@');

            
            MovePacman(g, right);
            MoveGhosts(g);
            MovePacman(g, right);
            MoveGhosts(g);
            MovePacman(g, right);
            MoveGhosts(g);
            MovePacman(g, down);
            MoveGhosts(g);
            /* ______
              |.     |
              | @    |
              |  @# C|
              |   # @|
              |    @ |
              |@     |
              \------/
            */

            MovePacman(g, down);
            /* ______
              |.     |
              | @    |
              |  @#  |
              |   # @|
              |    @ |
              |@     |
              \------/
            */
            OJ_assert(g->score == 12);
            OJ_assert(g->state == losing);
            OJ_assert(g->grid[3][5] == '@' && g->grid[2][5] == ' ' && g->grid[1][1] == '@' && g->grid[5][0] == '@');

            EndGame(g);
            break;
        }
        default: OJ_assert(0); break;
    }
    printf ("%d", tcase);
    return 0;
}