#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define FOOD_SCORE 10
#define MAX_GHOSTS 30

typedef enum gameState{losing, onGoing, winning} GameState;
typedef enum direction{up, down, left, right, idle} Direction;

/* This line enables us to declare pointers to Ghost in the Game structure,
 * even though definition of Ghost appears after Game. (Only for code to look nice)
 * However, declaring a Ghost object is not allowed. In need of such case,
 * simply move the Ghost definition up.
 */
typedef struct ghost Ghost;

// An example of what you can contain in a Game structure.
typedef struct game {
    char** grid;
    int columns;
    int rows;
    int foodCount;
    int score;
    GameState state;

    int pacmanPosR;
    int pacmanPosC;
    Ghost* ghosts[MAX_GHOSTS];
    int numGhosts;

} Game;

// Tracks a ghost's direction, and records if it stamps on a food or not.
struct ghost {
    int posR;
    int posC;
    bool hasFoodBelow;
    Direction moveDirection;
};

void PrintGame(Game* game);
void PlayGame(Game* game);


/* Creates a new game, with given rows and columns.
 * The left-upper corner is at row 0 and column 0.
 * Boundary is not included in either rows or columns.
 * You should dynamically allocate space for a Game pointer,
 * dynamically allocate a 2-dimensional char grid,
 * and initialize any other value in your Game structure.
 * Return that pointer to the game you created.
 */
Game* NewGame(int rows, int columns){ 
    Game* game = malloc(sizeof(Game));
    game->columns = columns;
    game->rows = rows;

    /* To create a dynamic 2-D array of `char`,
     * first malloc a 1-D array of `char*`,
     * then expand each of those `char*` into an array of `char`.
     */ 
    game->grid = malloc(sizeof(char*) * rows);
    for(int i = 0; i < rows; i++){
        game->grid[i] = malloc(sizeof(char) * columns);
        memset(game->grid[i], ' ', columns);
    }

    game->foodCount = 0;
    game->score = 0;
    game->state = onGoing;

    // Initialize to -1 and prevent multiple Pacmans if there is already valid data.
    game->pacmanPosR = -1;
    game->pacmanPosC = -1;

    game->numGhosts = 0;

    return game;
}

bool IsValidPos(Game* game, int r, int c){
    return (r >= 0 && r < game->rows && c >= 0 && c < game->columns);
}


/* Adds a wall to the game, at row = r, column = c.
 * Walls should be added only to an empty place.
 * After you successfully add a Pacman, return true.
 * Return false on failures.
 */
bool AddWall(Game* game, int r, int c){
    if(!IsValidPos(game, r, c)) return false;
    if(game->grid[r][c] != ' ') return false;
    game->grid[r][c] = '#';
    return true;
}

/* Adds a food to the game, at row = r, column = c.
 * Foods should be added only to an empty place.
 * After you successfully add a food, return true.
 * Return false on failures.
 *
 * FOR PART 2:
 * It's not allowed to add a food on a ghost.
 * It's allowed, however, conversely.
 */
bool AddFood(Game* game, int r, int c){
    if(!IsValidPos(game, r, c)) return false;
    if(game->grid[r][c] != ' ') return false;
    game->grid[r][c] = '.';
    game->foodCount++;
    return true;
}


/* Adds a Pacman to the game! At row = r, column = c.
 * If there is already a Pacman, return false.
 * Pacman should be added only to an empty place.
 * After you successfully add a Pacman, return true.
 * Return false on failures.
 */
bool AddPacman(Game* game, int r, int c){
    if(game->pacmanPosR != -1 || game->pacmanPosC != -1) return false;
    if(!IsValidPos(game, r, c)) return false;
    if(game->grid[r][c] != ' ') return false;
    game->grid[r][c] = 'C';
    game->pacmanPosR = r;
    game->pacmanPosC = c;
    return true;
}

/* Moves Pacman in the given direction.
 * The direction will always be valid.
 * Pacman should stay still if this move
 * will let him hit a wall or boundaries.
 * No matter what move is performed, the
 * game score should decrease by 1.
 *
 * FOR PART 2:
 * Pacman is allowed to move onto a grid
 * with a ghost. In that case, Pacman loses,
 * and will not be able to eat the food
 * under that ghost, if any. Score should
 * still decrease by 1.
 */
void MovePacman(Game* game, Direction direction){
    // Calculate Pacman's next position according to direction. 
    int nextR = game->pacmanPosR;
    int nextC = game->pacmanPosC;
    switch(direction){
    case up:
        nextR--; break;
    case left:
        nextC--; break;
    case down:
        nextR++; break;
    case right:
        nextC++; break;
    case idle:
        // early-exiting on idle
        game->score -= 1;
        return;
    default:
        return;
    }

    // Out of boundary or moves onto a wall
    if(!IsValidPos(game, nextR, nextC) || game->grid[nextR][nextC] == '#') {
        game->score -= 1;
        return;
    }
    
    // Clear the original grid
    game->grid[game->pacmanPosR][game->pacmanPosC] = ' ';
    game->pacmanPosR = nextR;
    game->pacmanPosC = nextC;

    // Different actions depending on the next position.
    if(game->grid[nextR][nextC] == '.'){
        game->score += FOOD_SCORE;
        game->foodCount--;
        if(game->foodCount == 0) game->state = winning;
        game->grid[nextR][nextC] = 'C';
        game->score -= 1;
        return;
    }
    if(game->grid[nextR][nextC] == ' '){
        game->grid[nextR][nextC] = 'C';
        game->score -= 1;
        return;
    }
    if(game->grid[nextR][nextC] == '@'){
        game->state = losing;
        game->score -= 1;
        return;
    }
    return;
}

/* Adds a ghost to the game,
 * at row = r, column = c, with given initial direction.
 * Ghosts can be added to an empty place or on a food.
 * For the latter case, the ghost will cover that food on display,
 * represented also by an '@', but that food should still exist,
 * and that grid should display '.' when the ghost leaves.
 */
bool AddGhost(Game* game, int r, int c, Direction direction){
    if(!IsValidPos(game, r, c)) return false;
    if(game->grid[r][c] == ' '){
        Ghost* ghost = (Ghost*)malloc(sizeof(Ghost));
        ghost->posR = r;
        ghost->posC = c;
        ghost->hasFoodBelow = false;
        ghost->moveDirection = direction;
        game->ghosts[game->numGhosts++] = ghost;
        game->grid[r][c] = '@';
        return true;
    } else if(game->grid[r][c] == '.'){
        Ghost* ghost = (Ghost*)malloc(sizeof(Ghost));
        ghost->posR = r;
        ghost->posC = c;
        ghost->hasFoodBelow = true;
        ghost->moveDirection = direction;
        game->ghosts[game->numGhosts++] = ghost;
        game->grid[r][c] = '@';
        return true;
    } else {
        return false;
    }
}

/* Moves all ghosts in their own directions.
 * Ghosts should be moved in the order they were added.
 * If a ghost will bump into a wall, another ghost, or a boundary,
 * Its direction will reverse, and it will try to move
 * in the new direction immediately this turn.
 * If it bumps into another wall/ghost/boundary,
 * it won't move for this turn.
 */
void MoveGhosts(Game* game){
    for(int i = 0; i < game->numGhosts; i++){
        // Calculate the next position for each ghost.
        Ghost* currGhost = game->ghosts[i];
        int nextR = currGhost->posR;
        int nextC = currGhost->posC;
        switch(currGhost->moveDirection){
        case up:
            nextR--; break;
        case left:
            nextC--; break;
        case down:
            nextR++; break;
        case right:
            nextC++; break;
        default:
            return;
        }

        // If bumps into a wall or a ghost, modify the ghost's direction, and re-calculate its next position.
        if(!IsValidPos(game, nextR, nextC) || game->grid[nextR][nextC] == '#' || game->grid[nextR][nextC] == '@'){
            switch(currGhost->moveDirection){
            case up:
                currGhost->moveDirection = down;
                nextR+=2; 
                break;
            case left:
                currGhost->moveDirection = right;
                nextC+=2; 
                break;
            case down:
                currGhost->moveDirection = up;
                nextR-=2; 
                break;
            case right:
                currGhost->moveDirection = left;
                nextC-=2; 
                break;
            default:
                return;
            }
        }
        
        // If blocked on both ways, stop.
        if(!IsValidPos(game, nextR, nextC) || game->grid[nextR][nextC] == '#' || game->grid[nextR][nextC] == '@') {
            continue;
        } 

        // Recover any food below ghosts.
        if(currGhost->hasFoodBelow){
            game->grid[currGhost->posR][currGhost->posC] = '.';
        } else{
            game->grid[currGhost->posR][currGhost->posC] = ' ';
        }

        // Move to the next position.
        currGhost->posR = nextR;
        currGhost->posC = nextC;

        // Different actions depending on the next position.
        if(game->grid[nextR][nextC] == ' '){
            currGhost->hasFoodBelow = false;
        } else if(game->grid[nextR][nextC] == '.'){
            currGhost->hasFoodBelow = true;
        } else if(game->grid[nextR][nextC] == 'C'){
            currGhost->hasFoodBelow = false;
            game->state = losing;
        }

        game->grid[nextR][nextC] = '@';

    }
}

void EndGame(Game* game){
    if(!game) return;

    /* Freeing a dynamic 2-D array is doing how we created it reversely.
     * First free all the inner 1-D arrays of `char`, i.e. `char*` pointers,
     * then free the `char**` pointer grid.
     */
    if(game->grid){
        for(int i = 0; i < game->rows; i++){
            free(game->grid[i]);
        }
        free(game->grid);
    }

    for(int i = 0; i < game->numGhosts; i++){
        free(game->ghosts[i]);
    }  

    free(game);
}

int main(){
    // This is the game in 4-4 test case 10.
    Game* g = NewGame(6, 6);

    AddFood(g, 3, 1);
    AddFood(g, 3, 5);
    AddFood(g, 4, 1);
    AddFood(g, 5, 1);
    AddFood(g, 0, 0);
    AddWall(g, 3, 3);
    AddWall(g, 2, 3);

    AddGhost(g, 5, 3, right);
    AddGhost(g, 3, 4, right);
    AddGhost(g, 5, 4, up);
    AddGhost(g, 2, 2, right);
    AddGhost(g, 4, 1, down);

    AddPacman(g, 3, 0);

    PlayGame(g);
    EndGame(g);

}


///////////////////////////////////////////////////////////////////////////////
//////////////////////// DO NOT MODIFY ANY CODE BELOW! ////////////////////////
///////////////////////////////////////////////////////////////////////////////

/* This function prints the game grid with boundary,
 * and any message depending on game state.
 * Please make sure that, after any action is done,
 * game->state, game->score, and game->foodCount
 * are correctly updated.
 */

#ifdef _MSC_VER

#include <windows.h>

#endif // _MSC_VER

void PrintGame(Game* game){
    if(!game || !game->grid) return;

// If visual C++, clear console.
#ifdef _MSC_VER 
    system("cls");
#else

// Clears terminal screen
#ifndef _ONLINE_JUDGE
    fflush(stdout);
    system("clear");
#endif

#endif
    
    // The game grid
    printf(" ");
    for(int i = 0; i < game->columns; i++)
        printf("_");
    printf(" \n");

    for(int i = 0; i < game->rows; i++){
        printf("|");
        for(int j = 0; j < game->columns; j++)
            printf("%c", game->grid[i][j]);
        printf("|\n");
    }
    printf("\\");
    for(int i = 0; i < game->columns; i++)
        printf("-");
    printf("/\n\n");

    // Messages on different states
    switch(game->state){
    case losing:
        printf("Pacman died! Your score: %d\n", game->score);
        break;
    case onGoing:
        printf("Score: %d\n", game->score);
        printf("There are %d foods remaining!\n", game->foodCount);
        printf("Pacman wants food! (control by w/a/s/d/i, confirm by Enter)\n\n");
        break;
    case winning:
        printf("Victory! Your score: %d\n", game->score);
        break;
    default:
        printf("ERROR: invalid game state!\n");
    }
}

void PlayGame(Game* game){
    
    // Prints the initial grid
    PrintGame(game);

    // Main loop of game. Terminates when the game ends.
    while(true){
        // We only care about one charater, but should eat the whole line of input.
        char input[127];
        scanf("%s", input);
        Direction direction;
        switch(input[0]){
        case 'w':
        case 'W':
            direction = up; break;
        case 'a':
        case 'A':
            direction = left; break;
        case 's':
        case 'S':
            direction = down; break;
        case 'd':
        case 'D':
            direction = right; break;
        case 'i':
        case 'I':
            direction = idle; break;
        default:
            PrintGame(game);
            continue;
        }

        // Pacman moves first
        MovePacman(game, direction);

        // Loses if Pacman bumps into a ghost
        if(game->state != onGoing){
            break;
        }
        
        // If you haven't implemented ghosts, this does nothing.
        MoveGhosts(game);

        // Loses if a ghost kills Pacman
        if(game->state != onGoing){
            break;
        }
        PrintGame(game);
    }

    // End game message
    PrintGame(game);
    printf("Press any key to exit.\n");
    getchar();
    getchar();
}