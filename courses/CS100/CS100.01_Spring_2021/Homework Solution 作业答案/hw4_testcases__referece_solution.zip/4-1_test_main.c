#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define main __Student__Main_Function_

// INSERT YOUR CODE BELOW

// INSERT YOUR CODE ABOVE

#ifdef OJ_assert
#undef OJ_assert
#endif
#define OJ_assert(stmt) { if (!(stmt)) { printf("Wrong answer!\n"); return 0; } }

#undef main

int main()
{
    int tcase;
    scanf("%d", &tcase);
    switch(tcase)
    {
    case 1: 
    {
        char* hand1[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "7m", "8m", \
                      "7m", "7m", "9m", "7m", "6z", "6z"};
        OJ_assert(CheckWin(hand1) == 1);
        char* hand2[14] = {"1s", "1s", "1s", "2z", "3z", "4z", "7m", "8m", \
                      "7m", "7m", "9m", "7m", "6z", "6z"};
        OJ_assert(CheckWin(hand2) == 0);
        char* hand3[14] = {"1s", "1s", "1s", "5s", "6s", "7s", "6m", "4m", \
                      "5m", "1z", "1z", "1z", "5z", "5z"};
        OJ_assert(CheckWin(hand3) == 1);
        break;
    }
    case 2:
    {
        char* hand1[14] = {"1s", "1s", "1s", "2s", "2s", "2s", "3m", "3m", \
                      "3m", "7m", "7m", "7m", "6z", "6z"};
        OJ_assert(CheckWin(hand1) == 1);
        char* hand2[14] = {"9s", "9s", "8s", "9s", "8s", "3p", "1p", "2p", \
                      "3z", "3z", "3z", "5p", "6p", "4p"};
        OJ_assert(CheckWin(hand2) == 1);
        char* hand3[14] = {"1s", "4s", "7s", "5m", "6p", "8m", "2m", "9p", \
                      "3p", "1z", "1z", "1z", "5z", "5z"};
        OJ_assert(CheckWin(hand3) == 0);
        break;
    }
    case 3:
    {    
        char* hand1[14] = {"1s", "9s", "1m", "9m", "1z", "2z", "3z", "4z", \
                      "5z", "6z", "7z", "1p", "9p", "9p"};
        OJ_assert(CheckWin(hand1) == 0); // thirteen orphans, not a win state
        char* hand2[14] = {"1s", "1s", "2m", "2m", "3p", "3p", "2z", "1z", \
                      "1z", "2z", "5z", "5z", "6z", "6z"}; // normal 7 pairs, not win
        OJ_assert(CheckWin(hand2) == 0);
        char* hand3[14] = {"1s", "1s", "2s", "2s", "3s", "3s", "6s", "6s", \
                      "7s", "7s", "8s", "8s", "6z", "6z"}; // consective 6 pairs and a pair, win
        OJ_assert(CheckWin(hand3) == 1);
        break;
    }
    case 4:
    {    
        char* hand1[14] = {"1z", "1z", "2z", "2z", "3z", "3z", "4z", "4z", \
                      "5z", "6z", "7z", "5z", "6z", "7z"}; // 7-pair makes up by 1-7z
        OJ_assert(CheckWin(hand1) == 0); 
        char* hand2[14] = {"1z", "1z", "2z", "2z", "3z", "3z", "4z", "4z", \
                      "1z", "2z", "3z", "4z", "6z", "6z"}; // The big four winds
        OJ_assert(CheckWin(hand2) == 1);
        char* hand3[14] = {"1s", "1s", "2s", "2s", "3s", "3s", "6s", "6s", \
                      "7s", "7s", "4s", "4s", "5s", "5s"}; // consecutive 7 pairs
        OJ_assert(CheckWin(hand3) == 1);
        break;
    }
    case 5:
    {    
        char* hand1[14] = {"9s", "9s", "9s", "9m", "9m", "9m", "1s", "1s", \
                      "1s", "1p", "1p", "1p", "9p", "9p"};
        OJ_assert(CheckWin(hand1) == 1); 
        char* hand2[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s", "5s"}; // the nine gates
        OJ_assert(CheckWin(hand2) == 1);
        char* hand3[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s", "1s"};
        OJ_assert(CheckWin(hand3) == 1);
        break;
    }
    case 6:
    {    
        char* hand1[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s", "8s"}; // the nine gates
        OJ_assert(CheckWin(hand1) == 1); 
        char* hand2[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s", "3s"}; // the nine gates
        OJ_assert(CheckWin(hand2) == 1);
        char* hand3[14] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s", "4z"};
        OJ_assert(CheckWin(hand3) == 0);
        break;
    }
    case 7:
    {    
        char* hand1[14] = {"3s", "3s", "3s", "1p", "2p", "3p", "8p", "8p", \
                      "8p", "6s", "6s", "6s", "9s", "8s"}; 
        OJ_assert(CheckWin(hand1) == 0); 
        char* hand2[14] = {"2m", "3m", "2p", "9p", "9p", "9p", "3p", "2p", \
                      "7s", "6s", "5s", "4s", "8s", "8s"}; 
        OJ_assert(CheckWin(hand2) == 0);
        char* hand3[14] = {"1m", "2m", "3m", "8m", "8m", "8m", "5s", "4s", \
                      "4s", "3p", "3p", "9p", "7p", "7p"};
        OJ_assert(CheckWin(hand3) == 0);
        break;
    }
    case 8:
    {    
        // 1111234556777p, waits for 35p
        char* hand1[14] = {"1p", "1p", "1p", "1p", "2p", "3p", "4p", "5p", \
                      "6p", "5p", "7p", "7p", "7p", "3p"}; 
        OJ_assert(CheckWin(hand1) == 1); 
        char* hand2[14] = {"1p", "1p", "1p", "1p", "2p", "3p", "4p", "5p", \
                      "6p", "5p", "7p", "7p", "7p", "5p"}; 
        OJ_assert(CheckWin(hand2) == 1);
        char* hand3[14] = {"1p", "1p", "1p", "1p", "2p", "3p", "4p", "5p", \
                      "6p", "5p", "7p", "7p", "7p", "7p"}; 
        OJ_assert(CheckWin(hand3) == 0);
        break;
    }
    case 9:
    {    
        // 1236777888899p, waits for 4679p.
        char* hand1[14] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p", "4p"}; 
        OJ_assert(CheckWin(hand1) == 1); 
        char* hand2[14] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p", "6p"}; 
        OJ_assert(CheckWin(hand2) == 1); 
        char* hand3[14] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p", "7p"}; 
        OJ_assert(CheckWin(hand3) == 1); 
        char* hand4[14] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p", "9p"}; 
        OJ_assert(CheckWin(hand4) == 1); 
        char* hand5[14] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p", "1p"}; 
        OJ_assert(CheckWin(hand5) == 0); 
        break;
    }
    case 10:
    {    
        char* hand1[14] = {"2p", "2p", "3p", "3p", "3p", "4p", "5p", "7p", \
                      "7p", "8p", "8p", "9p", "9p", "3p"}; 
        OJ_assert(CheckWin(hand1) == 1); 
        char* hand2[14] = {"2p", "2p", "3p", "3p", "3p", "4p", "5p", "7p", \
                      "7p", "8p", "8p", "9p", "9p", "2p"}; 
        OJ_assert(CheckWin(hand2) == 1); 
        char* hand3[14] = {"2p", "2p", "3p", "3p", "3p", "4p", "5p", "7p", \
                      "7p", "8p", "8p", "9p", "9p", "8p"}; 
        OJ_assert(CheckWin(hand3) == 0); 
        break;
    }
    case 11:
    {
        char* hand1[13] = {"2p", "3p", "4p", "5p", "6p", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "3z", "3z"}; 
        OJ_assert(CountWaitingTiles(hand1) == 3); //147p
        char* hand2[13] = {"3z", "4z", "4z", "4z", "4z", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "3z", "3z"}; 
        OJ_assert(CountWaitingTiles(hand2) == 0); // (4z)
        char* hand3[13] = {"2p", "3p", "4p", "7p", "9p", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "3z", "3z"}; 
        OJ_assert(CountWaitingTiles(hand3) == 1); // 8p
        break;
    }
    case 12:
    {
        char* hand1[13] = {"2p", "3p", "4p", "6p", "6p", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "3z", "3z"}; 
        OJ_assert(CountWaitingTiles(hand1) == 2); //6p,3z
        char* hand2[13] = {"2p", "3p", "4p", "5p", "3z", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "3z", "3z"}; 
        OJ_assert(CountWaitingTiles(hand2) == 2); //25p
        char* hand3[13] = {"2p", "3p", "4p", "5p", "6p", "1z", "1z", "1z", \
                      "2z", "2z", "2z", "7p", "3z"}; 
        OJ_assert(CountWaitingTiles(hand3) == 1); //3z
        break;
    }
    case 13:
    {
        char* hand1[13] = {"2p", "2p", "3p", "3p", "3p", "4p", "5p", "7p", \
                      "7p", "8p", "8p", "9p", "9p"}; 
        OJ_assert(CountWaitingTiles(hand1) == 3); //236p
        char* hand2[13] = {"1p", "2p", "3p", "5p", "6p", "7p", "7p", "8p", \
                      "8p", "8p", "8p", "9p", "9p"};
        OJ_assert(CountWaitingTiles(hand2) == 4); // 4679p
        char* hand3[13] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
                      "7s", "8s", "9s", "9s", "9s"}; // 1-9s
        OJ_assert(CountWaitingTiles(hand3) == 9);
        break;
    }
    }
    printf("%d", tcase);
    return 0;
}
