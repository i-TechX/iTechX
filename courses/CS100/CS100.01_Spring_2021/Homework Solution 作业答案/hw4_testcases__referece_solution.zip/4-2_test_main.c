#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define main __Student__Main_Function_

// INSERT YOUR CODE BELOW

// INSERT YOUR CODE ABOVE

#ifdef OJ_assert
#undef OJ_assert
#endif
#define OJ_assert(stmt) { if (!(stmt)) { printf("Wrong answer!\n"); return 0; } }
#undef main

int main()
{
    Node testType;
    assert(sizeof(typeof(testType.value)) == 4);
    int tcase = 0;
    scanf("%d", &tcase);
    for(tcase = 1; tcase <= 10; tcase++){
        LinkedList* ll = (LinkedList*)malloc(sizeof(LinkedList));
        list_init(ll);
        switch(tcase){
            case 1:
            {
            /* Test for list_init */
                assert(ll->size == 0 && ll->head == NULL && ll->tail == NULL);
                break;
            }
            case 2:
            {
            /* Test for single node insert */
                int tval1 = 10;
                list_insert(ll, tval1);
                assert(ll->head->value == tval1 && ll->tail->value == tval1 && ll->size == 1);
                break;
            }
            case 3:
            {
            /* Test for multiple nodes insert */
                int v1 = 10, v2 = 30;
                list_insert(ll, v1);
                list_insert(ll, v2);
                assert(ll->head->value == v1 && ll->tail->value == v2 && ll->size == 2);
                break;
            }        
            case 4:
            {
            /* 10 nodes insertion */
                int A[10];
                for (int i = 0; i < 10; i++)
                {
                    A[i] = 10*i;
                    list_insert(ll, A[i]);
                }
                int flag = 1, cnt = 0;
                for (Node* iter = ll->head; iter != NULL; iter = iter->next, cnt++)
                {
                    if (iter->value != cnt * 10)
                        flag = 0;
                }
                assert(flag && ll->size == 10 && cnt == 10);
                break;
            }
            case 5:
            {   
            /* Remove inserior node */
                int v1 = 100, v2 = 99, v3 = 101;
                list_insert(ll, v1);
                list_insert(ll, v2);
                list_insert(ll, v3);
                Node* ret = list_remove(ll, ll->head->next);
                assert(ll->head->value == v1 && ll->tail->value == v3 
                    && ll->size == 2 && ll->head->next == ll->tail && ret == ll->tail);
                break;
            }
            case 6:
            {
            /* Remode head(head != tail) */
                int v1 = 100;
                list_insert(ll, v1);
                int v2 = 99;
                list_insert(ll, v2);
                int v3 = 101;
                list_insert(ll, v3);
                list_remove(ll, ll->head);
                assert(ll->head->value == v2 && ll->tail->value == v3 
                    && ll->size == 2 && ll->head->next == ll->tail);
                break;
            }
            case 7:
            {
            /* Remove tail & head(head == tail) */
                list_insert(ll, 100);
                list_remove(ll, ll->head);
                assert(ll->head == NULL && ll->tail == NULL && ll->size == 0);
                break;
            }
            case 8:
            {
            /* Remove invalid nodes (not in this list) */
                int v1 = 31, v2 = 32, v3 = 33;
                Node* high_node = (Node*)malloc(sizeof(Node));
                high_node->value = 33;
                list_insert(ll, v1);
                list_insert(ll, v2);
                assert(list_remove(ll, high_node) == NULL && ll->size == 2);
                break;
            }
            case 9:
            {
            /* Tests for list_clear */
                int v1 = 31, v2 = 32, v3 = 33;
                list_insert(ll, v1);
                list_insert(ll, v2);
                list_insert(ll, v3);
                assert(ll->head != NULL && ll->size == 3);
                list_clear(ll);
                assert(ll->size == 0 && ll->head == NULL && ll->tail == NULL);
                break;
            }
            case 10:
            {
            /* All tests, insert, remov and clear */
                int v1 = 0, v2 = 1;
                list_insert(ll, v1);
                list_insert(ll, v2);
                list_insert(ll, 10);
                list_remove(ll, ll->head);
                list_remove(ll, ll->tail);
                assert(ll->size == 1 && ll->tail != NULL && ll->head != NULL);
                assert(ll->head->value == 1 && ll->tail->value == 1);
                list_clear(ll);
                assert(ll->size == 0 && ll->head == NULL);
                break;
            }
            default:
                assert(0 == 1);
                break;
        }
        
    } 
    printf("%d", tcase);   
}
