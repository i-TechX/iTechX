Here is guide on how to check your code (or reference code) with test cases. 

`<NAME>_reference` files contain reference code of all functions you need to write.
These files do not compile on their own.

`<NAME>_test_main` files contain code for test cases. 
They also do not compile on their own.

To check your code (or reference code) against a certain test case, copy the code and paste into corresponding `_test_main` files between the two lines of comments.
Compile the `_test_main` file and run the program. Input the test case number (for example, 7). If you pass that case, you would either see output of the same number or see the program terminating. Otherwise, you will see "Wrong answer!".
