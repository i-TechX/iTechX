#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define main __Student__Main_Function_
#define _ONLINE_JUDGE

// INSERT YOUR CODE BELOW

// INSERT YOUR CODE ABOVE

#ifdef OJ_assert
#undef OJ_assert
#endif
#define OJ_assert(stmt) { if (!(stmt)) { printf("Wrong answer!\n"); return 0; } }

#undef main

int main() 
{
    int tcase;
    scanf("%d", &tcase);
    switch(tcase)
    {
        case 1: // NewGame
        {
            Game* g = NewGame(8, 10);
            OJ_assert(g != NULL);
            OJ_assert(g->columns == 10 && g->rows == 8);
            OJ_assert(g->foodCount == 0 && g->score == 0);
            for (int i = 0; i < 8; i++)
                    OJ_assert(g->grid[i] != NULL);
            break;
        }
        case 2: // Add walls
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddWall(g, 1, 1) == true);
            OJ_assert(AddWall(g, 1, 1) == false);
            OJ_assert(g->grid[1][1] == '#');
            OJ_assert(AddWall(g, 11, 11) == false);
            for (int i = 0; i < 5; i++)
                AddWall(g, 0, i);
            for (int i = 0; i < 5; i++)
                OJ_assert(g->grid[0][i] == '#');
            break;
        }
        case 3: // Add food
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddWall(g, 1, 1) == true);
            OJ_assert(AddFood(g, 3, 5) == true);
            OJ_assert(AddFood(g, 3, 5) == false);
            OJ_assert(g->grid[3][5] == '.');
            OJ_assert(AddFood(g, 1, 1) == false);
            OJ_assert(AddFood(g, 11, 11) == false);
            break;
        }
        case 4: // Add pacman(s)
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddFood(g, 3, 5) == true);
            OJ_assert(g->grid[3][5] == '.');
            OJ_assert(AddPacman(g, 3, 5) == false);

            OJ_assert(AddWall(g, 1, 1) == true);
            OJ_assert(AddPacman(g, 1, 1) == false);
            OJ_assert(AddPacman(g, 11, 11) == false);

            OJ_assert(AddPacman(g, 4, 6) == true);
            OJ_assert(AddPacman(g, 4, 4) == false);
            OJ_assert(g->grid[4][6] == 'C' && g->grid[4][4] != 'C');
            break;
        }
        case 5: // Move legal
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddPacman(g, 5, 5) == true);
            OJ_assert(g->grid[5][5] == 'C');
            
            MovePacman(g, up);
            OJ_assert(g->grid[5][5] == ' ' && g->grid[4][5] == 'C');
            MovePacman(g, down);
            OJ_assert(g->grid[4][5] == ' ' && g->grid[5][5] == 'C');
            MovePacman(g, left);
            OJ_assert(g->grid[5][5] == ' ' && g->grid[5][4] == 'C');
            MovePacman(g, right);
            OJ_assert(g->grid[5][4] == ' ' && g->grid[5][5] == 'C');
            MovePacman(g, idle);
            OJ_assert(g->grid[5][5] == 'C');
            break;
        }
        case 6: // Move wall & boundary
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddPacman(g, 0, 0) == true);
            OJ_assert(g->grid[0][0] == 'C');
            OJ_assert(AddWall(g, 1, 0) == true);
            OJ_assert(AddWall(g, 0, 1) == true);

            MovePacman(g, up);
            OJ_assert(g->grid[0][0] == 'C');
            MovePacman(g, down);
            OJ_assert(g->grid[0][0] == 'C');
            MovePacman(g, left);
            OJ_assert(g->grid[0][0] == 'C');
            MovePacman(g, right);
            OJ_assert(g->grid[0][0] == 'C');
            MovePacman(g, idle);
            OJ_assert(g->grid[0][0] == 'C');
            break;
        }
        case 7: // Eat food
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddPacman(g, 0, 0) == true);
            OJ_assert(g->grid[0][0] == 'C');
            OJ_assert(AddFood(g, 0, 1) == true);
            OJ_assert(AddFood(g, 0, 2) == true);
            OJ_assert(g->grid[0][0] == 'C' && g->grid[0][1] == '.' && g->grid[0][2] == '.');
            MovePacman(g, right);
            MovePacman(g, right);
            OJ_assert(g->grid[0][0] == ' ' && g->grid[0][1] == ' ' && g->grid[0][2] == 'C');
            break;
        }
        case 8: // Score
        {
            Game* g = NewGame(8, 10);
            OJ_assert(AddPacman(g, 0, 0) == true);
            OJ_assert(g->grid[0][0] == 'C');
            OJ_assert(AddFood(g, 0, 1) == true);
            OJ_assert(AddFood(g, 0, 2) == true);
            OJ_assert(AddWall(g, 0, 3) == true);
            OJ_assert(g->grid[0][0] == 'C' && g->grid[0][1] == '.' && g->grid[0][2] == '.');
            MovePacman(g, right);
            OJ_assert(g->score == 9);
            MovePacman(g, right);
            OJ_assert(g->grid[0][0] == ' ' && g->grid[0][1] == ' ' && g->grid[0][2] == 'C');
            OJ_assert(g->score == 18);
            MovePacman(g, right);
            OJ_assert(g->score == 17);
            MovePacman(g, idle);
            OJ_assert(g->score == 16);
            MovePacman(g, down);
            OJ_assert(g->grid[1][2] == 'C' && g->score == 15);
            break;
        }
        case 9: // Everything
        {
            Game* g = NewGame(8, 10);
            for (int i = 0; i < 10; i++)
                OJ_assert(AddWall(g, 2, i) == true);
            for (int i = 1; i < 10; i++)
            {
                OJ_assert(AddFood(g, 1, i) == true);
                OJ_assert(AddFood(g, 0, i) == true);
            }
            OJ_assert(g->foodCount == 18);
            OJ_assert(g->score == 0);
            OJ_assert(AddPacman(g, 0, 0) == true);
            OJ_assert(AddPacman(g, 0, 1) == false);
            OJ_assert(AddPacman(g, 0, 0) == false);
            OJ_assert(AddPacman(g, 2, 2) == false);
            for (int i = 0; i < 9; i++)
                MovePacman(g, right);
            OJ_assert(g->score == 81);
            OJ_assert(g->foodCount == 9);
            break;
        }
        case 10: // Everything
        {
            Game* g = NewGame(8, 10);
            for (int i = 0; i < 10; i++)
                OJ_assert(AddWall(g, 2, i) == true);
            for (int i = 1; i < 10; i++)
            {
                OJ_assert(AddFood(g, 1, i) == true);
                OJ_assert(AddFood(g, 0, i) == true);
            }
            OJ_assert(g->foodCount == 18);
            OJ_assert(g->score == 0);
            OJ_assert(AddPacman(g, 0, 0) == true);
            MovePacman(g, down);
            MovePacman(g, down);
            OJ_assert(g->grid[1][0] == 'C');
            for (int i = 0; i < 9; i++)
                MovePacman(g, right);
            OJ_assert(g->score == 79);
            OJ_assert(g->foodCount == 9);
            
            for (int i = 0; i < 10; i++)
            	MovePacman(g, idle);
            OJ_assert(g->score == 69);
            break;
        }
        default: OJ_assert(0); break;
    }
    printf ("%d", tcase);
    return 0;
}