#include <stdio.h>
#include <string.h>

#define INVALID 0
#define RESTRICTED 1
#define ALWAYS_ALLOWED 2

int isWeekday(char* day) {
    if(strcmp(day, "Mon") == 0 ||  
       strcmp(day, "Tue") == 0 || 
       strcmp(day, "Wed") == 0 || 
       strcmp(day, "Thu") == 0 ||
       strcmp(day, "Fri") == 0) 
        return 1;
    else
        return 0;
}

int isLetter(char c){
    return (c >= 'A' && c <= 'Z' && c != 'I' && c != 'O');
}

int isDigit(char c){
    return (c >= '0' && c <= '9');
}

/* Use 'L' and 'd' to form a 5-character expression,
 * and checks if the `plateNumber' matches it.
 */
int Match(char* plateNumber, char* expression){
    int result = 1;
    for (int i = 0; i < 5; i++){
        if(expression[i] == 'L')
            result &= isLetter(plateNumber[i]);
        if(expression[i] == 'd')
            result &= isDigit(plateNumber[i]);
    }
    return result;
}

int ThreeConsecutive(char* plateNumber){
    for(int i = 0; i < 3; i++)
        if(plateNumber[i] == plateNumber[i + 1] && plateNumber[i] == plateNumber[i + 2]) 
            return 1;
    return 0;
}

int PlateType(char* plateNumber){
    if(strlen(plateNumber) == 6){
        if( ((plateNumber[0] == 'D' || plateNumber[0] == 'F') && Match(plateNumber + 1, "ddddd")) || ((plateNumber[5] == 'D' || plateNumber[5] == 'F') && Match(plateNumber, "ddddd")) )
            return ALWAYS_ALLOWED;
        else 
            return INVALID;
    }
    if(strlen(plateNumber) == 5){
        if(Match(plateNumber, "ddddd") || Match(plateNumber, "Ldddd") || Match(plateNumber, "ddddL")){
            if(plateNumber[0] == 'T' || plateNumber[0] == 'X') 
                return ALWAYS_ALLOWED;
            else
                return RESTRICTED;
        }
        else if(Match(plateNumber, "LLddd") || Match(plateNumber, "dLLdd") || Match(plateNumber, "ddLLd") ||
                Match(plateNumber, "dddLL") || Match(plateNumber, "LdddL") || Match(plateNumber, "dLddd") || Match(plateNumber, "ddLdd")){
            if(ThreeConsecutive(plateNumber))
                return INVALID;
            else
                return RESTRICTED;
        }else{
            return INVALID;
        }
    }else{
        return INVALID;
    }
}

int main(){
    char plateNumber[11];
    int month, date;
    char day[4];

    for(int i = 0; i < 3; i++){
        scanf("%s %d/%d %s", plateNumber, &month, &date, day);
        
        switch(PlateType(plateNumber)){
        case INVALID:
            printf("This number is invalid.\n");
            break;
        case RESTRICTED:
            if(!isWeekday(day)){
                printf("This car is allowed to drive.\n");
                break;
            }

            int lastDigit = 0;
            for (int i = 4; i >= 0; i--){
                if(isDigit(plateNumber[i])){
                    lastDigit = plateNumber[i] - '0';
                    break;
                }
            }

            if((lastDigit % 2) == (date % 2))
                printf("This car is allowed to drive.\n");
            else
                printf("This car is not allowed to drive.\n");
            break;
        case ALWAYS_ALLOWED:
            printf("This car is allowed to drive.\n");
            break;
        default:
            return -1;
        }
    }
    
}