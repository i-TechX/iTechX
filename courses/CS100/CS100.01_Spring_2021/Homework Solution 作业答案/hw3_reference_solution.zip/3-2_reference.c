#include <stdio.h>
#include <string.h>

typedef struct
{
    int op, r1, r2, r3;
}inst_t;

typedef enum{add, sub, mul, div, let, print, bge} inst_types;
#define check_one(str, inst_type) { if (strcmp(#inst_type, str) == 0) return inst_type; }

int regs[6];
inst_t insts[30];

unsigned char type(char* str)
{
    check_one(str, add); check_one(str, sub); check_one(str, mul); check_one(str, div);
    check_one(str, bge); check_one(str, let); check_one(str, print); 
    return (unsigned char) -1;
}

int reg_no()
{
    char buf[50];
    scanf("%s", buf);
    return buf[1] - '0';
}

void exec_insts(int n)
{
    int i = 0;
    while (i < n)
    {
        switch (insts[i].op)
        {
            case add:
                regs[insts[i].r1] = regs[insts[i].r2] + regs[insts[i].r3];
                break;
            case sub:
                regs[insts[i].r1] = regs[insts[i].r2] - regs[insts[i].r3];
                break;
            case mul:
                regs[insts[i].r1] = regs[insts[i].r2] * regs[insts[i].r3];
                break;
            case div:
                regs[insts[i].r1] = regs[insts[i].r2] / regs[insts[i].r3];
                break;
            case let:
                regs[insts[i].r1] = insts[i].r2;
                break;
            case print:
                printf("x%d = %d\n", insts[i].r1, regs[insts[i].r1]);
                break;
            case bge:
                i = (regs[insts[i].r1] >= regs[insts[i].r2]) ? insts[i].r3 - 2 : i;
                break;
            default:
                break;
        }
        i++;
    }
}

int main()
{
    int n, num;
    char buf[20];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%s", buf);
        unsigned t = type(buf);
        insts[i].op = t;
        if (t < 4 && t >= 0)
        {
            insts[i].r1 = reg_no();
            insts[i].r2 = reg_no();
            insts[i].r3 = reg_no();
        }
        else if (t == let)
        {
            insts[i].r1 = reg_no();
            scanf("%d", &num);
            insts[i].r2 = num;
        }
        else if (t == print)
        {
            insts[i].r1 = reg_no();
        }    
        else if (t == bge)
        {
            insts[i].r1 = reg_no();
            insts[i].r2 = reg_no();
            scanf("%d", &num);
            insts[i].r3 = num;
        }
    }
    exec_insts(n);
    return 0;
}