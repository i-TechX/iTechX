Controls:

(1) WASD to move
     'J' to fire
     'K' to launch a meteor

(2) Arrow keys to move 
     spacebar to fire 
     left Ctrl to launch a meteor