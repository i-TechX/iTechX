#ifndef GAMEOBJECTS_H__
#define GAMEOBJECTS_H__

#include "ObjectBase.h"

class GameObject : public ObjectBase {};

#endif // GAMEOBJECTS_H__