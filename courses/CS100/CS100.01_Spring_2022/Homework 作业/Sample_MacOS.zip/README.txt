On MacOS:
DO NOT open the executable by double-clicking!
Open a terminal and go to this directory. Run "./Dawnbreaker". If it does not have permission, run "chmod +x ./Dawnbreaker".

在MacOS上：
请*不要*双击运行该程序！
请打开终端并切换到当前目录，运行"./Dawnbreaker"。如果没有执行权限，运行"chmod +x ./Dawnbreaker"。

Controls:

(1) WASD to move
     'J' to fire
     'K' to launch a meteor

(2) Arrow keys to move 
     spacebar to fire 
     *MacOS* 'Z' to launch a meteor