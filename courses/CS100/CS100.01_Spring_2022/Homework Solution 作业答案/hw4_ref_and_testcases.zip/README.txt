Here is guide on how to check your code with test cases. 

"4-2A_test_main" and "4-2B_test_main" files contain code for test cases. 
"hw4_utils.h" contains utility functions to display the status of your game when your program runs incorrectly.
They do not compile on their own.

To check your code, copy your code and paste into corresponding "_test_main" files between the two lines of comments.

///////////// INSERT YOUR CODE BELOW /////////////
            ( paste your code here! )
///////////// INSERT YOUR CODE ABOVE /////////////

Then, compile the "_test_main" file and run the program.
