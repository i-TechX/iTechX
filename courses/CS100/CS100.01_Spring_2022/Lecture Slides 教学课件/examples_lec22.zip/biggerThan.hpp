#ifndef SOMEARBITRARYSENTINELTAG
#define SOMEARBITRARYSENTINELTAG

template<class T>
bool biggerThan( const T & lhs, const T & rhs ) {
  return lhs > rhs;
}

#endif