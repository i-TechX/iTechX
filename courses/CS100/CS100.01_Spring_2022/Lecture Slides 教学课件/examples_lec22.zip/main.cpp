#include <iostream>
#include <vector>
#include "biggerThan.hpp"
#include "allBiggerThan.hpp"

int main() {
  int a,b;
  a = 3;
  b = 2;

  std::cout << biggerThan<int>( a,b ) << std::endl;

  std::vector<int> va(3);
  std::vector<int> vb(3);

  //leave the elements to be random!
  std::cout << allBiggerThan<int>( va,vb ) << std::endl;
}