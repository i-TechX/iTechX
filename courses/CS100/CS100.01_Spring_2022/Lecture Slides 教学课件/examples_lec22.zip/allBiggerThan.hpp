#ifndef SOMEARBITRARYSENTINELTAG2
#define SOMEARBITRARYSENTINELTAG2

#include "biggerThan.hpp"
#include <vector>

template<class T>
bool allBiggerThan( const std::vector<T> & lhs, const std::vector<T> & rhs ) {
  //for the sake of simplicity, lets simply assume that lhs.size() == rhs.size()

  bool allBiggerThanResult = true;
  for( int i = 0; i < lhs.size(); i++ ) {
    if( !(biggerThan<T>(lhs[i],rhs[i])) )
      allBiggerThanResult = false;
  }

  return allBiggerThanResult;
}

#endif