# Homework1

Name:

Student ID:

The Homework1 consists of two parts.

## PartA
 There are 2 problems in a similar form as Quiz 1.
 You should commit electronic version of your answer (Latex is encouraged, but picture of handwriting is OK).
 Please write **your Chinese name and your student ID in PartA and README**.


## PartB
It's a coding project. We mainly borrow the assignment project from CS231n. In addition, we add Perceptron Learning Algorithm as an independent file. You should remove all the datasets you download before you commit your project.
