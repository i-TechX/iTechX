Details about this assignment can be found [on the course webpage](http://cs231n.github.io/), under Assignment #1 of Spring 2020.

Please note that we also have a separate ipython notebook file "perceptron.ipynb", which also needs to be completed. 
