# Homework2

Name:

Student ID:

The Homework2 consists of two parts. 

This assignment is due on **Sunday, November 6 2022** at 11:59pm CST.

## PartA
 There are 3 problems in a similar form as Quiz 1.
 You should commit electronic version of your answer (Latex is encouraged, but picture of handwriting is OK).
 Please write **your Chinese name and your student ID in PartA and README**.


## PartB
It's a coding project. We mainly borrow the assignment project from CS231n. For detailed instructions, see `assignment2.md`.
