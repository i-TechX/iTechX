# Final Project Report
Group Number:  
Group Name:

## Deadline
**January 9, 2020, 23:59 UTC+8**

Name:   student ID:  Github Username:  
Name:   student ID:  Github Username:  
Name:   student ID:  Github Username:  

**No more than 3 students of each team.**

One group just need to create one repo in gitclassroom. You can add your teammate into collabration in the repo.
Write the group number and your chinese name, student ID(include your teammate if any).
In this repo, you need to submit your project proposal.(.tex and pdf)

For the detail of the project report, please read introduction.pdf and the post of final project on piazza carefully!

