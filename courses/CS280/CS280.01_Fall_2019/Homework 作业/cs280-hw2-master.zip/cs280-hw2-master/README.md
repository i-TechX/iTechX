# Homework2

Name:  student ID: 

**Please write your Chinese name and your student ID in this README**.

## Deadline
**November 5, 2019, 23:59 UTC+8**

 **Please write your Chinese name and your student ID in README**.



## Statement 
It's a coding project. We mainly borrow the project from CS231n. You can refer to [README](partA-coding/README.md) for details.   
Before you start coding, make sure you current work dir is in this folder `partA-coding`, otherwise you can not import the modules normally.



## Submission

The submission poses no difference against a normal push to the github repo. We will assemble your assignments via Git Classroom's functionality. 
You need to push this folder contains PartA into you Github repo which is created by Git Classroom. **We will take your last commit as the final result.**
You should remove all the datasets you download before you commit your project.

If you have any question about the usage of git/GitHub, refer to the manual or post on Piazza for help.


