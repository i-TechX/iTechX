CS282 Homework 3:

You need to complete both writing part (3 points) and coding part (3 points).

Please hand in .pdf files of two parts.

Due 23:59 (CST), Dec 16, 2021. Plagiarizer will get 0 points. Late submission will be accepted according to the late policy:

0-12 hours: 90%
12-36 hours: 50%
36-60 hours: 25%
>60 hours: 0%

We only grade the last submission.

