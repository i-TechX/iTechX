load fisheriris
variety = ~strcmp(species,'virginica');
X = meas(variety,3:4);
y = species(variety);
gscatter(X(:,1),X(:,2),y);


