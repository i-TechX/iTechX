# inside.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to ShanghaiTech University, including a link 
# to https://i-techx.github.io/iTechX/courses?course_code=CS274A
# 
# Attribution Information: The NLP projects were developed at ShanghaiTech University.
# The question was created by Songlin Yang (yangsl@shanghaitech.edu.cn).

import torch

def inside(unary, binary, root):
    """
    :param unary: emission log-probability \log P(A-> w_i), size: [l, m]
    :param binary:  binary rule log-probability \log P(A->BC), size: [m, m, m]
    :param root: root rule log-probability, size: [m]
    :return: alpha: inside score chart, size: [l+1, l+1, m]
             logZ: partiton function, size: [1]
    """
    sen_len, nt_num = unary.shape

    # inside chart (indexing: left inclusive, right exclusive). -1e5 is a small number to represent -inf
    alpha = torch.zeros(sen_len + 1, sen_len + 1, nt_num).fill_(-1e5)

    """YOUR CODE HERE"""
    raise NotImplementedError

def outside(alpha, unary, binary, root):
    """
    :param alpha: inside score chart
    :return: beta: outside score  chart
    """
    beta = torch.zeros_like(alpha).fill_(-1e5)

    """YOUR CODE HERE"""
    raise NotImplementedError

def inside_outside(unary, binary, root):
    """
    :return: marginal. size: [l+1, l+1, m]
    """
    alpha, logZ = inside(unary, binary, root)
    beta = outside(alpha, unary, binary, root)

    """YOUR CODE HERE"""
    raise NotImplementedError

def inside_backprop(unary, binary, root):
    """
    :return: marginal. size: [l+1, l+1, m]
    """
    """YOUR CODE HERE"""
    raise NotImplementedError



if __name__ == '__main__':
    length = 10
    state_num = 5
    root = torch.randn(state_num).log_softmax(-1)
    binary = torch.randn(state_num, state_num**2).log_softmax(-1).reshape(state_num, state_num, state_num)
    unary = torch.randn(length, state_num)

    span_nt_marginal = inside_outside(unary, binary, root)
    span_nt_marginal2 = inside_backprop(unary, binary, root)

    # inside-outside are just back-prop!
    assert torch.isclose(span_nt_marginal, span_nt_marginal2).all()

