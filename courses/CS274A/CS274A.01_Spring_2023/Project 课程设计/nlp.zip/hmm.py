# hmm.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to ShanghaiTech University, including a link 
# to https://i-techx.github.io/iTechX/courses?course_code=CS274A
# 
# Attribution Information: The NLP projects were developed at ShanghaiTech University.
# The question was created by Songlin Yang (yangsl@shanghaitech.edu.cn).

import torch

def forward(pi, A, O):
    """
    :param pi: prior log-probability
    :param A: transition log-probability
    :param O: emission log-probability
    :return: forward score

    Note: Slightly different from what we learned in the lecture, we do not consider START or STOP for simplicity.
    Instead, we use *pi* to indicate the prior distribution in the 0th step.
    """

    length, state_num = O.shape
    alpha = torch.zeros(length, state_num).fill_(-1e9)
    alpha[0] = pi + O[0]

    for i in range(1, length):
        alpha[i] = (alpha[i-1].unsqueeze(-1) + A + O[i].unsqueeze(-2)).logsumexp(-2)

    logZ = alpha[-1].logsumexp(-1)
    return alpha, logZ


def backward(pi, A, O):
    length, state_num = O.shape
    beta = torch.zeros(length, state_num).fill_(-1e9)
    beta[-1] = 0

    for i in range(length-2, -1, -1):
        beta[i] = (beta[i + 1].unsqueeze(-2) + A + O[i+1].unsqueeze(-2)).logsumexp(-1)
    return beta

def forward_backward(pi, A, O):
    alpha, logZ = forward(pi, A, O)
    beta = backward(pi, A, O)

    # similar to page 47 of the slide of Lecture08
    emission_marginal = (alpha + beta -  logZ).exp()
    transition_marginal = (alpha[:-1].unsqueeze(-1) + beta[1:].unsqueeze(-2) + A + O[1:].unsqueeze(-2) - logZ).exp()
    return emission_marginal, transition_marginal


def forward_backprop(pi, A, O):
    length, state_num = O.shape
    t_marginal_aux = torch.zeros(length, state_num, state_num, requires_grad=True)
    e_marginal_aux = torch.zeros(length, state_num, requires_grad=True)
    alpha = torch.zeros(length, state_num).fill_(-1e9)
    alpha[0] = pi + O[0] + e_marginal_aux[0]

    for i in range(1, length):
        alpha[i] = (alpha[i-1].unsqueeze(-1) + A + O[i].unsqueeze(-2) + t_marginal_aux[i-1]).logsumexp(-2) + e_marginal_aux[i]

    logZ = alpha[-1].logsumexp(-1)
    logZ.sum().backward()
    return e_marginal_aux.grad, t_marginal_aux.grad[:-1]


if __name__ == '__main__':
    length = 10
    state_num = 5
    pi = torch.rand(state_num)
    A = torch.rand(state_num, state_num)
    O = torch.rand(length, state_num)

    e_marginals, t_marginals = forward_backward(pi, A, O)
    e_marginals2, t_marginals2 = forward_backprop(pi, A, O)

    # forward-backward are just back-prop!
    assert torch.isclose(e_marginals, e_marginals2).all()
    assert torch.isclose(t_marginals, t_marginals2).all()

