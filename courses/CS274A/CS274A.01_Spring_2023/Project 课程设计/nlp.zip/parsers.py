# parsers.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to ShanghaiTech University, including a link 
# to https://i-techx.github.io/iTechX/courses?course_code=CS274A
# 
# Attribution Information: The NLP projects were developed at ShanghaiTech University.
# The core projects and autograders were created by Haoyi Wu (wuhy1@shanghaitech.edu.cn),
# severely modified by the Pacman projects from UC Berkeley (http://ai.berkeley.edu/projects/pacman/)

import util
from parsers_util import (
    TransitionError,
    DependencyGraph,
    DependencyNode,
    ROOT,
)


class Parser(object):
    """
    A base class for implementing a parser.
    """

    def __init__(self):
        """
        Initialize the parser.
        """
        pass

    def parse(self, tokens):
        """
        Parse the given list of tokens, return a list of dependency edges.
        """
        raise NotImplementedError


class TransitionBasedParser(Parser):
    """
    A transition-based parser.
    """
    def __init__(self, transition_system):
        """
        Initialize the parser.
        """
        self.transition_system = transition_system

    def parse(self, tokens):
        """
        Question: Implement the transition-based parsing algorithm.

        The input is a list of tokens. Your task is to return the parsed dependency
        graph. The dependency graph should be an instance of `DependencyGraph` in
        `parsers_util.py`, which is a list of dependency nodes.

        You need to call the transition system in order to get the next action:

        >>> action = self.transition_system.get_next_action(state)

        where state is the current parser state. In this project, we simply use
        a transition system that returns a fixed sequence of actions, so you can
        pass whatever you like into the transition system, or just ignore it:

        >>> action = self.transition_system.get_next_action()

        The transition system will only return one of the following actions: `SHIFT`,
        `LEFT-ARC`, or `RIGHT-ARC`. If you find that the transition system takes
        an invalid move, raise the `TransitionError` exception:

        >>> raise TransitionError("Invalid move")

        Example to construct a parse tree for a dummy sentence:

        >>> tokens = ["I", "am", "here"]
        >>> dummy_nodes = [DependencyNode(token) for token in [ROOT] + tokens]
        >>> dummy_nodes[1].head = dummy_nodes[2]
        >>> dummy_nodes[2].head = dummy_nodes[0]
        >>> dummy_nodes[3].head = dummy_nodes[2]
        >>> graph = DependencyGraph(dummy_nodes)
        >>> print(graph)
        sentence: ROOT I am here
        heads:    -1   2 0  2

        HINT: This question is quite easy. There's no need to implement complex 
        data structures. Make good use of the data structures in `util.py`.
        HINT: The algorithm detail should be consistent with the slides.
        """

        stack = util.Stack()
        buffer = util.Stack()

        """YOUR CODE HERE"""
        raise NotImplementedError

