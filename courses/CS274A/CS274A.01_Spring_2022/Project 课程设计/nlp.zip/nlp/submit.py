import tarfile
def tar(fname, files): 
  t = tarfile.open(fname, "w") 
  for file in files: 
    t.add(file)
  t.close()

tar("nlp.tar", ['parsers.py', 'inside.py'])
print('''Successfully generated tar file. Please submit the generated tar file to
autolab to receive credits.''')