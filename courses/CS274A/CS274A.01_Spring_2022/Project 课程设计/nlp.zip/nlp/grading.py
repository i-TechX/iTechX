# grading.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import re
import sys, traceback
import time_decorator
import util

class TestClass(object):

    timeLimit = 2           # The time limit (in seconds) of each testcase

    def __init__(self, test_dict, solution_dict):

        self.test_dict = test_dict
        self.solution_dict = solution_dict
        self.class_ = test_dict['class']
        self.algorithm_ = test_dict['algorithm']
        self.timeLimit_ = int(test_dict.get('timeLimit', TestClass.timeLimit))
    
    def getResult(self):
        return self.test(lambda *args, **kwargs: (TestClass.__dict__[self.algorithm_](self, *args, **kwargs)), self.timeLimit_)
    
    def test(self, my_algorithm, time = timeLimit):
        
        @time_decorator.time_limit(time)
        def excuteTask(my_algorithm):
            return my_algorithm()
        
        try:
            result = excuteTask(my_algorithm)
        except Exception as e:
            result = {"ans":e, "gold":"", "msg":"**Solution not accessable due to TimeOutError. Please find it in file.**"}
        
        if self.test_dict['class'] == 'IOTest':
            return self.IOTest(**result)
        elif self.test_dict['class'] == 'ExceptionTest':
            return self.ExceptionTest(**result) 
        elif self.test_dict['class'] == 'HiddenTest':
            return self.HiddenTest(**result) 

    def IOTest(self, ans, gold = None, msg = '', passed = None):
        if isinstance(ans, BaseException):
            if isinstance(ans, ImportError):
                return False, '    ' + 'Code not found! Please check the path of your code.'
            elif isinstance(ans, NotImplementedError):
                return False, '    ' + 'Have not been implemented!' + ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename)
            else:
                return False, '    ' + 'Exception raised: ' + type(ans).__name__ + \
                              ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename) + ': ' + str(ans) + '\n*** ' + \
                              '    ' + '  Exception line: ' + str(traceback.extract_tb(ans.__traceback__)[-1].line) + '\n*** ' + \
                              '    ' + '        Comments: ' + self.test_dict['trickyPart']
        elif ((ans != gold) if passed is None else (not passed)):
            return False, '    ' + 'Wrong answer! ' + msg + '\n*** ' +\
                           '    ' + '   Your answer: ' + str(ans) + '\n*** ' +\
                           '    ' + 'Correct answer: ' + str(gold) + '\n*** ' +\
                           '    ' + '      Comments: ' + self.test_dict['trickyPart']
        else:
            return True, '    ' + 'Test case passed!'

    
    def ExceptionTest(self, ans, gold = None, msg = '', passed = None):
        if isinstance(ans, BaseException):
            if isinstance(ans, ImportError):
                return False, '    ' + 'Code not found! Please check the path of your code.'
            elif isinstance(ans, NotImplementedError):
                return False, '    ' + 'Have not been implemented!' + ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename)
            elif not issubclass(type(ans), type(gold)):
                return False, '    ' + 'Exception raised: ' + type(ans).__name__ + \
                              ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename) + ': ' + str(ans) + '\n*** ' + \
                              '    ' + '  Exception line: ' + str(traceback.extract_tb(ans.__traceback__)[-1].line) + '\n*** ' + \
                              '    ' + '  Correct answer: ' + repr(gold) + '\n*** ' +\
                              '    ' + '        Comments: ' + self.test_dict['trickyPart']
            else:
                return True, '    ' + 'Test case passed!'
        else:
            return False, '    ' + 'Wrong answer! ' + (msg if msg else 'Exception should be raised!') + '\n*** ' +\
                            '    ' + '   Your answer: ' + str(ans) + '\n*** ' +\
                            '    ' + 'Correct answer: ' + repr(gold) + '\n*** ' +\
                            '    ' + '      Comments: ' + self.test_dict['trickyPart']
    

    def HiddenTest(self, ans, gold = None, msg = '', passed = None):
        if isinstance(ans, BaseException):
            if isinstance(ans, ImportError):
                return False, '    ' + 'Code not found! Please check the path of your code.'
            elif isinstance(ans, NotImplementedError):
                return False, '    ' + 'Have not been implemented!' + ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename)
            else:
                return False, '    ' + 'Exception raised: ' + type(ans).__name__ + \
                              ' (line %d in %s)' % (traceback.extract_tb(ans.__traceback__)[-1].lineno, traceback.extract_tb(ans.__traceback__)[-1].filename) + ': ' + str(ans) + '\n*** ' + \
                              '    ' + '  Exception line: ' + str(traceback.extract_tb(ans.__traceback__)[-1].line)
        elif ((ans != gold) if passed is None else (not passed)):
            return False, '    ' + 'Wrong answer! ' + msg
        else:
            return True, '    ' + 'Test case passed!'
            

    # ========== Below is the template of the algorithms run during the test ========== #

    ## Question: Transition Based Parsing

    def transitionTest(self):
        msg = ''
        try:
            from parsers_testclass import TransitionBasedParserTestClass
            from parsers_util import DependencyGraph, TransitionError, ROOT
            heads = eval(self.solution_dict['solution'])
            gold = heads

            tokens = self.test_dict['Sentence'].split(' ')
            trans = self.test_dict['Transitions'].split(' ')
            is_hidden = self.test_dict.get('hidden', False)

            tester = TransitionBasedParserTestClass
            graph, cnt = tester.test_parse(tokens, trans)

            def test(graph, cnt):

                if isinstance(heads, TransitionError):
                    pred, gold, msg = graph, heads, "The transition is invalid."
                    if isinstance(graph, DependencyGraph): return pred, gold, msg, False
                    pred, gold, msg = cnt, len(trans), "The number of calls you make to the `get_next_action` is incorrect."
                    if cnt != len(trans): return pred, gold, msg, False
                    pred, gold, msg = graph, heads, ""
                    return pred, gold, msg, True
                        
                else:
                    pred, gold, msg = graph, heads, "The transition is valid."
                    if not isinstance(graph, DependencyGraph): return pred, gold, msg, False
                    pred, gold, msg = graph.sentence, tokens, "The sentence from your dependency graph is incorrect."
                    if graph.sentence != [ROOT] + tokens: return pred, gold, msg, False
                    pred, gold, msg = graph.heads, heads, "The heads from your dependency graph is incorrect."
                    if is_hidden: pred = util.md5(pred)
                    if pred != gold: return pred, gold, msg, False
                    pred, gold, msg = cnt, len(trans), "The number of calls you make to the `get_next_action` is incorrect."
                    if pred != gold: return pred, gold, msg, False
                    pred, gold, msg = graph.heads, heads, ""
                    return pred, gold, msg, True

            pred, gold, msg, passed = test(graph, cnt)

        except BaseException as e:
            return {"ans": e, "gold": heads}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}
    
    def transitionSanityTest(self):
        msg = ''
        try:
            from parsers_testclass import TransitionBasedParserTestClass
            from parsers_util import DependencyGraph, TransitionError, ROOT
            import random

            def getTrans(n):
                seqs = []
                shift = 0
                arc = 0
                p = random.random()
                for i in range(n*2):
                    if shift < n and shift - arc <= 1:
                        seqs.append('SHIFT')
                        shift += 1
                    elif shift == n:
                        seqs.append('LEFT-ARC' if random.random() < 0.5 and arc < n-1 else 'RIGHT-ARC')
                        arc += 1
                    else:
                        if random.random() < p:
                            seqs.append('SHIFT')
                            shift += 1
                        else:
                            seqs.append('LEFT-ARC' if random.random() < 0.5 else 'RIGHT-ARC')
                            arc += 1
                return seqs

            def is_connected(heads):
                if heads[0] != -1: return False
                heads[0] = 0
                
                if any([h<0 or h>=len(heads) for h in heads]): return False
                
                def find(i):
                    if heads[i] == i:
                        return i
                    else:
                        return find(heads[i])
                
                if any([find(i) != 0 for i in range(len(heads))]): return False
                return True

            def test(graph, cnt):

                pred, gold, msg = graph, '<a dependency graph>', "The transition is valid."
                if not isinstance(graph, DependencyGraph): return pred, gold, msg, False
                pred, gold, msg = graph.sentence, [ROOT] + tokens, "The sentence from your dependency graph is incorrect."
                if pred != gold: return pred, gold, msg, False
                pred, gold, msg = graph.heads, '<a connected dependency graph>', "The heads from your dependency graph is incorrect."
                if not is_connected(pred[:]): return pred, gold, msg, False
                pred, gold, msg = cnt, len(trans), "The number of calls you make to the `get_next_action` is incorrect."
                if pred != gold: return pred, gold, msg, False
                pred, gold, msg = graph.heads, '<a connected dependency graph>', ""
                return pred, gold, msg, True

            for n in (1, 2, 3, 4, 5, 10, 20, 50, 50, 50):

                msg = f"Test with sentence length {n}"

                tokens = [str(i+1) for i in range(n)]
                trans = getTrans(n)

                tester = TransitionBasedParserTestClass
                graph, cnt = tester.test_parse(tokens, trans)

                pred, gold, msg, passed = test(graph, cnt)
                if not passed: break

        except BaseException as e:
            return {"ans": e, "gold": "", "msg": msg}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}

    ## Question: Graph Based Parsing - Chu-Liu-Edmonds Algorithm

    def nonProjectiveTest(self):
        try:
            from parsers_testclass import ChuLiuEdmondsParserTestClass
            from parsers_util import DependencyGraph, ROOT
            heads = eval(self.solution_dict['solution'])
            heads2 = eval(self.solution_dict.get('solution2', 'None'))
            is_hidden = self.test_dict.get('hidden', False)
            gold = heads

            tokens = self.test_dict['Sentence'].split(' ')
            scores = eval(self.test_dict['Scores'])

            tester = ChuLiuEdmondsParserTestClass
            graph = tester.test_parse(tokens, scores)

            def test(graph):
                pred, gold, msg = graph, heads, "The returned object is not a DependencyGraph."
                if not isinstance(pred, DependencyGraph): return pred, gold, msg, False

                pred, gold, msg = graph.sentence, [ROOT] + tokens, "The sentence from your dependency graph is incorrect."
                if pred != gold: return pred, gold, msg, False

                pred, gold, gold2, msg = graph.heads, heads, heads2, "The heads from your dependency graph is incorrect."
                if is_hidden: pred = util.md5(pred)
                if pred != gold and (not gold2 or pred != gold2): return pred, gold, msg, False

                pred, gold, msg, passed = graph.heads, graph.heads, "Correct.", True
                return pred, gold, msg, passed

            pred, gold, msg, passed = test(graph)

        except BaseException as e:
            return {"ans": e, "gold": heads}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}
    
    def nonProjectiveSanityTest(self):
        try:
            from parsers_testclass import ChuLiuEdmondsParserTestClass
            from parsers_util import DependencyGraph, ROOT
            import random

            def is_connected(heads):
                if heads[0] != -1: return False
                heads[0] = 0
                
                if any([h<0 or h>=len(heads) for h in heads]): return False
                
                def find(i):
                    if heads[i] == i:
                        return i
                    else:
                        return find(heads[i])
                
                if any([find(i) != 0 for i in range(len(heads))]): return False
                return True

            def test(graph):
                pred, gold, msg = graph, '<a dependency graph>', "The returned object is not a DependencyGraph."
                if not isinstance(pred, DependencyGraph): return pred, gold, msg, False

                pred, gold, msg = graph.sentence, [ROOT] + tokens, "The sentence from your dependency graph is incorrect."
                if pred != gold: return pred, gold, msg, False

                pred, gold, msg = graph.heads, '<a connected dependency graph>', "The heads from your dependency graph is incorrect."
                if not is_connected(pred[:]): return pred, gold, msg, False

                pred, gold, msg, passed = graph.heads, graph.heads, "Correct.", True
                return pred, gold, msg, passed

            for n in range(1, 20+1):
                tokens = [str(i+1) for i in range(n)]
                scores = [[random.random() for _ in range(n+1)] for _ in range(n+1)]
                for i in range(n+1):
                    scores[i][0] = 0
                    scores[i][i] = 0

                tester = ChuLiuEdmondsParserTestClass
                graph = tester.test_parse(tokens, scores)

                pred, gold, msg, passed = test(graph)

                if not passed: break

        except BaseException as e:
            return {"ans": e, "gold": '<a dependency graph>'}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}


    ## Question: Is dependency graph projective or not

    def isProjectiveTest(self):
        try:
            from parsers_testclass import EisnerParserTestClass
            from parsers_util import DependencyNode, DependencyGraph, ROOT
            gold = eval(self.solution_dict['solution'])
            is_hidden = self.test_dict.get('hidden', False)

            tokens = self.test_dict['Sentence'].split(' ')
            heads = eval(self.test_dict['Heads'])
            tokens = [DependencyNode(token) for token in [ROOT]+tokens]
            for token, head in zip(tokens[1:], heads): token.head = tokens[head]

            tester = EisnerParserTestClass
            pred = tester.test_is_projective(DependencyGraph(tokens))

            def test(pred):
                msg = "The returned object is not a boolean value (True, False)."
                if not pred in [True, False]: return pred, gold, msg, False

                msg = "Wrong answer."
                if is_hidden: pred = util.md5(self.test_dict['Sentence']+str(pred))
                if pred != gold: return pred, gold, msg, False

                msg, passed = "Correct.", True
                return pred, gold, msg, passed

            pred, gold, msg, passed = test(pred)

        except BaseException as e:
            return {"ans": e, "gold": gold}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}

    ## Question: Graph Based Parsing - Eisner Algorithm

    def projectiveTest(self):
        try:
            from parsers_testclass import EisnerParserTestClass
            from parsers_util import DependencyGraph, ROOT
            heads = eval(self.solution_dict['solution'])
            heads2 = eval(self.solution_dict.get('solution2', 'None'))
            is_hidden = self.test_dict.get('hidden', False)
            gold = heads

            tokens = self.test_dict['Sentence'].split(' ')
            scores = eval(self.test_dict['Scores'])

            tester = EisnerParserTestClass
            graph = tester.test_parse(tokens, scores)

            def test(graph):
                pred, gold, msg = graph, heads, "The returned object is not a DependencyGraph."
                if not isinstance(pred, DependencyGraph): return pred, gold, msg, False

                pred, gold, msg = graph.sentence, [ROOT] + tokens, "The sentence from your dependency graph is incorrect."
                if pred != gold: return pred, gold, msg, False

                pred, gold, gold2, msg = graph.heads, heads, heads2, "The heads from your dependency graph is incorrect."
                if is_hidden: pred = util.md5(pred)
                if pred != gold and (not gold2 or pred != gold2): return pred, gold, msg, False

                pred, gold, msg, passed = graph.heads, graph.heads, "Correct.", True
                return pred, gold, msg, passed

            pred, gold, msg, passed = test(graph)

        except BaseException as e:
            return {"ans": e, "gold": heads}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}
    
    def projectiveSanityTest(self):
        try:
            from parsers_testclass import EisnerParserTestClass
            from parsers_util import DependencyGraph, ROOT
            import random

            def is_connected(heads):
                if heads[0] != -1: return False
                heads[0] = 0
                
                if any([h<0 or h>=len(heads) for h in heads]): return False
                
                def find(i):
                    if heads[i] == i:
                        return i
                    else:
                        return find(heads[i])
                
                if any([find(i) != 0 for i in range(len(heads))]): return False
                return True

            def test(graph):
                pred, gold, msg = graph, '<a dependency graph>', "The returned object is not a DependencyGraph."
                if not isinstance(pred, DependencyGraph): return pred, gold, msg, False

                pred, gold, msg = graph.sentence, [ROOT] + tokens, "The sentence from your dependency graph is incorrect."
                if pred != gold: return pred, gold, msg, False

                pred, gold, msg = graph.heads, '<a connected dependency graph>', "The heads from your dependency graph is incorrect."
                if not is_connected(pred[:]): return pred, gold, msg, False

                pred, gold, msg, passed = graph.heads, graph.heads, "Correct.", True
                return pred, gold, msg, passed

            for n in range(1, 20+1):
                tokens = [str(i+1) for i in range(n)]
                scores = [[random.random() for _ in range(n+1)] for _ in range(n+1)]
                for i in range(n+1):
                    scores[i][0] = 0
                    scores[i][i] = 0

                tester = EisnerParserTestClass
                graph = tester.test_parse(tokens, scores)
                assert tester.test_is_projective(graph), "The dependency graph is not projective!"

                pred, gold, msg, passed = test(graph)

                if not passed: break

        except BaseException as e:
            return {"ans": e, "gold": '<a dependency graph>'}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}

    ## Question: Inside algorithm - dummy test

    def insideSanityTest(self):
        try:
            from inside import inside, outside, inside_outside, inside_backprop
            import torch
            length = 10
            state_num = 5
            root = torch.rand(state_num).log_softmax(-1)
            binary = torch.rand(state_num, state_num**2).log_softmax(-1).reshape(state_num, state_num, state_num)
            unary = torch.rand(length, state_num)

            span_nt_marginal = inside_outside(unary, binary, root)
            span_nt_marginal2 = inside_backprop(unary, binary, root)

            # inside-outside are just back-prop!
            if span_nt_marginal.shape != (length+1, length+1, state_num):
                pred, gold, msg, passed = f"<marginal with shape {tuple(span_nt_marginal.shape)}>", f"<marginal with shape {(length+1, length+1, state_num)}>", "The shape of the tensor returned from 'inside_outside' is incorrect.", False
            elif span_nt_marginal2.shape != (length+1, length+1, state_num):
                pred, gold, msg, passed = f"<marginal with shape {tuple(span_nt_marginal2.shape)}>", f"<marginal with shape {(length+1, length+1, state_num)}>", "The shape of the tensor returned from 'inside_backprop' is incorrect.", False
            elif torch.isclose(span_nt_marginal, span_nt_marginal2).all():
                pred, gold, msg, passed = "<marginal>", "<marginal>", "Correct.", True
            else:
                pred, gold, msg, passed = "<marginal>", "<marginal>", "Incorrect.", False

        except BaseException as e:
            return {"ans": e, "gold": None}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}
    
    def keywordTest(self):
        try:
            import inside, inspect, re

            requirements = eval(self.test_dict['requirements'])
            for_pattern = re.compile(r'^\s*for\s*\w+\s*in\s*range\s*\([^\)]+\)\s*:\s*$')

            def test_func(inside_func):
                loops = 0
                lines, line_no = inspect.getsourcelines(inside_func)
                for i, line in enumerate(lines):
                    line = line.split('#')[0].strip()
                    if any([s.strip().endswith('for') for s in line.split()]):
                        if for_pattern.match(line):
                            loops += 1
                        else:
                            pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o for>", "For loops should only use format 'for ... in range(...):'.", False
                            return (pred, gold, msg, passed)
                    if any([s.strip().endswith('while') for s in line.split()]):
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o while>", "Your inside function contains a while loop!", False
                        return (pred, gold, msg, passed)
                    if i>0 and any([s.strip().endswith('def') for s in line.split()]):
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o def>", "Your inside function contains a local function!", False
                        return (pred, gold, msg, passed)
                return loops

            def test():
                loop_dict = {}

                for func in inside.__dict__.values():
                    if inspect.isfunction(func):
                        if func.__name__ not in ('inside', 'outside', 'inside_outside', 'inside_backprop'):
                            pred, gold, msg, passed = f"func: {func.__name__}", "<code w/o def>", "Your inside function contains a self-defined function!", False
                            return (pred, gold, msg, passed)
                    
                        loops = test_func(func)
                        if isinstance(loops, tuple): return loops
                        loop_dict[func.__name__] = loops
                
                lines, line_no = inspect.getsourcelines(inside)
                for i, line in enumerate(lines):
                    line = line.split('#')[0].strip()
                    if any([s.strip().endswith('import') for s in line.split()]) and line.strip() != 'import torch':
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o import>", "Do not import other modules.", False
                        return (pred, gold, msg, passed)
                    if 'exec' in line or 'eval' in line:
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o exec>", "Do not use exec or eval.", False
                        return (pred, gold, msg, passed)
                    if 'class' in line.lower():
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o class>", "Do not use class.", False
                        return (pred, gold, msg, passed)
                    if 'lambda' in line.lower():
                        pred, gold, msg, passed = f"line {line_no+i}: {line}", "<code w/o lambda>", "Do not use lambda.", False
                        return (pred, gold, msg, passed)
                
                for func, loops in requirements.items():
                    if func not in loop_dict:
                        pred, gold, msg, passed = f"func: {func}", f"<code with {func}>", f"Your inside function does not contain {func}.", False
                        return (pred, gold, msg, passed)
                    if loop_dict[func] > loops:
                        pred, gold, msg, passed = f"func: {func}", f"<code with {loops} loops>", f"Your inside function contain {loop_dict[func]} for loops, which is more than {loops}-loops requirement.", False
                        return (pred, gold, msg, passed)

                pred, gold, msg, passed = "<code>", "<code>", "Your inside function has passed the for loop check.", True
                return (pred, gold, msg, passed)
                    
            pred, gold, msg, passed = test()

        except BaseException as e:
            return {"ans": e, "gold": None}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}
    
    def insideTest(self):
        try:
            import inside
            import torch

            def test(path):

                func = getattr(inside, self.test_dict['func'])
                data = torch.load(path)
                unary, binary, root = data['unary'], data['binary'], data['root']

                if func.__name__ == 'inside':
                    alpha, logZ = func(unary, binary, root)
                    if not torch.allclose(alpha, data['alpha'], atol=1e-05):
                        pred, gold, msg, passed = f"<tensor>", f"<tensor>", f"alpha returned by inside is incorrect. Test data: {path}", False
                    elif not torch.allclose(logZ, data['logZ'], atol=1e-05):
                        pred, gold, msg, passed = f"<tensor>", f"<tensor>", f"logZ returned by inside is incorrect. Test data: {path}", False
                    else:
                        pred, gold, msg, passed = "<tensor>", "<tensor>", "Inside function works correctly.", True
                elif func.__name__ == 'outside':
                    beta = func(data['alpha'], unary, binary, root)
                    if not torch.allclose(beta, data['beta'], atol=1e-05):
                        pred, gold, msg, passed = f"<tensor>", f"<tensor>", f"beta returned by outside is incorrect. Test data: {path}", False
                    else:
                        pred, gold, msg, passed = "<tensor>", "<tensor>", "Outside function works correctly.", True
                elif func.__name__ == 'inside_outside':
                    span_nt_marginal = func(unary, binary, root)
                    if not torch.allclose(span_nt_marginal, data['span_nt_marginal'], atol=1e-05):
                        pred, gold, msg, passed = f"<tensor>", f"<tensor>", f"span_nt_marginal returned by inside_outside is incorrect. Test data: {path}", False
                    else:
                        pred, gold, msg, passed = "<tensor>", "<tensor>", "inside_outside function works correctly.", True
                elif func.__name__ == 'inside_backprop':
                    span_nt_marginal = func(unary, binary, root)
                    if not torch.allclose(span_nt_marginal, data['span_nt_marginal2'], atol=1e-05):
                        pred, gold, msg, passed = f"<tensor>", f"<tensor>", f"span_nt_marginal returned by inside_backprop is incorrect. Test data: {path}", False
                    else:
                        pred, gold, msg, passed = "<tensor>", "<tensor>", "inside_backprop function works correctly.", True
                return pred, gold, msg, passed

            paths = eval(self.test_dict['paths'])
            for path in paths:
                pred, gold, msg, passed = test(path)
                if not passed: break

        except BaseException as e:
            return {"ans": e, "gold": None}
        return {"ans": pred, "gold": gold, "msg": msg, "passed": passed}

    
    def consecutiveTest(self):
        msg = ''
        try:
            gold = eval(self.solution_dict['solution'])
            exec(self.test_dict['code'])
            ans = eval(self.test_dict['ans'])
        except BaseException as e:
            ans = e
        return {"ans": ans, "gold": gold, "msg":msg}
    
    # ================= The end of the algorithms run during the test =================#

    

class TestParser(object):

    def __init__(self, path):
        # save the path to the test file
        self.path = path

    def removeComments(self, rawlines):
        # remove any portion of a line following a '#' symbol
        fixed_lines = []
        for l in rawlines:
            idx = l.find('#')
            if idx == -1:
                fixed_lines.append(l)
            else:
                fixed_lines.append(l[0:idx])
        return '\n'.join(fixed_lines)

    def parse(self):
        # read in the test case and remove comments
        test = {}
        with open(self.path) as handle:
            raw_lines = handle.read().split('\n')

        test_text = self.removeComments(raw_lines)
        test['__raw_lines__'] = raw_lines
        test['path'] = self.path
        test['__emit__'] = []
        lines = test_text.split('\n')
        i = 0
        # read a property in each loop cycle
        while(i < len(lines)):
            # skip blank lines
            if re.match('\A\s*\Z', lines[i]):
                test['__emit__'].append(("raw", raw_lines[i]))
                i += 1
                continue
            m = re.match('\A([^"]*?):\s*"([^"]*)"\s*\Z', lines[i])
            if m:
                test[m.group(1)] = m.group(2)
                test['__emit__'].append(("oneline", m.group(1)))
                i += 1
                continue
            m = re.match('\A([^"]*?):\s*"""\s*\Z', lines[i])
            if m:
                msg = []
                i += 1
                while(not re.match('\A\s*"""\s*\Z', lines[i])):
                    msg.append(raw_lines[i])
                    i += 1
                test[m.group(1)] = '\n'.join(msg)
                test['__emit__'].append(("multiline", m.group(1)))
                i += 1
                continue
            print ('error parsing test file: %s' % self.path)
            sys.exit(1)
        return test


def emitTestDict(testDict, handle):
    for kind, data in testDict['__emit__']:
        if kind == "raw":
            handle.write(data + "\n")
        elif kind == "oneline":
            handle.write('%s: "%s"\n' % (data, testDict[data]))
        elif kind == "multiline":
            handle.write('%s: """\n%s\n"""\n' % (data, testDict[data]))
        else:
            raise Exception("Bad __emit__")
