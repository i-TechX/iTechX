# util.py
# -------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import sys
from hashlib import md5 as md5_

# Useful data structures
# ----------------------

class Stack:
    "A container with a last-in-first-out (LIFO) queuing policy."
    def __init__(self):
        self.list = []

    def push(self,item):
        "Push 'item' onto the stack"
        self.list.append(item)

    def pop(self):
        "Pop the most recently pushed item from the stack"
        return self.list.pop()

    def isEmpty(self):
        "Returns true if the stack is empty"
        return len(self.list) == 0
    
    def size(self):
        "Returns the size of the stack"
        return len(self.list)

# Definition for a binary tree node.
class BinaryTreeNode:
    def __init__(self, x = None, left = None, right = None):
        self.val = x
        self.left = None
        self.right = None

    def __str__(self):
        return f"BinaryTreeNode({str(self.val)}, left={str(self.left)}, right={str(self.right)})"

# Definitions for a tree node.
class TreeNode:
    def __init__(self, x = None, left = None, right = None):
        self.val = x
        self.left = [] if left is None else left
        self.right = [] if right is None else right

    def __str__(self):
        return f"TreeNode(\n{str(self.val)}, left={str(self.left)}, right={str(self.right)})"

# Definitions for a graph node.
class GraphNode:
    def __init__(self, x = None, children = None):
        self.val = x
        self.children = [] if children is None else children

    def __repr__(self):
        return f"GraphNode({str(self.val)} <with {len(self.children)} children>)"


# MD5 Hash
# --------------------
def md5(obj):
    """Return the md5 hash of the given object."""
    s = str(obj).encode(encoding='UTF-8')
    m = md5_(s).hexdigest()
    return m


# Code to mute outputs
# --------------------

_ORIGINAL_STDOUT = None
_ORIGINAL_STDERR = None
_MUTED = False

class WritableNull:
    def write(self, string):
        pass

def mutePrint():
    global _ORIGINAL_STDOUT, _ORIGINAL_STDERR, _MUTED
    if _MUTED:
        return
    _MUTED = True

    _ORIGINAL_STDOUT = sys.stdout
    #_ORIGINAL_STDERR = sys.stderr
    sys.stdout = WritableNull()
    #sys.stderr = WritableNull()

def unmutePrint():
    global _ORIGINAL_STDOUT, _ORIGINAL_STDERR, _MUTED
    if not _MUTED:
        return
    _MUTED = False

    sys.stdout = _ORIGINAL_STDOUT
    #sys.stderr = _ORIGINAL_STDERR