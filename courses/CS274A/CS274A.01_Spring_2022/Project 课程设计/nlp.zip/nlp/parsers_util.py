# parsers_util.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to ShanghaiTech University, including a link 
# to https://i-techx.github.io/iTechX/courses?course_code=CS274A
# 
# Attribution Information: The NLP projects were developed at ShanghaiTech University.
# The core projects and autograders were created by Haoyi Wu (wuhy1@shanghaitech.edu.cn),
# severely modified by the Pacman projects from UC Berkeley (http://ai.berkeley.edu/projects/pacman/)

ROOT = "ROOT"


class DependencyNode:
    """
    A node in a dependency graph.
    """
    def __init__(self, token, head = None):
        """
        Initialize a dependency node. The head should be another dependency node, or None.
        """
        self.token = token
        self.head = head


class DependencyGraph:
    """
    A container for the nodes and edges of a dependency structure.
    """

    def __init__(self, nodes = None):
        """
        Create a dependency graph from the list of dependency nodes.
        """
        self.nodes = [] if nodes is None else nodes
        
    def __eq__(self, other):
        """
        We say two dependency graphs are equal iff their tokens are the same and the
        heads index are the same.
        """
        if not isinstance(other, DependencyGraph):
            return False
        return (self.sentence == other.sentence and
                self.heads == other.heads)
    
    def __str__(self):
        """
        :return: a human-readable string representation of the graph
        :rtype: str
        """
        s = "sentence: "
        h = "heads:    "
        for token, head in zip(self.sentence, self.heads):
            s += str(token) + " "
            h += str(head).ljust(len(token) + 1)
        return "\n" + s + "\n" + h

    @property
    def sentence(self):
        """
        The sentence in this dependency graph.
        """
        return [node.token for node in self.nodes]

    @property
    def heads(self):
        """
        :returns: a list of ints, the indices of the heads of the nodes in self.nodes
        """
        d = {hash(n): i for i, n in enumerate(self.nodes)}
        def get_head(node):
            if node.head is None:
                return -1
            if hash(node.head) in d:
                return d[hash(node.head)]
            raise ValueError("Node's head not found in graph")
        return [get_head(node) for node in self.nodes]


class TransitionError(Exception):
    pass

