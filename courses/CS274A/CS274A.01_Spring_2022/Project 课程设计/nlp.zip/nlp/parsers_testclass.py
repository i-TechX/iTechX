# parsers_testclass.py
# -------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to ShanghaiTech University, including a link 
# to https://i-techx.github.io/iTechX/courses?course_code=CS274A
# 
# Attribution Information: The NLP projects were developed at ShanghaiTech University.
# The core projects and autograders were created by Haoyi Wu (wuhy1@shanghaitech.edu.cn),
# severely modified by the Pacman projects from UC Berkeley (http://ai.berkeley.edu/projects/pacman/)

try:
    from parsers import TransitionBasedParser
except:
    pass

try:
    from parsers import ChuLiuEdmondsParser
except:
    pass

try:
    from parsers import EisnerParser
except:
    pass

from parsers_util import TransitionError, ROOT
from util import GraphNode


class TransitionSystem:
    """
    A transition system. The implementation is at instance level, so that we
    can monitor action calls.
    """
    def __init__(self, func):
        self.func = func
    
    def get_next_action(self, *args, **kwargs):
        return self.func(*args, **kwargs)


class TransitionBasedParserTestClass:

    @classmethod
    def test_parse(cls, tokens, transitions):
        """
        Test the parser on a sequence of tokens.
        :param list[str] tokens: the list of input tokens.
        :param list[str] transitions: the list of transitions.
        """

        cnt = 0
        def trans(*args, **kwargs):
            nonlocal cnt
            res = transitions[cnt] if cnt < len(transitions) else 'SHIFT'
            cnt += 1
            return res
        system = TransitionSystem(trans)
        parser = TransitionBasedParser(system)

        try:
            graph = parser.parse(tokens)
        except TransitionError as e:
            graph = e
        
        return graph, cnt


class DependencyScorer:
    """
    A dependency scorer. The implementation is at instance level, so that we
    can monitor action calls.
    """
    def __init__(self, func):
        self.func = func
    
    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs)


class ChuLiuEdmondsParserTestClass:

    @classmethod
    def test_parse(cls, tokens, scores):
        """
        Test the parser on a sequence of tokens.
        :param list[str] tokens: the list of input tokens.
        :param list[list[float]] score: the score matrix
        """
        nodes = list(map(GraphNode, [ROOT] + tokens))
        for idx, (node, score) in enumerate(zip(nodes, scores)):
            for idx_, (node_, score_) in enumerate(zip(nodes, score)):
                if idx_ not in (0, idx):
                    node.children.append((node_, score_))

        for idx, node in enumerate(nodes):
            node.idx = idx
            node.children.sort(key=lambda x: x[1])
        
        cnt = 0
        def getScore(*args, **kwargs):
            nonlocal cnt
            if cnt: raise RuntimeError("Call scorer more than once in one parse!")
            else: cnt = 1
            return nodes[0]

        scorer = DependencyScorer(getScore)
        parser = ChuLiuEdmondsParser(scorer)
        
        graph = parser.parse(tokens)

        return graph


class EisnerParserTestClass:
    """
    ref: https://aclanthology.org/P05-1013.pdf
    """

    @classmethod
    def test_is_projective(cls, graph):
        heads = graph.heads

        for i in range(1, len(heads)):
            head = heads[i]
            a, b = min(i, head), max(i, head)
            for j in range(a+1, b):
                if not (a <= heads[j] <= b):
                    return False
        return True

    @classmethod
    def test_parse(cls, tokens, scores):
        """
        Test the parser on a sequence of tokens.
        :param list[str] tokens: the list of input tokens.
        :param list[list[float]] score: the score matrix
        """
        nodes = list(map(GraphNode, [ROOT] + tokens))
        for idx, (node, score) in enumerate(zip(nodes, scores)):
            for idx_, (node_, score_) in enumerate(zip(nodes, score)):
                if idx_ not in (0, idx):
                    node.children.append((node_, score_))

        for idx, node in enumerate(nodes):
            node.idx = idx
            node.children.sort(key=lambda x: x[1])
        
        cnt = 0
        def getScore(*args, **kwargs):
            nonlocal cnt
            if cnt: raise RuntimeError("Call scorer more than once in one parse!")
            else: cnt = 1
            return nodes[0]

        scorer = DependencyScorer(getScore)
        parser = EisnerParser(scorer)
        
        graph = parser.parse(tokens)

        return graph