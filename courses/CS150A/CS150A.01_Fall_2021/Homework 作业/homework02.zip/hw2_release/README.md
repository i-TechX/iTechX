# CS150A Database HW2:

In homework 2, you need to finish hw2_coding.ipynb.

*Caution: Activity-15.ipynb is recommended to complete but not necessary. What
you need is to fill out the required content of submit.py.*

## Submission Instructions for Homework 2

1. Finish `hw2_coding.ipynb` following the instructions at its top. 
2. Copy your answers to `submit.py`.
3. Upload the pdf version of 'submit.py' to gradescope.

## Due date
 
23:59, 2021.12.4.
