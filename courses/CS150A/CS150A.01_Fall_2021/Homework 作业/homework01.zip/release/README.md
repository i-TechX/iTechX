# HW1

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (100 PTS)

1. Finish the problems in `hw1_writing.tex`.
2. Upload the pdf version of your answers to gradescope.

### Part Two: Coding (100 PTS)

1. Finish `hw1_coding.ipynb`. 
2. Finish `submit.py` following the submission instructions at the top of `hw1_coding.ipynb`.

## Due date
 
23:59, 2021.10.31.
