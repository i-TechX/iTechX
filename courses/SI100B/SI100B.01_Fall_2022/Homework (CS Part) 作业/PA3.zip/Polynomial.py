class Polynomial:
    #################### Task1 #######################
    def __init__(self, coeffs):
        pass

    def __str__(self):
        pass

    def deg(self):
        pass

    #################### Task2 #######################
    def __neg__(self):
        pass

    def __add__(self, other):
        pass

    def __sub__(self, other):
        pass

    def __mul__(self, other):
        pass

    def evaluate(self, x):
        pass
    
    #################### Task3 #######################
    def derivate(self, m):
        pass

    def integral(self,m):
        pass
    
    def definite_integral(self,m,x1,x2):
        pass

########## DON'T MODIFY THE CODE BELOW ##########
if __name__ == "__main__":
    print(eval(input()))