This file contains assignment 1, an optional template that you may use for the report, and all the images that will used in the assignment.

The template may not perfectly meet all your needs and you may modify the template to produce an ideal report.

The submission requirements are listed in the assignment. Double check your submission to ensure all the requirements are satisfied.

Submit your homework on 'blackboard' BEFORE the deadline. Late submission will not be accepted.