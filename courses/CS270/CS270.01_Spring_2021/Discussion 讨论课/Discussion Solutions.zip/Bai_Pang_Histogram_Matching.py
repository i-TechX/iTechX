# coding: utf-8

import cv2
import numpy as np

# 精力有限，只实现了uint8的情况

def quantization(ch, bits=8):
    L = 1 << bits
    ch = np.round(ch)
    ch[ch<0] = 0
    ch[ch>=L] = L-1
    ch = ch.astype(eval(f'np.uint{bits}'))
    return ch

def get_histogram_equalization_transformation(ch, L=256):  # ch for channel
    M, N = ch.shape[:2]
    Sigma = np.array([np.sum(ch<=i) for i in range(L)])
    T = (L-1) / (M*N) * Sigma.astype(np.float64)
    T = quantization(T)
    return T

def apply_transformation(ch, T):
    out = quantization(ch)
    for r, Tr in enumerate(T):
        out[ch==r] = Tr
    return out

def channel_histogram_equalization(ch):
    T = get_histogram_equalization_transformation(ch)
    ret = apply_transformation(ch, T)
    return ret

def histogram_equalization(img):
    if len(img.shape) == 2:
        return channel_histogram_equalization(img)
    else:
        ret = np.empty_like(img)
        for i in range(img.shape[2]):
            ret[..., i] = channel_histogram_equalization(img[..., i])
        return ret

def inversion(T):
    L = len(T)
    T_ = np.empty_like(T)
    last_Tr = -1
    for r in range(L):
        T_[last_Tr+1: T[r]+1] = r
        last_Tr = T[r]
    T_[T[L-1]+1: L] = L-1
    return T_

def composition(F, G):
    T = np.empty_like(F)
    for r, Gr in enumerate(G):
        T[r] = F[Gr]
    return T

def channel_histogram_matching(ch, tar):
    T = get_histogram_equalization_transformation(ch)
    G = get_histogram_equalization_transformation(tar)
    F = composition(inversion(G), T)
    ret = apply_transformation(ch, F)
    return ret

def histogram_matching(img, target):
    assert img.dtype == target.dtype  # == np.uint8
    assert len(img.shape) == len(target.shape)
    if len(img.shape) == 2:
        return channel_histogram_matching(img, target)
    else:
        ret = np.empty_like(img)
        for i in range(img.shape[2]):
            ret[..., i] = channel_histogram_matching(img[..., i], target[..., i])
        return ret

##############################################################################
B = 'histogram_matching'
lena = cv2.imread(f'{B}/lena.jpg')
tar1 = cv2.imread(f'{B}/timg.jpg')
tar2 = cv2.imread(f'{B}/img2.jpg')
out1 = histogram_matching(lena, tar1)
out2 = histogram_matching(lena, tar2)
cv2.imwrite(f'{B}/lena1.png', out1)
cv2.imwrite(f'{B}/lena2.png', out2)
##############################################################################
