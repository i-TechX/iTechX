function regiongrow(im,t)

while 1
    
figure(1)
imshow(im)
g = round(ginput(1));

if nargin<2
    bw = grayconnected(im,g(2),g(1));
else
    bw = grayconnected(im,g(2),g(1),t);
end

figure;
imshow(bw);

figure;
h = imshow(imoverlay(im,bw,'cyan'));
end
