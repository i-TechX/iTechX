function img = my_back2rgb(lab_s,lab_t,x,y,z)
%set pic size here
% x = 512;
% y = 768;
% z = 3;

a = [sqrt(3)/3 0 0;0 sqrt(6)/6 0;0 0 sqrt(2)/2];
b = [1 1 1;1 1 -1;1 -2 0];
c = [4.4679 -3.5873 0.1193;-1.2186 2.3809 -0.1624;0.0497 -0.2439 1.2045];

% compute mean and std
mean_s = mean(lab_s,2);
std_s = std(lab_s,0,2);
mean_t = mean(lab_t,2);
std_t = std(lab_t,0,2);

res_lab = zeros(3,x*y);

sf = std_t./std_s;

for ch = 1:3 % for each channel, apply the statistical alignment
    res_lab(ch,:) = (lab_s(ch,:) - mean_s(ch))*sf(ch) + mean_t(ch);
end

% convert back to LMS
LMS_res=b*a*res_lab;
for ch = 1:3
    LMS_res(ch,:) = 10.^LMS_res(ch,:);
end

% convert back to RGB
img = (c*LMS_res)';
img = reshape(img,x,y,z); % reshape the image
end