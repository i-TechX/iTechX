clc
clear all;

%%
% ��1��
I0 = im2double(imread('houses.bmp'));% source
I1 = im2double(imread('hats.bmp'));% target

[x,y,z] = size(I0);
img_s = reshape(im2double(I0),[],3);
img_t = reshape(im2double(I1),[],3);
img_s = max(img_s,1/255);
img_t = max(img_t,1/255);

lab_s = my_rgb2lab(img_s');
lab_t = my_rgb2lab(img_t');
lab_s = reshape(lab_s',x,y,3); 
lab_t = reshape(lab_t',x,y,3); 
figure;
subplot(1,2,1); imshow(lab_s);title('Source Image in lab Color Space');
subplot(1,2,2); imshow(lab_t);title('Target Image in lab Color Space');
%%
% (2)
figure;
subplot(1,3,1); imshow(lab_s(:, :, 1),[]);title('l Component of Source Image');
subplot(1,3,2); imshow(lab_s(:, :, 2),[]);title('a Component of Source Image');
subplot(1,3,3); imshow(lab_s(:, :, 3),[]);title('b Component of Source Image');
%%
% (3)
q3();
%%
% (4)
clc

I0 = im2double(imread('Mountains.png'));
I1 = im2double(imread('Starry_night.png'));

IR1 = reinhard(I0,I1);
IR2 = reinhard(I1,I0);

figure;
subplot(2,3,1); imshow(I0); title('Original Image'); axis off
subplot(2,3,2); imshow(I1); title('Target Palette'); axis off
subplot(2,3,3); imshow(IR1); title('Result After Colour Transfer'); axis off
subplot(2,3,4); imshow(I1); title('Original Image'); axis off
subplot(2,3,5); imshow(I0); title('Target Palette'); axis off
subplot(2,3,6); imshow(IR2); title('Result After Colour Transfer'); axis off
%%
% (5)(6)
I0 = im2double(imread('flower1.jpg'));
I1 = im2double(imread('flower2.jpg'));

IR1 = reinhard(I0,I1);
IR2= Color_Transfer_CCS(I0,I1); 

figure;
subplot(1,3,1); imshow(I0); title('Original Image'); axis off
subplot(1,3,2); imshow(I1); title('Target Image'); axis off
subplot(1,3,3); imshow(IR1); title('Result After Colour Transfer'); axis off
figure; imshow(IR2); title('Result After Spatial Related Colour Transfer'); axis off


