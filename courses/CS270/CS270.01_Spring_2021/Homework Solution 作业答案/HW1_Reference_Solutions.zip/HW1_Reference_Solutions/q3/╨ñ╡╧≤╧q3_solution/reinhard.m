function res_img = reinhard(source,target)

[x,y,z] = size(source);
img_s = reshape(im2double(source),[],3);
img_t = reshape(im2double(target),[],3);

img_s = max(img_s,1/255);
img_t = max(img_t,1/255);

lab_s = my_rgb2lab(img_s');
lab_t = my_rgb2lab(img_t');

res_img = my_back2rgb(lab_s, lab_t, x, y, z);
