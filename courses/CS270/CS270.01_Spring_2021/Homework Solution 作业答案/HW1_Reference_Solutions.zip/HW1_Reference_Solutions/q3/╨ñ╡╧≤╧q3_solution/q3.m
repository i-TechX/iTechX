function q3()
% ��3��
b2 = [sqrt(3)/3 0 0;0 sqrt(6)/6 0;0 0 sqrt(2)/2];
c2 = [1 1 1;1 1 -1;1 -2 0];

I0 = im2double(imread('houses.bmp'));% source
I1 = im2double(imread('hats.bmp'));% target

[x,y,z] = size(I0);
img_s = reshape(im2double(I0),[],3);
img_t = reshape(im2double(I1),[],3);
img_s = max(img_s,1/255);
img_t = max(img_t,1/255);

lab_s = my_rgb2lab(img_s');
lab_t = my_rgb2lab(img_t');
% lab_s = reshape(lab_s',x,y,3); 
% lab_t = reshape(lab_t',x,y,3); 

% compute mean and std
mean_s = mean(lab_s,2);
std_s = std(lab_s,0,2);
mean_t = mean(lab_t,2);
std_t = std(lab_t,0,2);

res_lab = zeros(3,x*y);

sf = std_t./std_s;

for ch = 1:3 % for each channel, apply the statistical alignment
    res_lab(ch,:) = (lab_s(ch,:) - mean_s(ch))*sf(ch) + mean_t(ch);
end

% convert back to LMS
LMS_res=c2*b2*res_lab;
for ch = 1:3
    LMS_res(ch,:) = 10.^LMS_res(ch,:);
end

img_c = reshape(res_lab',size(I0));

% convert back to RGB
est_im = ([4.4679 -3.5873 0.1193;-1.2186 2.3809 -0.1624;0.0497 -0.2439 1.2045]*LMS_res)';
est_im = reshape(est_im,size(I0)); % reshape the image

figure;
subplot(1,2,1); imshow(img_c);title('Result after Color Transfer in lab Color Space');
subplot(1,2,2); imshow(est_im);title('Result after Color Transfer in RGB Color Space');
end