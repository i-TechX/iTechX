# DIP Homework 1: README

Zhuoan Li

Environment: 

- MATLAB 2020b
  - Image processing Toolbox
  - Deep learning Toolbox

All the function is in zip document and do not need to input any images manually.

- To check the code, you just need to open "hw1_ZhuoanLi.mlx" since all the codes are in the file.

- If there exist warning in problem two, please run more times then the result will get more stable. 
- The last part of problem 3 used a neural network and if you need to run it, please just be patient, it will take you few minutes or you can just change the iteration time in a smaller number.