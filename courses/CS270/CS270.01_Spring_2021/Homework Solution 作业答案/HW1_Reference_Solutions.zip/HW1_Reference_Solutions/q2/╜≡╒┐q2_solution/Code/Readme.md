- Here are three ipynb files

- 'Problem1.ipynb' is the code for task 1, and so on.

- The libraries that need to be installed are:

  numpy

  os

  matplotlib

  cv2

  glob

  imutils

  imageio