function [match] = ChooseGoodMatchingPoint(match12,f1,f2,er)
[M,~]=size(match12);
match=zeros(1,2);
num=0;
for i=1:1:M
    p11=f1(match12(i,1),:);
    p12=f2(match12(i,2),:);   
    for j=1:1:M
        if j~=i
            p21=f1(match12(j,1),:);
            p22=f2(match12(j,2),:); 
            dx1=p11(1)-p21(1);
            dy1=p11(2)-p21(2);
            dx2=p12(1)-p22(1);
            dy2=p12(2)-p22(2);
            distance1=sqrt(p11(1)-p21(1))^2+(p11(2)-p21(2))^2; 
            distance2=sqrt(p12(1)-p22(1))^2+(p12(2)-p22(2))^2;
            if abs(dx1-dx2)<er && abs(dy1-dy2)<er && distance1<er && distance2<er && sum(sum(match==match12(i,:)))==0
                num=num+1;
                match(num,:)=match12(i,:);
            end
        end
        
    end
end

end

