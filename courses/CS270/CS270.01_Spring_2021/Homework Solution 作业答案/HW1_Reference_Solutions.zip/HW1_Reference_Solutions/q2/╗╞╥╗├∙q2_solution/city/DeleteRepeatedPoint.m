function [match12] = DeleteRepeatedPoint(match12)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
[M,~]=size(match12);
for l=1:1:M
    if sum(match12(l,1)==match12(:,1))>1
        d_num=sum(match12(l,1)==match12(:,1));
        d_vec=find(match12(l,1)==match12(:,1))
        match12(d_vec,:)=[];
        l=l-1; [M,~]=size(match12);
    elseif sum(match12(l,2)==match12(:,2))>1
        d_num=sum(match12(l,2)==match12(:,2));
        d_vec=find(match12(l,1)==match12(:,1));
        match12(d_vec,:)=[];
        l=l-1; [M,~]=size(match12);
    end
    if l>=M
        break
    end
end
end

