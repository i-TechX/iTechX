clear;clc;
ex_image=imread('Ex_ColorEnhance.png');
[M,N,~]=size(ex_image);
figure;subplot(2,2,1);imshow(ex_image);title('original image');

%%%%%%%%%%%%%%histogram equalization%%%%%%%%%%%%%%%
output_1=his_equ(ex_image);
subplot(2,2,2);imshow(output_1), title('histogram equalization');

%%%%%%%%%%%%%%local histogram equalization%%%%%%%%%%%%%%%
%set up local sweep window
window_size=100;
length=floor(window_size/2);
window=ones(window_size);
%extend the image
input_2=wextend('2D','sym',ex_image,window_size);
[M_2,N_2,~]=size(input_2);
%equalize the histogram in the local window
output_2=uint8(zeros(M_2,N_2,3));
for i=1+window_size:M_2-window_size
    for j=1+window_size:N_2-window_size
        local_image=input_2(i-length:i-length+window_size-1,j-length:j-length+window_size-1,1:3);
        local_output=his_equ(local_image);
        output_2(i,j,1:3)=local_output(1+length,1+length,1:3);
    end
end
output_2=output_2(1+window_size:M_2-window_size,1+window_size:N_2-window_size,1:3);
subplot(2,2,3);imshow(output_2);title('local histogram equalization');

%%%%%%%%%%%%%He Kaiming's dark channel theory%%%%%%%%%%%%%%
input_3=ex_image;
w0=0.9;  %defogging factor 
t0=0.3; %illumination factor   
%generate dark channel image
dark_channel=zeros(M,N);
for i=1:M        
    for j=1:N
        dark_channel(i,j)=min(input_3(i,j,:));
    end
end
 %defogging
Max_dark_channel=double(max(max(dark_channel))); 
dark_channel=double(dark_channel);
t=1-w0*(dark_channel/Max_dark_channel);  
t=max(t,t0);
I1=double(input_3);
J(:,:,1) = uint8((I1(:,:,1) - (1-t)*Max_dark_channel)./t);
mean_1=mean(mean(J(:,:,1)));
J(:,:,2) = uint8((I1(:,:,2) - (1-t)*Max_dark_channel)./t);
J(:,:,3) =uint8((I1(:,:,3) - (1-t)*Max_dark_channel)./t);
 J=uint8(0.7*double(J).^(1.2));
subplot(2,2,4);imshow(J);title('dark channel theory');

%%%%%%%%%%%%%function of histogram equalization%%%%%%%%%%%%%
function output=his_equ(I)
output=I;
% generate normalized histogram
[M, N,~] = size(output);
PMF = zeros(1, 256);
for k=1:3
for i = 1:M
    for j = 1:N
        PMF(output(i,j,k) + 1) = PMF(output(i,j,k) + 1) + 1;
    end
end
PMF = PMF / (M * N);
%histogram equalization
CDF = zeros(1,256);
CDF(1) = PMF(1);
for i = 2:256
    CDF(i) = CDF(i - 1) + PMF(i);
end
post_histogram = zeros(1,256);
for i = 1:256
    post_histogram(i) = CDF(i) * 255;
end
%match new histogram back to the origin image
post_histogram = round(post_histogram);
for i = 1:M
    for j = 1:N
        output(i,j,k) = post_histogram(output(i,j,k) + 1);
    end
end
end
end
