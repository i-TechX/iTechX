clear;clc;
ex_image=imread('Tam_clear.jpg');
[M,N,~]=size(ex_image);
figure;subplot(2,1,1);imshow(ex_image);title('original image');
%%%%%%%%%%%%%%%%%fogging%%%%%%%%%%%%%%%%%%%%%
%find maximum intensity in three channels as the normalization standard
original_max=double(max(ex_image(:)));
%add noise(as the inverse process of histogram equalization)
rgbImage2 = double(ex_image)+500;
rgbImage2 = rgbImage2+unifrnd (0,10,M,N);
rgbImage2 = rgbImage2/max(rgbImage2(:))*original_max;
subplot(2,1,2);imshow(uint8(rgbImage2));title('foggy image');