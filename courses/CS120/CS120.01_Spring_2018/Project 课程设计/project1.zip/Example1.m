%% Simple Tx example

clear all;
fs=44100; % sampling rate
carrier=cos(2*pi*10000*linspace(0,8,fs*8)); % 10kHz carrier lasts for 8 second
transmit_1000bps_baseband=zeros(1,length(carrier));

for i=1:44:length(transmit_1000bps_baseband)-44 %44100/1000=44 1000bps
    if rand()>0.5
        transmit_1000bps_baseband(i:i+43)=1;
    else
        transmit_1000bps_baseband(i:i+43)=0;
    end
end
temp=transmit_1000bps_baseband.*carrier;
figure;
plot(temp); % spectrum
sound(temp,44100);