package javaTA;

public class Dog implements Animals,Pet {
	public void move(){
		System.out.println("The dog is moving");
	}
	public void eat(){
		System.out.println("The dog is eating");
	}
	public void accompany(){
		System.out.println("I love you");
	}
	public static void main(String [] agrs){
		Dog dog=new Dog();
		dog.move();
		dog.eat();
		dog.accompany();
	}
}
