package javaTA;

public class Print implements Runnable{
	public void run(){
		
		for(int i=1;i<=200;i++){
			System.out.println("hello"+i+"  ");
		}
		
	}
	
}

