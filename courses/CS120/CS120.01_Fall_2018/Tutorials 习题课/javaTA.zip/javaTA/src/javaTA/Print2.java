package javaTA;

public class Print2 extends Thread{
	public void run(){
		for(int i=1;i<=200;i++){
			System.out.println("hello"+i+"  ");
		}
	}

}
