package javaTA;

public class Students {
	public void view(Grades grades){
		System.out.println("english:"+grades.getEnglish());
		System.out.println("math:"+grades.getMath());
	}
}
