package javaTA;

public class Grades {
private int english ;
private int math ;
public void setEnglish(int score){
	english=score;
}
public void setMath(int score){
	math=score;
}
public int getEnglish(){
	return english;
}
public int getMath(){
	return math;
}
}
