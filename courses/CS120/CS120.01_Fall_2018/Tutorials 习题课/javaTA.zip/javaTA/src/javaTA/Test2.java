package javaTA;

public class Test2 {
	public static void main(String args[]){
	
		Thread threadOne =new Print2();
		
		threadOne.start();
		
		for(int i=1;i<=200;i++){
			System.out.println("���"+i+"  ");
		}	
	}
}
