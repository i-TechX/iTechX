package javaTA;

public interface Animals {
	public void move();
	public void eat();
}
