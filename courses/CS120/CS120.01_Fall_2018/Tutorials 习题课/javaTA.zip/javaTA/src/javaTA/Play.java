package javaTA;

import java.io.File;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

public class Play {
	public static void main(String args[]){
		try{
			AudioInputStream ais=AudioSystem.getAudioInputStream(new File("src\\javaTA\\kexi.wav"));
			
			AudioFormat baseFormat=ais.getFormat();
			System.out.println("baseFormat="+baseFormat);
			
			DataLine.Info info=new DataLine.Info(SourceDataLine.class, baseFormat);
			System.out.println("info="+info);
			
			SourceDataLine line=(SourceDataLine)AudioSystem.getLine(info);
			System.out.println("line="+line);
			
			line.open(baseFormat);
			line.start();
			int BUFFER_SIZE=4000*4;
			int intBytes=0;
			int outBytes;
			byte[] audioData=new byte[BUFFER_SIZE];
			while(intBytes!=-1)
			{
				intBytes=ais.read(audioData, 0, BUFFER_SIZE);
				if(intBytes>=0)
					outBytes=line.write(audioData, 0, intBytes);				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
}
