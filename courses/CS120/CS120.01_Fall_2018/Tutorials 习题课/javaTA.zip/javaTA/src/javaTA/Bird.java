package javaTA;

public class Bird extends Animal {
	public void eat(){
		System.out.println("The Bird is eating");
	}
	public void fly(){
		System.out.println("The Bird is flying");
	}
	public static void main(String [] agrs){
		Animal animal=new Animal();
		animal.eat();
		animal.move();
		Bird bird=new Bird();
		bird.eat();
		bird.move();
		bird.fly();
	}
}

