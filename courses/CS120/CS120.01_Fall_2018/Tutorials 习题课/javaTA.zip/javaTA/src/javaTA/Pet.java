package javaTA;

public interface Pet {
	public void accompany();
}
