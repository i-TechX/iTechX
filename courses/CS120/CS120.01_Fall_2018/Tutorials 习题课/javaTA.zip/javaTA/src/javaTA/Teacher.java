package javaTA;

public class Teacher {
	public void update(Grades grades,int englishscore,int mathscore){
		grades.setEnglish(englishscore);
		grades.setMath(mathscore);
	}
	public void view(Grades grades){
		System.out.println("english:"+grades.getEnglish());
		System.out.println("math:"+grades.getMath());
	}
	public static void main(String [] agrs){
		Grades grade = new Grades();
		Teacher teacher =new Teacher();
		Students student =new Students();
		teacher.update(grade, 90, 100);
		teacher.view(grade);
		student.view(grade);
	}
}
