package javaTA;

public class Animal {
	public void move(){
		System.out.println("The Animal is moving");
	}
	public void eat(){
		System.out.println("The Animal is eating");
	}
}
