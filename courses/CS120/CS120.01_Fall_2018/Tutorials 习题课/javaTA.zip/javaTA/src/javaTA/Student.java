package javaTA;

public class Student {
	//fields
	private String name;
	private int age;
	//constructor
	public Student(String name,int age){
		this.name=name;
		this.age=age;
	}
	//methods
	public String getName(){
		return this.name;
	}
	public String getAge(){
		return this.name;
	}
//main method
	public static void main(String args[]){
		Student studnt =new Student("Ningzhi",21);
		String name =studnt.getName();
		System.out.println(name);
	}
}
