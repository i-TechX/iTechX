package javaTA;

public class Test1 {
	
	public static void main(String args[]){
		Print sayhello=new Print();
		Thread threadOne =new Thread(sayhello);
		
		threadOne.start();
		
		for(int i=1;i<=200;i++){
			System.out.println("���"+i+"  ");
		}	
		
	}

}
