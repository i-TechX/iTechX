package javaTA;

public class Test3 {
	public static void main(String args[]){
		Counter count=new Counter();
		
		Thread increment1 =new Thread(count,"One");
		Thread increment2 =new Thread(count,"Two");
		
		increment1.start();
		increment2.start();
	}
}
