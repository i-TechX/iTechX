# SI151 HW5

## Introduction

HW5 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (30 PTS)

1. Finish the problems in `..\writing\hw5_writing.pdf`.
2. Upload your answers as "name_hw5_writing.pdf" to Gradescope.

### Part Two: Coding (70 PTS)

1. Finish `..\coding\hw5_coding.ipynb`. 
2. Upload your answers as "name_hw5_coding.pdf" to Gradescope.

## Due date
 
Friday, May 28 at 23:59 (CST)
