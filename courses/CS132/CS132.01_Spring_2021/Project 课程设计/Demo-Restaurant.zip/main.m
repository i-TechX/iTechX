close all
clear all 
db=OrderDB;
 pro=OrderProcessor;
 sapp=ServerUI;
 capp=ChefUI;
 
 pro.serverApp=sapp;
 pro.chefApp=capp;
 pro.orderDB=db;

 sapp.OrderProcessor=pro;
 capp.orderProcessor=pro;
 db.processor=pro;