classdef OrderDB < handle
    
    properties
        orderList
        processor
    end
    
    methods
        function register(DB,order)
            DB.orderList=[DB.orderList;order];
        end
        function list=retrieve(DB)
            list=DB.orderList;
        end
        function succ=update(DB,table,order)
            succ=0;
            for i=1:length(DB.orderList)
                if strcmp(DB.orderList(i).table,table) && ~strcmp(DB.orderList(i).status,'Complete')
                    DB.orderList(i)=order;
                    succ=1;
%                     DB.processor.displayMessage(sprintf('Order for %s Updated',order.table));
%                     DB.processor.displayOrder(order);
                    break;
                end
            end
        end
    end
    
    
end