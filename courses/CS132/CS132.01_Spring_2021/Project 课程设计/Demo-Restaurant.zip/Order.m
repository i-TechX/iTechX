classdef Order < handle
    properties
        table
        status='Created';
        startTime
        completeTime
        items
    end
    
    methods
        
    end
    
end