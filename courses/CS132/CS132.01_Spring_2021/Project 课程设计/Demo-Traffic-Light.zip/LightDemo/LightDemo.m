classdef LightDemo < handle
    properties
        hLight
        hLightController
        t
    end
    
    methods
        function obj=LightDemo(gLen,yLen,rLen)
            obj.hLight=Light;
            obj.hLightController=LightController(gLen,yLen,rLen);
            obj.hLight.hController=obj.hLightController;
            obj.hLight.hDemo=obj;
            obj.t=timer;
            obj.t.ExecutionMode='fixedRate';
            obj.t.Period=1;
            obj.t.TimerFcn=@obj.updateState;
            start(obj.t);

        end
        function updateState(obj,~,~)
            obj.hLight.updateState;
            obj.hLightController.updateState;
        end
    end
    
    
    
end