classdef LightController < handle
    properties
        state
        gtimer
        ytimer
        rtimer
        gLen
        yLen
        rLen
    end
 
    methods
        function obj=LightController(gLen,yLen,rLen)
            obj.state=1;
            obj.gLen=gLen;
            obj.yLen=yLen;
            obj.rLen=rLen;
            obj.gtimer=0;
            obj.ytimer=0;
            obj.rtimer=0;
 
        end
        function updateState(obj)
            switch obj.state
                case 1 %green
                    if obj.gtimer>obj.gLen
                        obj.state=2;
                        obj.gtimer=0;
                    else
                        obj.gtimer=obj.gtimer+1;
                    end
                case 2 %yellow
                    if obj.ytimer>obj.yLen
                        obj.state=3;
                        obj.ytimer=0;
                    else
                        obj.ytimer=obj.ytimer+1;
                    end
                case 3 %red
                    if obj.rtimer>obj.rLen
                        obj.state=1;
                        obj.rtimer=0;
                    else
                        obj.rtimer=obj.rtimer+1;
                    end
                
            end
        end
        
    end
    
    
    
    
end