import sys

from PyQt6 import QtCore, QtGui, QtWidgets, uic


class MainWindow(QtWidgets.QMainWindow):
  def __init__(self):
    super().__init__()
    uic.loadUi("form.ui", self)



if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec()