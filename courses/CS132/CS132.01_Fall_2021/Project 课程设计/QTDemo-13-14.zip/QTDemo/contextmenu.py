import sys
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import  QApplication, QLabel, QMainWindow, QMenu

class MainWindow(QMainWindow):
  def __init__(self):
    super().__init__()


  def contextMenuEvent(self, e):
      context = QMenu(self)
      context.addAction(QAction("test 1", self))
      context.addAction(QAction("test 2", self))
      q3 = QAction("test 3", self)
      context.addAction(q3)
      q3.triggered.connect(self.q3_clicked)
      context.exec(e.globalPos())

  def q3_clicked(self):
      print("Q3 Clicked")




if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec()